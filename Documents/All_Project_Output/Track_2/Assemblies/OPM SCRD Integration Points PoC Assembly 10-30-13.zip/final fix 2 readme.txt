Aggregation Worksheet
####################################################
Question 2.2.8

1 fixed.
2 fixed.
note some cases are not good to use the helper check null.
for example:
        if (arg == null || arg.length() != requiredLength) {
            throw new IllegalArgumentException("The length of the field - " + name + " must be " + requiredLength);
        }
Here the concrete error message are more accurate.   
     
==============================================
Question 2.5.1

1 fixed.


=====================
Question 2.5.6 
fixed.

