/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * <p>
 * This interface encapsulates the following file access operations:
 * <ul>
 * <li>check if a file exists</li>
 * <li>open file for input</li>
 * <li>open file for output</li>
 * <li>delete a file</li>
 * </ul>
 * </p>
 * <p>
 * The implementation may work on different underlying file systems(local file systems, networked file systems
 * etc.).
 * </p>
 * <p>
 * <strong>Thread Safety: </strong> Implementations must be thread safe.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public interface FileAccessService {

    /**
     * This method is used to check if a file exists.
     *
     * @param filePath the full file path
     * @return true if the file exists, false otherwise.
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    boolean fileExists(String filePath) throws FileAccessServiceException;

    /**
     * This method is used to open file for input. The file must be present, otherwise
     * <code>FileAccessServiceException</code> will be thrown.
     *
     * @param filePath the full file path
     * @return the InputStream for the file.
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    InputStream openFileForInput(String filePath) throws FileAccessServiceException;

    /**
     *
     This method is used to open file for output. If the file doesn't exist, it will be created.
     *
     * @param filePath the full file path
     * @return the OutputStream for the file.
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    OutputStream openFileForOutput(String filePath) throws FileAccessServiceException;

    /**
     *
     This method is used to delete a file.
     *
     * @param filePath the full file path
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    void deleteFile(String filePath) throws FileAccessServiceException;
}
