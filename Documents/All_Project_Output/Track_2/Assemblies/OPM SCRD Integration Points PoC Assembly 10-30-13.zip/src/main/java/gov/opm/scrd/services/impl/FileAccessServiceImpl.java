/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import gov.opm.scrd.services.FileAccessService;
import gov.opm.scrd.services.FileAccessServiceException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;

import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;

/**
 * <p>
 * This is the default implementation of FileAccessService, it supports file access to local file system and remote
 * CIFS/SMB file server.
 * </p>
 * <p>
 * NOTE that this is not a mock implementation, thus can be used in both PoC and the production.
 * </p>
 * <p>
 * <strong>Thread Safety: </strong> This class is thread safe since it's immutable.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class FileAccessServiceImpl implements FileAccessService {

    /**
     * The prefix of the SMB protocol.
     */
    private static final String SMB_PROTOCOL = "SMB://";

    /**
     * Default empty constructor.
     */
    public FileAccessServiceImpl() {
        // empty
    }

    /**
     * This method is used to check if a file exists.
     *
     * @param filePath the full file path
     * @return true if the file exists, false otherwise.
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    @Override
    public boolean fileExists(String filePath) throws FileAccessServiceException {
        filePath = Helper.checkStringNullOrEmpty(filePath, "filePath");

        if (isSmbFileProtocol(filePath)) {
            // File is on CIFS/SMB file server
            return smbFileExists(obtainSmbFile(filePath));
        }
        // File is on local file system
        return localFileExists(new File(filePath));
    }

    /**
     * This method is used to open file for input. The file must be present, otherwise
     * <code>FileAccessServiceException</code> will be thrown.
     *
     * @param filePath the full file path
     * @return the InputStream for the file.
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    @Override
    public InputStream openFileForInput(String filePath) throws FileAccessServiceException {
        filePath = Helper.checkStringNullOrEmpty(filePath, "filePath");
        if (isSmbFileProtocol(filePath)) {
            // File is on CIFS/SMB file server
            SmbFile smbFile = obtainSmbFile(filePath);
            if (smbFileExists(smbFile)) {
                try {
                    return smbFile.getInputStream();
                } catch (IOException e) {
                    throw new FileAccessServiceException(
                        "Error occurred when getting the input stream of the smb file(" + filePath + ").", e);
                }
            }
            throw new FileAccessServiceException("Smb file(" + filePath + ") is not found on the server.");
        }
        // File is on local file system
        File file = new File(filePath);
        if (localFileExists(file)) {
            try {
                return new FileInputStream(file);
            } catch (FileNotFoundException e) {
                throw new FileAccessServiceException("The file(" + filePath + ") can not be opened for reading.", e);
            } catch (SecurityException e) {
                throw new FileAccessServiceException("Security violation occurred when accessing the local file - "
                    + filePath + " .", e);
            }
        }
        throw new FileAccessServiceException("File(" + filePath + ") is not found on the local file system.");

    }

    /**
     * This method is used to open file for output. If the file doesn't exist, it will be created.
     *
     * @param filePath the full file path
     * @return the OutputStream for the file.
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    @Override
    public OutputStream openFileForOutput(String filePath) throws FileAccessServiceException {
        filePath = Helper.checkStringNullOrEmpty(filePath, "filePath");
        if (isSmbFileProtocol(filePath)) {
            // File is on CIFS/SMB file server
            SmbFile smbFile = obtainSmbFile(filePath);
            if (!smbFileExists(smbFile)) {
                try {
                    smbFile.createNewFile();
                } catch (SmbException e) {
                    throw new FileAccessServiceException("Error occurred when creating new smb file(" + filePath
                        + ").", e);
                }

            }
            try {
                return smbFile.getOutputStream();
            } catch (IOException e) {
                throw new FileAccessServiceException("Error occurred when getting the output stream of the smb file("
                    + filePath + ").", e);
            }

        }

        // File is on local file system
        File file = new File(filePath);
        if (!localFileExists(file)) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                throw new FileAccessServiceException("An I/O error occurred when creating the new file(" + filePath
                    + ") on the local file system.", e);
            } catch (SecurityException e) {
                throw new FileAccessServiceException("Security violation occurred when creating the new file("
                    + filePath + ") on the local file system.", e);
            }
        }
        try {
            return new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            throw new FileAccessServiceException("This local file(" + filePath + ") can not be opened for reading.",
                e);
        } catch (SecurityException e) {
            throw new FileAccessServiceException("Security violation occurred when accessing the local file - "
                + filePath + " .", e);
        }
    }

    /**
     * This method is used to delete a file.
     *
     * @param filePath the full file path
     * @throws IllegalArgumentException if filePath is null/empty
     * @throws FileAccessServiceException if any other error occurred during the operation
     */
    @Override
    public void deleteFile(String filePath) throws FileAccessServiceException {
        filePath = Helper.checkStringNullOrEmpty(filePath, "filePath");

        if (isSmbFileProtocol(filePath)) {
            // File is on CIFS/SMB file server
            SmbFile smbFile = obtainSmbFile(filePath);
            if (smbFileExists(smbFile)) {
                try {
                    smbFile.delete();
                } catch (SmbException e) {
                    throw new FileAccessServiceException("Error occurred when deleting the smb file(" + filePath
                        + ").", e);
                }

            }
            return;
        }
        // File is on local file system
        File file = new File(filePath);
        if (localFileExists(file)) {
            try {
                file.delete();
            } catch (SecurityException e) {
                throw new FileAccessServiceException("Security violation occurred when deleting the local file - "
                    + filePath + " .", e);
            }

        }
    }

    /**
     * This method is used to obtain the SMB file.
     *
     * @param filePath the file path
     * @return the SMB file
     * @throws FileAccessServiceException if the given file path is invalid
     */
    private static final SmbFile obtainSmbFile(String filePath) throws FileAccessServiceException {
        try {
            return new SmbFile(filePath);
        } catch (MalformedURLException e) {
            throw new FileAccessServiceException("The input file path( " + filePath + " ) is invalid.", e);
        }
    }

    /**
     * This method is used to check whether the SMB file exists.
     *
     * @param smbFile the SMB file to check
     * @return true if the SMB file exists, otherwise return false
     * @throws FileAccessServiceException if error occurring when checking whether the SMB file exists
     */
    private static final boolean smbFileExists(SmbFile smbFile) throws FileAccessServiceException {
        try {

            return smbFile.exists() && smbFile.isFile();
        } catch (SmbException e) {
            throw new FileAccessServiceException("Error occurred when checking whether the smb file( "
                + smbFile.getPath() + " ) exists.", e);
        }
    }

    /**
     * This method is used to check whether the local file exists.
     *
     * @param file the file to check
     * @return true if the local file exists, otherwise return false
     * @throws FileAccessServiceException if client user does not have read permission of this file
     */
    private static final boolean localFileExists(File file) throws FileAccessServiceException {
        try {
            return file.exists() && file.isFile();
        } catch (SecurityException e) {
            throw new FileAccessServiceException("Security violation occurred when accessing the local file - "
                + file.getAbsolutePath() + " .", e);
        }
    }

    /**
     * This method is used to check whether this file path conforms the SMB file protocol.
     *
     * @param filePath the file path
     * @return true if the file path is the SMB file path
     */
    private static final boolean isSmbFileProtocol(String filePath) {
        return filePath.toUpperCase().startsWith(SMB_PROTOCOL);
    }
}
