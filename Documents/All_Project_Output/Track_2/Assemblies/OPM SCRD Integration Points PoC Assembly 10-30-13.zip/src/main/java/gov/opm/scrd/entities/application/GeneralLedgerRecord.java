/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.services.impl.Helper;

import java.util.Date;

/**
 * This class represents a General Ledger record.
 * <p>
 * <strong>Thread Safety: </strong>This class is not thread safe since it's mutable, and it is not expected to be
 * used by multiple threads concurrently.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class GeneralLedgerRecord {

    /**
     * Represents the maximum length of the accounting code.
     */
    private static final int ACCOUNTING_CODE_MAX_LENGTH = 20;

    /**
     * <p>
     * Represents the Feeder System ID.
     * </p>
     * <p>
     * Valid values: Non-null, non-empty, its length must be 4.
     * </p>
     */
    private String feederSystemId;

    /**
     * <p>
     * Represents the payment date.
     * </p>
     * <p>
     * Valid values: Non-null.
     * </p>
     */
    private Date paymentDate;

    /**
     * <p>
     * Represents the General Ledger Filler.
     * </p>
     * <p>
     * Valid values: Any character.
     * </p>
     */
    private char generalLedgerFiller;

    /**
     * <p>
     * Represents the General Ledger Code.
     * </p>
     * <p>
     * Valid values: Non-null, non-empty, its length must be 3.
     * </p>
     */
    private String generalLedgerCode;

    /**
     * <p>
     * Represents the fiscal year.
     * </p>
     * <p>
     * Valid values: Positive integer in range (0, 9999].
     * </p>
     */
    private int fiscalYear;

    /**
     * <p>
     * Represents the accounting code.
     * </p>
     * <p>
     * Valid values: Non-null, non-empty, max length of 20.
     * </p>
     */
    private String accountingCode;

    /**
     * <p>
     * Represents the receipt amount.
     * </p>
     * <p>
     * Valid values: Positive double number.
     * </p>
     */
    private double receiptAmount;

    /**
     * <p>
     * Represents the revenue source code.
     * </p>
     * <p>
     * Valid values: Non-null, non-empty, its length must be 4.
     * </p>
     */
    private String revenueSourceCode;

    /**
     * Default empty constructor.
     */
    public GeneralLedgerRecord() {
        // Empty
    }

    /**
     * The setter for the feederSystemId instance variable.
     *
     * @param feederSystemId the feederSystemId to set
     * @throws IllegalArgumentException if the length of given feederSystemId is not 4
     */
    public void setFeederSystemId(String feederSystemId) {
        checkLength(4, feederSystemId, "feederSystemId");
        this.feederSystemId = feederSystemId;
    }

    /**
     * The setter for the paymentDate instance variable.
     *
     * @param paymentDate the paymentDate to set
     * @throws IllegalArgumentException if the given paymentDate is null
     */
    public void setPaymentDate(Date paymentDate) {
        Helper.checkNull(paymentDate, "paymentDate");
        this.paymentDate = paymentDate;
    }

    /**
     * The setter for the generalLedgerFiller instance variable.
     *
     * @param generalLedgerFiller the generalLedgerFiller to set
     */
    public void setGeneralLedgerFiller(char generalLedgerFiller) {
        this.generalLedgerFiller = generalLedgerFiller;
    }

    /**
     * The setter for the generalLedgerCode instance variable.
     *
     * @param generalLedgerCode the generalLedgerCode to set
     * @throws IllegalArgumentException if the length of given generalLedgerCode is not 3
     */
    public void setGeneralLedgerCode(String generalLedgerCode) {
        checkLength(3, generalLedgerCode, "generalLedgerCode");
        this.generalLedgerCode = generalLedgerCode;
    }

    /**
     * The setter for the fiscalYear instance variable.
     *
     * @param fiscalYear the fiscalYear to set
     * @throws IllegalArgumentException if the given fiscalYear is not in range (0, 9999]
     */
    public void setFiscalYear(int fiscalYear) {
        if (fiscalYear <= 0 || fiscalYear > 9999) {
            throw new IllegalArgumentException("fiscalYear should be in range (0, 9999].");
        }
        this.fiscalYear = fiscalYear;
    }

    /**
     * The setter for the accountingCode instance variable.
     *
     * @param accountingCode the accountingCode to set
     * @throws IllegalArgumentException if the accountingCode is null or empty or the length of it exceeds 20.
     */
    public void setAccountingCode(String accountingCode) {
        Helper.checkNull(accountingCode, "accountingCode");
        if (accountingCode.isEmpty() || accountingCode.length() > ACCOUNTING_CODE_MAX_LENGTH) {
            throw new IllegalArgumentException(
                "The maximum length of the field - accountingCode is 20 and it should not be null or empty.");
        }
        this.accountingCode = accountingCode;
    }

    /**
     * The setter for the receiptAmount instance variable.
     *
     * @param receiptAmount the receiptAmount to set
     * @throws IllegalArgumentException if the given receiptAmount is not a positive double number
     */
    public void setReceiptAmount(double receiptAmount) {
        if (receiptAmount <= 0) {
            throw new IllegalArgumentException("The receiptAmount must be a positive double number.");
        }
        this.receiptAmount = receiptAmount;
    }

    /**
     * The setter for the revenueSourceCode instance variable.
     *
     * @param revenueSourceCode the revenueSourceCode to set
     * @throws IllegalArgumentException if the length of given revenueSourceCode is not 4
     */
    public void setRevenueSourceCode(String revenueSourceCode) {
        checkLength(4, revenueSourceCode, "revenueSourceCode");
        this.revenueSourceCode = revenueSourceCode;
    }

    /**
     * This method is used to check the exact length of the given string.
     *
     * @param requiredLength the required length
     * @param arg the string to check
     * @param name the name of this argument
     */
    private static void checkLength(int requiredLength, String arg, String name) {
        if (arg == null || arg.length() != requiredLength) {
            throw new IllegalArgumentException("The length of the field - " + name + " must be " + requiredLength);
        }
    }

    /**
     * The getter for the feederSystemId instance variable.
     *
     * @return the feederSystemId
     */
    public String getFeederSystemId() {
        return feederSystemId;
    }

    /**
     * The getter for the paymentDate instance variable.
     *
     * @return the paymentDate
     */
    public Date getPaymentDate() {
        return paymentDate;
    }

    /**
     * The getter for the generalLedgerFiller instance variable.
     *
     * @return the generalLedgerFiller
     */
    public char getGeneralLedgerFiller() {
        return generalLedgerFiller;
    }

    /**
     * The getter for the generalLedgerCode instance variable.
     *
     * @return the generalLedgerCode
     */
    public String getGeneralLedgerCode() {
        return generalLedgerCode;
    }

    /**
     * The getter for the fiscalYear instance variable.
     *
     * @return the fiscalYear
     */
    public int getFiscalYear() {
        return fiscalYear;
    }

    /**
     * The getter for the accountingCode instance variable.
     *
     * @return the accountingCode
     */
    public String getAccountingCode() {
        return accountingCode;
    }

    /**
     * The getter for the receiptAmount instance variable.
     *
     * @return the receiptAmount
     */
    public double getReceiptAmount() {
        return receiptAmount;
    }

    /**
     * The getter for the revenueSourceCode instance variable.
     *
     * @return the revenueSourceCode
     */
    public String getRevenueSourceCode() {
        return revenueSourceCode;
    }

}
