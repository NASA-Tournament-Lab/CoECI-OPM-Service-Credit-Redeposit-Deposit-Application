/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

/**
 * This is the top-level exception. It is thrown by all methods if there is an error.
 * <p>
 * <strong>Thread Safety: </strong> This class is not thread safe because its base class is not thread safe.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class OPMException extends Exception {

    /**
     * Serial Version UID.
     */
    private static final long serialVersionUID = -7756030787082997762L;

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message the error message
     */
    public OPMException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with this error message and cause of error.
     *
     * @param message the error message
     * @param cause the underlying cause
     */
    public OPMException(String message, Throwable cause) {
        super(message, cause);
    }

}
