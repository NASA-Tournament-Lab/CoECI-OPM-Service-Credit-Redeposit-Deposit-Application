/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import java.io.InputStream;

/**
 *
 This interface defines the contract to import the Lockbox file.
 * <p>
 * <strong>Thread Safety: </strong> Implementations must be thread safe.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public interface LockboxFileService {

    /**
     * This method is used to import the Lockbox file, the file content will be read from given InputStream.
     *
     * @param inputStream the InputStream from which the Lockbox file content will be read
     * @throws IllegalArgumentException if inputStream is null.
     * @throws LockboxFileImportingException if any other error occurred during the operation
     */
    void importLockboxFile(InputStream inputStream) throws LockboxFileImportingException;
}
