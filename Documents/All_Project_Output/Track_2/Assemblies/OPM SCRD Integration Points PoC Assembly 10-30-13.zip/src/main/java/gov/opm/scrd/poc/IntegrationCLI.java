/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.poc;

import gov.opm.scrd.entities.application.GeneralLedgerRecord;
import gov.opm.scrd.services.FileAccessService;
import gov.opm.scrd.services.FileAccessServiceException;
import gov.opm.scrd.services.GeneralLedgerFileGenerationException;
import gov.opm.scrd.services.GeneralLedgerFileService;
import gov.opm.scrd.services.LockboxFileImportingException;
import gov.opm.scrd.services.LockboxFileService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.context.support.AbstractXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * <p>
 * This is the command line utility that is used to verify the external integration points in the PoC.
 * </p>
 * <p>
 * To use this command line tool, you can simply run "ant run-IntegrationCLI".
 * </p>
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class IntegrationCLI {

    /**
     * Represents the standard error output stream.
     */
    private static final PrintStream STANDARD_ERROR_OUTPUT_STREAM = System.err;

    /**
     * Represents the abnormal exit status.
     */
    private static final int ERROR_EXIT_STATUS = -1;

    /**
     * Represents the success exit status.
     */
    private static final int SUCCESS_EXIT_STATUS = 0;

    /**
     * Private empty constructor.Utility classes should not have a public or default constructor.
     */
    private IntegrationCLI() {
        // Hide constructor.
    }

    /**
     * The main entry point for this PoC command line utility.
     * 
     * @param args the arguments. We expect a single argument which is the configuration file name
     */
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        if (args == null || args.length != 1 || args[0] == null || args[0].trim().isEmpty()) {
            STANDARD_ERROR_OUTPUT_STREAM
                .println("A single non-empty argument as the path of Spring configuration file is expected.");
            System.exit(ERROR_EXIT_STATUS);
            return;
        }

        // Load application context
        AbstractXmlApplicationContext context = null;
        try {
            context = new FileSystemXmlApplicationContext(args[0].trim());
            // Load configurations
            FileAccessService fileAccessService = context.getBean(FileAccessService.class);
            LockboxFileService lockboxFileService = context.getBean(LockboxFileService.class);
            GeneralLedgerFileService generalLedgerFileService = context.getBean(GeneralLedgerFileService.class);
            String lockboxFileInputDirectory = context.getBean("lockboxFileInputDirectory", String.class);
            String lockboxInputFileName = context.getBean("lockboxInputFileName", String.class);
            String generalLedgerFileOutputDirectory =
                context.getBean("generalLedgerFileOutputDirectory", String.class);
            List<GeneralLedgerRecord> mockGeneralLedgerRecords =
                context.getBean("mockGeneralLedgerRecords", List.class);
            String generatedGLFilesSerializationFile =
                context.getBean("generatedGLFilesSerializationFile", String.class);

            // Check if the generated GL files have been picked up by Mainframe
            List<String> glFiles = checkGeneratedGLFiles(fileAccessService, generatedGLFilesSerializationFile);

            // Check if Lockbox input file exists
            String lockboxInputFile = lockboxFileInputDirectory + lockboxInputFileName;

            if (lockboxFileNotExists(fileAccessService, lockboxInputFile)) {
                // Log as ERROR
                STANDARD_ERROR_OUTPUT_STREAM.println("The Lockbox input file (" + lockboxInputFile
                    + ") does not exist.");
            } else {
                importLockboxFile(fileAccessService, lockboxFileService, lockboxInputFile);

                // Suppose we have the General Ledger records ready for output, we use mock records in the PoC
                String glOutputFile =
                    generalLedgerFileOutputDirectory + "SCGL" + new SimpleDateFormat("yyMMdd").format(new Date())
                        + ".txt";

                generateGeneralLedgerFile(fileAccessService, generalLedgerFileService, mockGeneralLedgerRecords,
                    glOutputFile);

                // Put the GL file name to the job's JobDataMap
                glFiles.add(glOutputFile);
            }
            serializeGLFile(generatedGLFilesSerializationFile, glFiles);

            System.exit(SUCCESS_EXIT_STATUS);
        } catch (BeansException e) {
            printException(e, true, "Error occurred when loading the configuration via Spring.");
        } catch (ClassCastException e) {
            printException(e, true, "Error occurred when doing the type conversion.");
        } catch (SecurityException e) {
            printException(e, true, "Security violation occurred when accessing file.");
        } finally {
            if (context != null) {
                context.close();
            }
        }
    }

    /**
     * This method is used to check the lockbox input file does not exist.
     * 
     * @param fileAccessService the file access service
     * @param lockboxInputFile the lockbox input file
     * @return true if lockbox file does not exist,otherwise return false
     */
    private static boolean lockboxFileNotExists(FileAccessService fileAccessService, String lockboxInputFile) {
        try {
            return !fileAccessService.fileExists(lockboxInputFile);
        } catch (FileAccessServiceException e) {
            printException(e, true, "Error occurred when checking the lockbox input file exists.");
        } catch (IllegalArgumentException e) {
            printException(e, true);
        }

        // never occurred. because if exception happens, application will exit by System.exit(ERROR_EXIT_STATUS)
        return true;
    }

    /**
     * This method is used to serialize GL file.
     * 
     * @param generatedGLFilesSerializationFile the generated GL files serialization file
     * @param glFiles the GL files list
     */
    private static void serializeGLFile(String generatedGLFilesSerializationFile, List<String> glFiles) {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(generatedGLFilesSerializationFile));
            try {
                oos.writeObject(glFiles);
            } finally {
                oos.close();
            }
        } catch (IOException e) {
            printException(e, true, "I/O error occurred when serializing the GL file.");
        }

    }

    /**
     * This method is used to import the lockbox input file.
     * 
     * @param fileAccessService the file access service
     * @param lockboxFileService the lockbox file service
     * @param lockboxInputFile the lockbox input file
     */
    private static void importLockboxFile(FileAccessService fileAccessService, LockboxFileService lockboxFileService,
        String lockboxInputFile) {
        try {
            // Open the file for input
            InputStream inputStream = fileAccessService.openFileForInput(lockboxInputFile);
            try {
                // Import Lockbox file
                lockboxFileService.importLockboxFile(inputStream);
            } catch (LockboxFileImportingException e) {
                // Log as ERROR
                printException(e, false, "Error occurred when importing the Lockbox file.");
            } finally {
                // Cleanup
                inputStream.close();
                fileAccessService.deleteFile(lockboxInputFile);
            }
        } catch (FileAccessServiceException e) {
            printException(e, true, "Error occurred when operating(open or delete) the lockbox input file.");
        } catch (IOException e) {
            printException(e, true, "I/O error occurred when importing the lockbox input file.");
        } catch (IllegalArgumentException e) {
            printException(e, true);
        }
    }

    /**
     * This method is used to import the lockbox input file.
     * 
     * @param fileAccessService the file access service
     * @param generalLedgerFileService the general ledger file service
     * @param mockGeneralLedgerRecords the mock general ledger records
     * @param glOutputFile the GL output file
     */
    private static void generateGeneralLedgerFile(FileAccessService fileAccessService,
        GeneralLedgerFileService generalLedgerFileService, List<GeneralLedgerRecord> mockGeneralLedgerRecords,
        String glOutputFile) { // Open the file for output
        try {
            OutputStream outputStream = fileAccessService.openFileForOutput(glOutputFile);

            try {
                // Generate General Ledger File
                generalLedgerFileService.generateGeneralLedgerFile(mockGeneralLedgerRecords, outputStream);

            } catch (GeneralLedgerFileGenerationException e) {
                // Log as ERROR
                printException(e, false, "Error occurred when generating the general ledger file.");
            } finally {
                // Cleanup
                outputStream.close();
            }
        } catch (FileAccessServiceException e) {
            printException(e, true, "Error occurred when opening file to output the general ledger file content.");
        } catch (IOException e) {
            printException(e, true, "I/O error occurred when generating the general ledger file.");
        } catch (IllegalArgumentException e) {
            printException(e, true);
        }

    }

    /**
     * This method is used to check the generated GL files.
     * 
     * @param fileAccessService the file access service
     * @param generatedGLFilesSerializationFile the generated GL files serialization file
     * @return a list of file name of the generated GL files
     */
    @SuppressWarnings("unchecked")
    private static List<String> checkGeneratedGLFiles(FileAccessService fileAccessService,
        String generatedGLFilesSerializationFile) {
        if (!new File(generatedGLFilesSerializationFile).exists()) {
            return new ArrayList<String>();
        }
        ObjectInputStream ois = null;
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(generatedGLFilesSerializationFile);
            ois = new ObjectInputStream(fis);
            List<String> glFiles = (List<String>) ois.readObject();
            for (Iterator<String> itr = glFiles.iterator(); itr.hasNext();) {
                String glFile = itr.next();
                // Consider the file hasn't been picked up if it's still present
                if (fileAccessService.fileExists(glFile)) {
                    // Log as ERROR
                    STANDARD_ERROR_OUTPUT_STREAM.println("The generated GL file(" + glFile
                        + ") hasn't been picked up by Mainframe.");
                } else {
                    // Remove it from the checking list
                    itr.remove();
                }
            }
            return glFiles;

        } catch (IOException e) {
            printException(e, true, "I/O error occurred when reading the serialized object.");
        } catch (FileAccessServiceException e) {
            printException(e, true, "Error occurred when checking the GL file exists.");
        } catch (ClassNotFoundException e) {
            printException(e, true, "Class of a serialized object cannot be found.");
        } catch (IllegalArgumentException e) {
            printException(e, true);
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException e) {
                printException(e, true, "I/O error occurred when closing the stream.");
            }
        }

        // never occurred. because if exception happens, application will exit by System.exit(ERROR_EXIT_STATUS)
        return null;
    }

    /**
     * This method is used to print the exception message and the exception stack.
     * 
     * @param additionalErrorMessage the additional error message
     * @param exception the exception to print
     * @param abnormalExit the flag to indicate whether the external integration points verifying exits abnormally
     */
    private static void printException(Exception exception, boolean abnormalExit, String... additionalErrorMessage) {
        if (additionalErrorMessage != null) {
            STANDARD_ERROR_OUTPUT_STREAM.println(additionalErrorMessage[0]);
        }
        exception.printStackTrace(STANDARD_ERROR_OUTPUT_STREAM);
        if (abnormalExit) {
            STANDARD_ERROR_OUTPUT_STREAM.println("The verifying process is aborted abnormally.");
            System.exit(ERROR_EXIT_STATUS);
        }
    }
}
