/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

/**
 * Helper class for services.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public final class Helper {

    /**
     * The default charset name for encoding the String or input stream.
     */
    static final String DEFAULT_CHARSET_NAME = "UTF-8";

    /**
     * The Line separator.
     */
    static final String LINE_SEPARATOR = System.getProperty("line.separator");

    /**
     * Private empty constructor.
     */
    private Helper() {
        // Hide constructor.
    }

    /**
     * <p>
     * Checks whether the given Object is null.
     * </p>
     *
     * @param arg the argument to check
     * @param name the name of the argument to check
     * @throws IllegalArgumentException if the given Object is null
     */
    public static void checkNull(Object arg, String name) {
        if (arg == null) {
            throw new IllegalArgumentException(name + " should not be null.");
        }
    }

    /**
     * <p>
     * Checks whether the given String is null or empty.
     * </p>
     *
     * @param arg the String to check
     * @param name the name of the String argument to check
     * @return the trimmed string
     * @throws IllegalArgumentException if the given string is null or empty
     */
    public static String checkStringNullOrEmpty(String arg, String name) {
        checkNull(arg, name);
        String result = arg.trim();
        if (result.isEmpty()) {
            throw new IllegalArgumentException(name + " should not be empty.");
        }
        return result;
    }
}
