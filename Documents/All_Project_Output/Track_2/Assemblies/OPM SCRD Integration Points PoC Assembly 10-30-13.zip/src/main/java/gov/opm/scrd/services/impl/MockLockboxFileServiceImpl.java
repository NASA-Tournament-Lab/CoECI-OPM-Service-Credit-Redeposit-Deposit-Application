/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import gov.opm.scrd.services.LockboxFileImportingException;
import gov.opm.scrd.services.LockboxFileService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * <p>
 * This is the mock implementation of LockboxFileService.
 * </p>
 * <p>
 * NOTE that this is a mock implementation, thus can NOT be used in production, it is used in PoC ONLY.
 * </p>
 * <p>
 * <strong>Thread Safety: </strong> This class is thread safe since it's immutable.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class MockLockboxFileServiceImpl implements LockboxFileService {

    /**
     * Represents the record type error template.
     */
    private static final String RECORD_TYPE_ERROR_TEMPLATE = "Line #%s : Record must start with 'R6', 'C ' or 'R '.";

    /**
     * Represents the change field error template.
     */
    private static final String IDENTIFIER_ERROR_TEMPLATE =
        "Line #%s : Data element 'Identifier' at position [3 - 17] must be 'ZZZ     ZZZZZZZ'.";

    /**
     * Represents the change field regex.
     */
    private static final String CHANGE_FIELD_REGEX = "[a-zA-Z0-9]{24}";

    /**
     * Represents the change field error template.
     */
    private static final String CHANGE_FIELD_ERROR_TEMPLATE =
        "Line #%s : Data element 'Change Field' at position [24 - 47] must be 24 alphanumeric characters.";

    /**
     * Represents the regular expression for flag - 0 or 1.
     */
    private static final String FLAG_REGEX = "0|1";

    /**
     * Represents the flag error template.
     */
    private static final String FLAG_ERROR_TEMPLATE = "Line #%s : Data element 'ACH' at position 38 must be 0 or 1.";

    /**
     * Represents the date format regex.
     */
    private static final String DATE_FORMAT_PATTERN = "MMddyy";

    /**
     * Represents the space count regex template.
     */
    private static final String SPACE_COUNT_REGEX_TEMPLATE = " {%s}";

    /**
     * Represents the space count error template.
     */
    private static final String SPACE_COUNT_ERROR_TEMPLATE = "Line #%s : Data element '%s' at position %s must be %s";

    /**
     * Represents the digit count regex template.
     */
    private static final String DIGIT_COUNT_REGEX_TEMPLATE = "\\d{%s}";

    /**
     * Represents the digit count error template.
     */
    private static final String DIGIT_COUNT_ERROR_TEMPLATE = "Line #%s : Data element '%s' at position %s must be %s";

    /**
     * Represents the DB field to change error template.
     */
    private static final String DB_FIELD_TO_CHANGE_ERROR_TEMPLATE =
        "Line #%s : Data element 'Database Field to Change' at position [3 - 4] must be in range of [02, 99].";

    /**
     * Represents the date error template.
     */
    private static final String DATE_ERROR_TEMPLATE =
        "Line #%s : Data element '%s'- (%s) at position %s must match the date pattern '" + DATE_FORMAT_PATTERN
            + "'.";

    /**
     * Represents the error template for no 80 characters of one line.
     */
    private static final String NO_80_CHARACTERS_EERROR_TEMPLATE =
        "Line #%s : Each line should consist of exactly 80 bytes(characters), current line just has %s.";

    /**
     * Default empty constructor.
     */
    public MockLockboxFileServiceImpl() {
        // empty
    }

    /**
     * <p>
     * This method is used to import the Lockbox file, the file content will be read from given InputStream.
     * </p>
     * <p>
     * This method will parse lines of the file and throw LockboxFileImportingException if the file isn't in
     * correct format.
     * </p>
     *
     * @param inputStream the InputStream from which the Lockbox file content will be read
     * @throws IllegalArgumentException if inputStream is null.
     * @throws LockboxFileImportingException if any other error occurred during the operation
     */
    @Override
    public void importLockboxFile(InputStream inputStream) throws LockboxFileImportingException {
        Helper.checkNull(inputStream, "inputStream");
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_PATTERN);
        try {
            BufferedReader reader =
                new BufferedReader(new InputStreamReader(inputStream, Helper.DEFAULT_CHARSET_NAME));

            // Read the file
            String line = null;
            StringBuilder errors = new StringBuilder();
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                // Each line should consist of exactly 80 bytes(characters)
                if (line.length() != 80) {
                    errors.append(String.format(NO_80_CHARACTERS_EERROR_TEMPLATE, lineNumber, line.length()));
                    errors.append(Helper.LINE_SEPARATOR);
                    continue;
                }

                if (line.startsWith("R6")) {
                    processR6Line(lineNumber, line, errors, dateFormat);
                    continue;
                }
                if (line.startsWith("C ")) {
                    processCLine(lineNumber, line, errors, dateFormat);
                    continue;
                }
                if (line.startsWith("R ")) {
                    processRLine(lineNumber, line, errors, dateFormat);
                    continue;
                }
                errors.append(String.format(RECORD_TYPE_ERROR_TEMPLATE, lineNumber));
                errors.append(Helper.LINE_SEPARATOR);
            }

            if (errors.length() > 0) {
                throw new LockboxFileImportingException("The Lockbox file content has following errors: "
                    + Helper.LINE_SEPARATOR + errors.toString().trim());
            }
        } catch (UnsupportedEncodingException e) {
            throw new LockboxFileImportingException("The charset(" + Helper.DEFAULT_CHARSET_NAME
                + ") is not supported.", e);
        } catch (IOException e) {
            throw new LockboxFileImportingException("I/O error occurred when reading a line from the input stream.",
                e);
        }
    }

    /**
     * This method is used to process the R6 line.
     *
     * @param lineNumber the line number
     * @param line the line to process
     * @param errors the errors
     * @param dateFormat the date format
     */
    private static void processR6Line(int lineNumber, String line, StringBuilder errors, SimpleDateFormat dateFormat) {

        // no need to check type
        
        String batch = line.substring(2, 5);
        checkDigitCount(lineNumber, batch, "Batch", "[3 - 5]", 3, errors);

        String block = line.substring(5, 7);
        checkDigitCount(lineNumber, block, "Block", "[6 - 7]", 2, errors);

        String sequence = line.substring(7, 9);
        checkDigitCount(lineNumber, sequence, "Sequence", "[8 - 9]", 2, errors);

        String filler1 = line.substring(9, 10);
        checkSpaceCount(lineNumber, filler1, "Filler", "10", 1, errors);

        String claimNumber = line.substring(10, 17);
        checkDigitCount(lineNumber, claimNumber, "Claim Number", "[11 - 17]", 7, errors);

        String dateOfBirth = line.substring(17, 23);
        checkDateFormat(lineNumber, dateOfBirth, "Date of Birth", "[18 - 23]", dateFormat, errors);

        String paymentAmount = line.substring(23, 30);
        checkDigitCount(lineNumber, paymentAmount, "Payment Amount", "[24 - 30]", 7, errors);

        String paymentDate = line.substring(30, 36);
        checkDateFormat(lineNumber, paymentDate, "Payment Date", "[31 - 36]", dateFormat, errors);

        String filler2 = line.substring(36, 37);
        checkSpaceCount(lineNumber, filler2, "Filler", "37", 1, errors);

        String achFlag = line.substring(37, 38);
        if (!achFlag.matches(FLAG_REGEX)) {
            errors.append(String.format(FLAG_ERROR_TEMPLATE, lineNumber));
            errors.append(Helper.LINE_SEPARATOR);
        }

        String filler3 = line.substring(38);
        checkSpaceCount(lineNumber, filler3, "Filler", "[39 - 80]", 42, errors);
    }

    /**
     * This method is used to process the C line.
     *
     * @param lineNumber the line number
     * @param line the line to process
     * @param errors the errors
     * @param dateFormat the date format
     */
    private static void processCLine(int lineNumber, String line, StringBuilder errors, SimpleDateFormat dateFormat) {
        // no need to check type
        String dbFieldToChange = line.substring(2, 4);
        if ((!dbFieldToChange.matches(String.format(DIGIT_COUNT_REGEX_TEMPLATE, 2))) || dbFieldToChange.equals("00")
            || dbFieldToChange.equals("01")) {

            errors.append(String.format(DB_FIELD_TO_CHANGE_ERROR_TEMPLATE, lineNumber));
            errors.append(Helper.LINE_SEPARATOR);
        }
        String filler1 = line.substring(4, 10);
        checkSpaceCount(lineNumber, filler1, "Filler", "[5 - 10]", 6, errors);

        String claimNumber = line.substring(10, 17);
        checkDigitCount(lineNumber, claimNumber, "Claim Number", "[11 - 17]", 7, errors);

        String dateOfBirth = line.substring(17, 23);
        checkDateFormat(lineNumber, dateOfBirth, "Date of Birth", "[18 - 23]", dateFormat, errors);

        String changeField = line.substring(23, 47);
        if (!changeField.matches(CHANGE_FIELD_REGEX)) {
            errors.append(String.format(CHANGE_FIELD_ERROR_TEMPLATE, lineNumber));
            errors.append(Helper.LINE_SEPARATOR);
        }

        String filler2 = line.substring(47);
        checkSpaceCount(lineNumber, filler2, "Filler", "[48 - 80]", 33, errors);

    }

    /**
     * This method is used to process the R line.
     *
     * @param lineNumber the line number
     * @param line the line to process
     * @param errors the errors
     * @param dateFormat the date format
     */
    private static void processRLine(int lineNumber, String line, StringBuilder errors, SimpleDateFormat dateFormat) {
        // no need to check type
        String identifier = line.substring(2, 17);
        if (!"ZZZ     ZZZZZZZ".equals(identifier)) {
            errors.append(String.format(IDENTIFIER_ERROR_TEMPLATE, lineNumber));
            errors.append(Helper.LINE_SEPARATOR);
        }
        String subtotal = line.substring(17, 27);
        checkDigitCount(lineNumber, subtotal, "Subtotal", "[18 - 27]", 10, errors);

        String filler = line.substring(27);
        checkSpaceCount(lineNumber, filler, "Filler", "[28 - 80]", 53, errors);

    }

    /**
     * This method is used to check date format.
     *
     * @param lineNumber the line number
     * @param arg the argument to check
     * @param argName the argument name
     * @param position the data element position
     * @param dateFormat the date format
     * @param errors the errors String builder
     */
    private static void checkDateFormat(int lineNumber, String arg, String argName, String position,
        SimpleDateFormat dateFormat, StringBuilder errors) {
        try {
            dateFormat.setLenient(false);
            dateFormat.parse(arg);
        } catch (ParseException e) {
            errors.append(String.format(DATE_ERROR_TEMPLATE, lineNumber, argName, arg, position));
            errors.append(Helper.LINE_SEPARATOR);
        }
    }

    /**
     * This method is used to check digit count.
     *
     * @param lineNumber the line number
     * @param arg the argument to check
     * @param argName the argument name
     * @param position the data element position
     * @param count the digit count
     * @param errors the errors String builder
     */
    private static void checkDigitCount(int lineNumber, String arg, String argName, String position, int count,
        StringBuilder errors) {
        if (!arg.matches(String.format(DIGIT_COUNT_REGEX_TEMPLATE, count))) {
            errors.append(String.format(DIGIT_COUNT_ERROR_TEMPLATE, lineNumber, argName, position, (count == 1
                ? "1 digit." : (count + " digits."))));
            errors.append(Helper.LINE_SEPARATOR);
        }
    }

    /**
     * This method is used to check space count.
     *
     * @param lineNumber the line number
     * @param arg the argument to check
     * @param argName the argument name
     * @param position the data element position
     * @param count the space count
     * @param errors the errors String builder
     */
    private static void checkSpaceCount(int lineNumber, String arg, String argName, String position, int count,
        StringBuilder errors) {
        if (!arg.matches(String.format(SPACE_COUNT_REGEX_TEMPLATE, count))) {
            errors.append(String.format(SPACE_COUNT_ERROR_TEMPLATE, lineNumber, argName, position, (count == 1
                ? "1 space." : (count + " spaces."))));
            errors.append(Helper.LINE_SEPARATOR);
        }
    }
}
