/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

/**
 * This exception will be thrown by FileAccessService to indicate errors that occurred while accessing files.
 * <p>
 * <strong>Thread Safety: </strong> This class is not thread safe because its base class is not thread safe.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class FileAccessServiceException extends OPMException {

    /**
     * Serial Version UID.
     */
    private static final long serialVersionUID = 7688129073475748206L;

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message the error message
     */
    public FileAccessServiceException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with this error message and cause of error.
     *
     * @param message the error message
     * @param cause the underlying cause
     */
    public FileAccessServiceException(String message, Throwable cause) {
        super(message, cause);
    }

}
