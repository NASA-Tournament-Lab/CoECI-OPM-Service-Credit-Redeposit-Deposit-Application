/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import gov.opm.scrd.entities.application.GeneralLedgerRecord;
import gov.opm.scrd.services.GeneralLedgerFileGenerationException;
import gov.opm.scrd.services.GeneralLedgerFileService;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * This is the default implementation of GeneralLedgerFileService.
 * </p>
 * <p>
 * NOTE that this is not a mock implementation, thus can be used in both PoC and the production.
 * </p>
 * <p>
 * <strong>Thread Safety: </strong> This class is thread safe since it's immutable.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class GeneralLedgerFileServiceImpl implements GeneralLedgerFileService {

    /**
     * Default empty constructor.
     */
    public GeneralLedgerFileServiceImpl() {
        // empty
    }

    /**
     * This method is used to generate a General Ledger file (GL file) based on given General Ledger records, the
     * file content will be written to given OutputStream.
     *
     * @param records the General Ledger records.
     * @param outputStream the OutputStream to which the GL file content will be written
     * @throws IllegalArgumentException if records is null or empty, or any item in records is null, or
     *             outputStream is null or GeneralLedgerRecord is not fully initialized.
     * @throws GeneralLedgerFileGenerationException if any other error occurred during the operation
     */
    @Override
    public void generateGeneralLedgerFile(List<GeneralLedgerRecord> records, OutputStream outputStream)
        throws GeneralLedgerFileGenerationException {
        Helper.checkNull(outputStream, "outputStream");
        Helper.checkNull(records, "records");
        if (records.isEmpty()) {
            throw new IllegalArgumentException("The records list should not be empty.");
        }
        for (GeneralLedgerRecord generalLedgerRecord : records) {
            Helper.checkNull(generalLedgerRecord, "The item of the given records list");
            Helper.checkNull(generalLedgerRecord.getAccountingCode(),
                "GeneralLedgerRecord is not fully initialized.The accountingCode");
            if (generalLedgerRecord.getFiscalYear() == 0) {
                throw new IllegalArgumentException(
                    "GeneralLedgerRecord is not fully initialized.The fiscalYear should not be 0.");
            }
            Helper.checkNull(generalLedgerRecord.getFeederSystemId(),
                "GeneralLedgerRecord is not fully initialized.The feederSystemId");
            Helper.checkNull(generalLedgerRecord.getGeneralLedgerCode(),
                "GeneralLedgerRecord is not fully initialized.The generalLedgerCode");
            Helper.checkNull(generalLedgerRecord.getPaymentDate(),
                "GeneralLedgerRecord is not fully initialized.The paymentDate");
            if (generalLedgerRecord.getReceiptAmount() == 0) {
                throw new IllegalArgumentException(
                    "GeneralLedgerRecord is not fully initialized.The receiptAmount should not be 0.");
            }
            Helper.checkNull(generalLedgerRecord.getRevenueSourceCode(),
                "GeneralLedgerRecord is not fully initialized.The revenueSourceCode");

        }
        try {
            SimpleDateFormat julianFormat = new SimpleDateFormat("yyyyDDD");
            // Create a buffered stream
            OutputStream bos = new BufferedOutputStream(outputStream);
            // Iterate the General Ledger records to
            int lastRecordIndex = records.size() - 1;
            for (int i = 0; i < records.size(); i++) {
                GeneralLedgerRecord record = records.get(i);

                StringBuilder sb = new StringBuilder();
                // Feeder System ID (4 bytes)
                sb.append(record.getFeederSystemId());
                // Payment Date in Julian Date format (7 bytes)
                sb.append(julianFormat.format(record.getPaymentDate()));
                // Record Number (3 bytes Julian Date, 1 byte filler)
                // substring from 4-th character because the julianFormat uses 4 characters for year part
                sb.append(julianFormat.format(new Date()).substring(4));
                sb.append(record.getGeneralLedgerFiller());

                // General Ledger Code (3 bytes)
                sb.append(record.getGeneralLedgerCode());
                if (record.getFiscalYear() < 1000) {
                    // Accounting Code (padding to 20 bytes)
                    sb.append(String.format("%1$-20s", record.getAccountingCode()));
                } else {
                    // Fiscal Year (2 bytes)
                    sb.append(String.valueOf(record.getFiscalYear()).substring(2));
                    // Blanks (2 bytes)
                    sb.append(String.format("%1$-2s", ""));

                    if (record.getAccountingCode().length() <= 16) {
                        // Accounting Code (padding to 16 bytes)
                        sb.append(String.format("%1$-16s", record.getAccountingCode()));
                    } else {
                        sb.append(record.getAccountingCode().substring(0, 16));
                    }

                }
                // Amount of the Receipt (15 bytes - 13 significant)
                sb.append(String.format("%015d", (int) (record.getReceiptAmount() * 100)));
                // Revenue Source Code (4 bytes)
                sb.append(record.getRevenueSourceCode());
                // Blanks (28 bytes)
                sb.append(String.format("%1$-28s", ""));

                if (i != lastRecordIndex) {
                    sb.append(Helper.LINE_SEPARATOR);
                }

                // Write to the output stream
                bos.write(sb.toString().getBytes(Helper.DEFAULT_CHARSET_NAME));
            }
            bos.flush();
        } catch (UnsupportedEncodingException e) {
            throw new GeneralLedgerFileGenerationException("The charset(" + Helper.DEFAULT_CHARSET_NAME
                + ") is not supported.", e);
        } catch (IOException e) {
            throw new GeneralLedgerFileGenerationException(
                "Error occurred when writting the content to OutputStream.", e);
        }

    }
}
