/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.GeneralLedgerRecord;

import java.io.OutputStream;
import java.util.List;

/**
 * This interface defines the contract to generate a General Ledger file (GL file) based on given General Ledger
 * records, the file content will be written to given OutputStream.
 * <p>
 * <strong>Thread Safety: </strong> Implementations must be thread safe.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public interface GeneralLedgerFileService {

    /**
     * This method is used to generate a General Ledger file (GL file) based on given General Ledger records, the
     * file content will be written to given OutputStream.
     *
     * @param records the General Ledger records.
     * @param outputStream the OutputStream to which the GL file content will be written
     * @throws IllegalArgumentException if records is null or empty, or any item in records is null, or
     *             outputStream is null or GeneralLedgerRecord is not fully initialized.
     * @throws GeneralLedgerFileGenerationException if any other error occurred during the operation
     */
    void generateGeneralLedgerFile(List<GeneralLedgerRecord> records, OutputStream outputStream)
        throws GeneralLedgerFileGenerationException;
}
