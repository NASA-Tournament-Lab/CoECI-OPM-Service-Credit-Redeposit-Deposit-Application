/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

/**
 * This exception will be thrown by GeneralLedgerFileService to indicate errors that occurred while generating
 * General Ledger file.
 * <p>
 * <strong>Thread Safety: </strong> This class is not thread safe because its base class is not thread safe.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 */
public class GeneralLedgerFileGenerationException extends OPMException {

    /**
     * Serial Version UID.
     */
    private static final long serialVersionUID = 7338533673374732172L;

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message the error message
     */
    public GeneralLedgerFileGenerationException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with this error message and cause of error.
     *
     * @param message the error message
     * @param cause the underlying cause
     */
    public GeneralLedgerFileGenerationException(String message, Throwable cause) {
        super(message, cause);
    }
}
