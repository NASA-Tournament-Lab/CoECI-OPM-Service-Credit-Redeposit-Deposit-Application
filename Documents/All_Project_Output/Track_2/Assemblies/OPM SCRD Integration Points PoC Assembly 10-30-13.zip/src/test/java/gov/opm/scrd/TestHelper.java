/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;

import jcifs.smb.SmbFile;

/**
 * Test Helper.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public final class TestHelper {

    /**
     * The Line separator.
     */
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");

    /**
     * Represents the buffer size.
     */
    private static final int BUFFER_SIZE = 1024;

    /**
     * Private empty constructor.
     */
    private TestHelper() {
        // Hide constructor.
    }

    /**
     * Reads the content of the file.
     *
     * @param filePath the file path
     * @return The content of file
     * @throws IOException if any exception occurs
     */
    public static String readFileContent(String filePath) throws IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        try {
            // Buffer for reading
            char[] buffer = new char[BUFFER_SIZE];
            // Number of read chars
            int num = 0;

            // Read characters and append to string builder
            while ((num = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, num);
            }

            // Return the content
            return sb.toString();
        } finally {
            reader.close();
        }
    }

    /**
     * Reads the content of the file from given input stream.
     *
     * @param fileInputStream the file input stream
     * @return The content of file
     * @throws IOException if any exception occurs
     */
    public static String readFileContent(InputStream fileInputStream) throws IOException {
        StringBuilder sb = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));
        try {
            // Buffer for reading
            char[] buffer = new char[BUFFER_SIZE];
            // Number of read chars
            int num = 0;

            // Read characters and append to string builder
            while ((num = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, num);
            }

            // Return the content
            return sb.toString();
        } finally {
            reader.close();
        }
    }

    /**
     * Removes the local file.
     *
     * @param filePath the local file path
     * @throws IOException if any exception occurs
     */
    public static void removeLocalFile(String filePath) throws IOException {
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }
    }

    /**
     * Removes the SMB file on the CIFS/SMB file server.
     *
     * @param smbFileUrl the SMB file url
     * @throws IOException if any exception occurs
     */
    public static void removeSmbFile(String smbFileUrl) throws IOException {
        SmbFile file = new SmbFile(smbFileUrl);
        if (file.exists()) {
            file.delete();
        }
    }

    /**
     * Creates the local file.
     *
     * @param filePath the local file path
     * @throws IOException if any exception occurs
     */
    public static void createLocalFile(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            file.createNewFile();
        }
    }

    /**
     * Creates the SMB file on the CIFS/SMB file server.
     *
     * @param smbFileUrl the SMB file url
     * @throws IOException if any exception occurs
     */
    public static void createSmbFile(String smbFileUrl) throws IOException {
        SmbFile file = new SmbFile(smbFileUrl);
        if (!file.exists()) {
            file.createNewFile();
        }
    }

    /**
     * Writes the content to the local file.
     *
     * @param filePath the local file path
     * @param fileContent the file content
     * @throws IOException if any exception occurs
     */
    public static void writeLocalFileContent(String filePath, String fileContent) throws IOException {
        File fileDir = new File(filePath).getParentFile();
        if (!fileDir.exists()) {
            fileDir.mkdirs();
        }
        Writer output = new BufferedWriter(new FileWriter(filePath));
        try {
            output.write(fileContent);
        } finally {
            output.close();
        }
    }

    /**
     * Writes the content to the SMB file.
     *
     * @param smbFileUrl the SMB file url
     * @param fileContent the file content
     * @throws IOException if any exception occurs
     */
    public static void writeSmbFileContent(String smbFileUrl, String fileContent) throws IOException {
        SmbFile smbFile = new SmbFile(smbFileUrl);
        if (!smbFile.exists()) {
            smbFile.createNewFile();

        }
        OutputStream os = smbFile.getOutputStream();
        try {
            os.write(fileContent.getBytes());
        } finally {
            os.close();
        }
    }

}
