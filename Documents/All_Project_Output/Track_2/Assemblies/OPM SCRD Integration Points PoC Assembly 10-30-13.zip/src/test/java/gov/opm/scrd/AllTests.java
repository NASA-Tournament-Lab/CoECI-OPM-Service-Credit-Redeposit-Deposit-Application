/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import gov.opm.scrd.poc.IntegrationCLITests;
import gov.opm.scrd.services.impl.FileAccessServiceImplTests;
import gov.opm.scrd.services.impl.GeneralLedgerFileServiceImplTests;
import gov.opm.scrd.services.impl.MockLockboxFileServiceImplTests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * This test case aggregates all the test cases.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
@SuiteClasses({ IntegrationCLITests.class, FileAccessServiceImplTests.class, GeneralLedgerFileServiceImplTests.class,
    MockLockboxFileServiceImplTests.class })
@RunWith(Suite.class)
public class AllTests {
    // empty
}
