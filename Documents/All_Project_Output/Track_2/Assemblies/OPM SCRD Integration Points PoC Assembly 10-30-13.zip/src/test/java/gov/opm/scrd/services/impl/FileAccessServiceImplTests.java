/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import gov.opm.scrd.TestHelper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.Properties;

import jcifs.smb.SmbFile;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test cases for {@link FileAccessServiceImpl}.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class FileAccessServiceImplTests {

    /**
     * Represents the local temporary test file.
     */
    private static final String LOCAL_TEMP_TEST_FILE = "test_files" + File.separator + "temp.txt";

    /**
     * Represents the temporary test file URL on CIFS/SMB file server.
     */
    private static String SMB_TEMP_TEST_FILE;

    /**
     * Initialize the configuration.
     */
    static {

        try {
            Reader reader = new BufferedReader(new InputStreamReader(new FileInputStream("build.properties")));
            try {
                Properties properties = new Properties();
                properties.load(reader);
                SMB_TEMP_TEST_FILE = properties.getProperty("smb.file.server.url") + File.separator + "temp.txt";
            } finally {
                reader.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Represents {@link FileAccessServiceImpl} instance for testing.
     */
    private FileAccessServiceImpl instance;

    /**
     * Sets up the test environment.
     *
     * @throws Exception to JUnit
     */
    @Before
    public void setUp() throws Exception {
        instance = new FileAccessServiceImpl();
    }

    /**
     * Tears down the test environment.
     *
     * @throws Exception to JUnit
     */
    @After
    public void tearDown() throws Exception {
        TestHelper.removeLocalFile(LOCAL_TEMP_TEST_FILE);
        TestHelper.removeSmbFile(SMB_TEMP_TEST_FILE);
    }

    /**
     * Test for {@link FileAccessServiceImpl#fileExists}.It is for local file system.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_fileExists_local() throws Exception {
        assertFalse("Local temp test file should not exist.", instance.fileExists(LOCAL_TEMP_TEST_FILE));
        new File(LOCAL_TEMP_TEST_FILE).createNewFile();
        assertTrue("Local temp test file should exist.", instance.fileExists(LOCAL_TEMP_TEST_FILE));
    }

    /**
     * Test for {@link FileAccessServiceImpl#fileExists}.It is for CIFS/SMB file server.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_fileExists_smb() throws Exception {

        assertFalse("SMB temp test file should not exist.", instance.fileExists(SMB_TEMP_TEST_FILE));
        new SmbFile(SMB_TEMP_TEST_FILE).createNewFile();
        assertTrue("SMB temp test file should exist.", instance.fileExists(SMB_TEMP_TEST_FILE));

    }

    /**
     * Test for {@link FileAccessServiceImpl#openFileForInput}.It is for local file system.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_openFileForInput_local() throws Exception {
        String testString = "test content";
        TestHelper.writeLocalFileContent(LOCAL_TEMP_TEST_FILE, testString);
        assertEquals("Local temp test file content should be 'test content'.", testString,
            TestHelper.readFileContent(instance.openFileForInput(LOCAL_TEMP_TEST_FILE)));
    }

    /**
     * Test for {@link FileAccessServiceImpl#openFileForInput}.It is for CIFS/SMB file server.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_openFileForInput_smb() throws Exception {
        String testString = "test content";
        TestHelper.writeSmbFileContent(SMB_TEMP_TEST_FILE, testString);
        assertEquals("SMB temp test file content should be 'test content'.", testString,
            TestHelper.readFileContent(instance.openFileForInput(SMB_TEMP_TEST_FILE)));
    }

    /**
     * Test for {@link FileAccessServiceImpl#openFileForOutput}.It is for local file system.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_openFileForOutput_local() throws Exception {
        String testString = "testtest";
        OutputStream os = instance.openFileForOutput(LOCAL_TEMP_TEST_FILE);
        try {
            os.write(testString.getBytes());
        } finally {
            os.close();
        }

        assertEquals("Local file content should be 'testtest'.", testString,
            TestHelper.readFileContent(LOCAL_TEMP_TEST_FILE));
    }

    /**
     * Test for {@link FileAccessServiceImpl#openFileForOutput}.It is for CIFS/SMB file server.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_openFileForOutput_smb() throws Exception {
        String testString = "testtest";
        OutputStream os = instance.openFileForOutput(SMB_TEMP_TEST_FILE);
        try {
            os.write(testString.getBytes());
        } finally {
            os.close();
        }
        assertEquals("SMB file content should be 'testtest'.", testString,
            TestHelper.readFileContent(new SmbFile(SMB_TEMP_TEST_FILE).getInputStream()));
    }

    /**
     * Test for {@link FileAccessServiceImpl#deleteFile}.It is for local file system.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_deleteFile_local() throws Exception {
        TestHelper.createLocalFile(LOCAL_TEMP_TEST_FILE);
        assertTrue("Local temp test file should exist.", new File(LOCAL_TEMP_TEST_FILE).exists());
        instance.deleteFile(LOCAL_TEMP_TEST_FILE);
        assertFalse("Local temp test file should not exist.", new File(LOCAL_TEMP_TEST_FILE).exists());
    }

    /**
     * Test for {@link FileAccessServiceImpl#deleteFile}.It is for CIFS/SMB file server.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_deleteFile_smb() throws Exception {
        TestHelper.createSmbFile(SMB_TEMP_TEST_FILE);
        assertTrue("SMB temp test file should exist.", new SmbFile(SMB_TEMP_TEST_FILE).exists());
        instance.deleteFile(SMB_TEMP_TEST_FILE);
        assertFalse("SMB temp test file should not exist.", new SmbFile(SMB_TEMP_TEST_FILE).exists());
    }

}
