/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import gov.opm.scrd.TestHelper;
import gov.opm.scrd.entities.application.GeneralLedgerRecord;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test cases for {@link GeneralLedgerFileServiceImpl}.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class GeneralLedgerFileServiceImplTests {

    /**
     * Represents the date format.
     */
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyDDD");

    /**
     * In this GeneralLedgerRecord, fiscalYear<1000.
     */
    private static String EXPECTED_RECORD_1_CONTENT;

    /**
     * In this GeneralLedgerRecord, fiscalYear>1000.
     */
    private static String EXPECTED_RECORD_2_CONTENT;

    /**
     * In this GeneralLedgerRecord, fiscalYear>1000 and the length of the accountingCode exceeds 16.
     */
    private static String EXPECTED_RECORD_3_CONTENT;

    /**
     * Initialize the expected record content.
     */
    static {
        EXPECTED_RECORD_1_CONTENT =
            "SCBS2013123" + DATE_FORMAT.format(new Date()).substring(4)
                + "FGLCAVCS                000000000010000RSC1                            ";

        EXPECTED_RECORD_2_CONTENT =
            "SCBS2013121" + DATE_FORMAT.format(new Date()).substring(4)
                + " GLC00  AVCS            000000000002323RSC1                            ";

        EXPECTED_RECORD_3_CONTENT =
            "SCBS2013121" + DATE_FORMAT.format(new Date()).substring(4)
                + " GLC00  0123456789012345000000000002323RSC1                            ";
    }

    /**
     * Represents {@link GeneralLedgerFileServiceImpl} instance for testing.
     */
    private GeneralLedgerFileServiceImpl instance;

    /**
     * Sets up the test environment.
     *
     * @throws Exception to JUnit
     */
    @Before
    public void setUp() throws Exception {
        instance = new GeneralLedgerFileServiceImpl();
    }

    /**
     * Tears down the test environment.
     *
     * @throws Exception to JUnit
     */
    @After
    public void tearDown() throws Exception {
        instance = null;
    }

    /**
     * Test for {@link GeneralLedgerFileServiceImpl#generateGeneralLedgerFile}.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_generateGeneralLedgerFile() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            List<GeneralLedgerRecord> generalLedgerRecords = new ArrayList<GeneralLedgerRecord>();

            // fiscalYear<1000
            generalLedgerRecords.add(createRecord(300, 100, 'F', "2013123", "AVCS"));

            // fiscalYear>1000
            generalLedgerRecords.add(createRecord(3000, 23.23, ' ', "2013121", "AVCS"));

            // fiscalYear>1000 and the length of the accountingCode exceeds 16, the last 66 should be truncated.
            generalLedgerRecords.add(createRecord(3000, 23.23, ' ', "2013121", "012345678901234566"));

            instance.generateGeneralLedgerFile(generalLedgerRecords, baos);
            String generalLedgerFileContent = baos.toString();
            String[] generalLedgerFileContentLines = generalLedgerFileContent.split(TestHelper.LINE_SEPARATOR);

            assertTrue("It should have two records.", generalLedgerFileContentLines.length == 3);

            assertTrue("The length of the record 1 line must be 85.", generalLedgerFileContentLines[0].length() == 85);
            assertEquals("The content of record 1 is incorrect.", EXPECTED_RECORD_1_CONTENT,
                generalLedgerFileContentLines[0]);

            assertTrue("The length of the record 2 line must be 85.", generalLedgerFileContentLines[1].length() == 85);
            assertEquals("The content of record 2 is incorrect.", EXPECTED_RECORD_2_CONTENT,
                generalLedgerFileContentLines[1]);

            assertTrue("The length of the record 3 line must be 85.", generalLedgerFileContentLines[2].length() == 85);
            assertEquals("The content of record 3 is incorrect.", EXPECTED_RECORD_3_CONTENT,
                generalLedgerFileContentLines[2]);

        } finally {
            baos.close();
        }
    }

    /**
     * This method is used to create the GeneralLedgerRecord for testing purpose.
     *
     * @param fiscalYear the fiscal year
     * @param receiptAmount the receipt amount
     * @param generalLedgerFiller the GeneralLedgerRecord instance
     * @param paymentDate the payment date
     * @param accountingCode the accounting code
     * @return created GeneralLedgerRecord instance
     * @throws Exception to JUnit
     */
    private static GeneralLedgerRecord createRecord(int fiscalYear, double receiptAmount, char generalLedgerFiller,
        String paymentDate, String accountingCode) throws Exception {
        GeneralLedgerRecord generalLedgerRecord = new GeneralLedgerRecord();
        generalLedgerRecord.setAccountingCode(accountingCode);
        generalLedgerRecord.setFeederSystemId("SCBS");
        generalLedgerRecord.setFiscalYear(fiscalYear);
        generalLedgerRecord.setGeneralLedgerCode("GLC");
        generalLedgerRecord.setGeneralLedgerFiller(generalLedgerFiller);
        generalLedgerRecord.setPaymentDate(DATE_FORMAT.parse(paymentDate));
        generalLedgerRecord.setReceiptAmount(receiptAmount);
        generalLedgerRecord.setRevenueSourceCode("RSC1");
        return generalLedgerRecord;
    }

}
