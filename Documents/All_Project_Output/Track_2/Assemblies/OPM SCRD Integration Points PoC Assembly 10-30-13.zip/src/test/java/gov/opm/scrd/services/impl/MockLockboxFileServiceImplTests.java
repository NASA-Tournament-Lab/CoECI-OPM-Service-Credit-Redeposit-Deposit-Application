/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import static org.junit.Assert.assertEquals;
import gov.opm.scrd.TestHelper;
import gov.opm.scrd.services.LockboxFileImportingException;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test cases for {@link MockLockboxFileServiceImpl}.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class MockLockboxFileServiceImplTests {

    /**
     * Represents the invalid lockbox input file content.
     */
    private static final String INVALID_LOCKBOX_INPUT_FILE_CONTENT =
        "R618dddd6d1234d79d11d240050d0d1d0505d1  d                                       ";

    /**
     * Represents the errors for invalid lockbox input file content.
     */
    private static String ERRORS;

    /**
     * Represents the test string as the content of the lock box input file.
     */
    private static String LOCKBOX_INPUT_FILE_CONTENT;

    /**
     * Initialize the testing content.
     */
    static {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("R61875166 12345790110240050000110505 1                                          ");
        stringBuilder.append(TestHelper.LINE_SEPARATOR);

        stringBuilder.append("C 02      6185516111213abcdefghijklmnopqrstuvwx                                 ");
        stringBuilder.append(TestHelper.LINE_SEPARATOR);

        stringBuilder.append("R ZZZ     ZZZZZZZ0000198000                                                     ");
        LOCKBOX_INPUT_FILE_CONTENT = stringBuilder.toString();

        StringBuilder errors = new StringBuilder();
        errors.append("The Lockbox file content has following errors: ");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Batch' at position [3 - 5] must be 3 digits.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Block' at position [6 - 7] must be 2 digits.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Sequence' at position [8 - 9] must be 2 digits.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Filler' at position 10 must be 1 space.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Claim Number' at position [11 - 17] must be 7 digits.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Date of Birth'- (d11d24) at position [18 - 23]"
            + " must match the date pattern 'MMddyy'.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Payment Amount' at position [24 - 30] must be 7 digits.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Payment Date'- (1d0505) at position [31 - 36]"
            + " must match the date pattern 'MMddyy'.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Filler' at position 37 must be 1 space.");
        errors.append(TestHelper.LINE_SEPARATOR);

        errors.append("Line #1 : Data element 'Filler' at position [39 - 80] must be 42 spaces.");

        ERRORS = errors.toString();
    }

    /**
     * Represents {@link MockLockboxFileServiceImpl} instance for testing.
     */
    private MockLockboxFileServiceImpl instance;

    /**
     * Sets up the test environment.
     *
     * @throws Exception to JUnit
     */
    @Before
    public void setUp() throws Exception {
        instance = new MockLockboxFileServiceImpl();
    }

    /**
     * Tears down the test environment.
     *
     * @throws Exception to JUnit
     */
    @After
    public void tearDown() throws Exception {
        instance = null;
    }

    /**
     * Test for {@link MockLockboxFileServiceImpl#importLockboxFile}. LOCKBOX_INPUT_FILE_CONTENT will be parsed
     * successfully.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_importLockboxFile() throws Exception {
        InputStream inputStream = new ByteArrayInputStream(LOCKBOX_INPUT_FILE_CONTENT.getBytes());
        try {
            instance.importLockboxFile(inputStream);
        } finally {
            inputStream.close();
        }
        // success to execute without any exception thrown
    }

    /**
     * Test for {@link MockLockboxFileServiceImpl#importLockboxFile}. LockboxFileImportingException will be thrown
     * from importLockboxFile method.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_invalid_importLockboxFile() throws Exception {
        InputStream inputStream = new ByteArrayInputStream(INVALID_LOCKBOX_INPUT_FILE_CONTENT.getBytes());
        try {
            instance.importLockboxFile(inputStream);
        } catch (LockboxFileImportingException exception) {
            // verify the error message
            assertEquals("The content of the exception error is incorrect.", ERRORS, exception.getMessage());
        } finally {
            inputStream.close();
        }
    }
}
