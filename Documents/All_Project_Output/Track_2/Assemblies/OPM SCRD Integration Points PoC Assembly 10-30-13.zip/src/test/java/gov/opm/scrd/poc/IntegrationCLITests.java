/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.poc;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import gov.opm.scrd.TestHelper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.Assertion;
import org.junit.contrib.java.lang.system.ExpectedSystemExit;
import org.springframework.context.support.AbstractXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 * Test cases for {@link IntegrationCLI}.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class IntegrationCLITests {

    /**
     * Represents the date format.
     */
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyMMdd");

    /**
     * Represents the spring configuration file for testing purpose.
     */
    private static final String TEST_SPRING_CONFIG_FILE = "src" + File.separator + "test" + File.separator
        + "resources" + File.separator + "applicationTestContext.xml";

    /**
     * Represents the temporary directory for testing purpose.
     */
    private static final File TEMP_DIR = new File("temp");

    /**
     * Represents the lockbox input file.
     */
    private static String LOCKBOX_INPUT_FILE;

    /**
     * Represents the general ledger file output directory.
     */
    private static String GENERAL_LEDGER_FILE_OUTPUT_DIRECTORY;

    /**
     * Represents the generated GL files serialization file.
     */
    private static String GENERATED_GLFILES_SERIALIZATION_FILE;

    /**
     * Initialize the configuration.
     */
    static {
        AbstractXmlApplicationContext context = null;
        try {
            context = new FileSystemXmlApplicationContext(TEST_SPRING_CONFIG_FILE);
            LOCKBOX_INPUT_FILE =
                context.getBean("lockboxFileInputDirectory", String.class)
                    + context.getBean("lockboxInputFileName", String.class);
            GENERAL_LEDGER_FILE_OUTPUT_DIRECTORY = context.getBean("generalLedgerFileOutputDirectory", String.class);
            GENERATED_GLFILES_SERIALIZATION_FILE = context.getBean("generatedGLFilesSerializationFile", String.class);
        } finally {
            if (context != null) {
                context.close();
            }
        }
    }

    /**
     * The system exit rule. Refer to this for more detail: http://www.stefan-birkner.de/system-rules/index.html .
     */
    @Rule
    public final ExpectedSystemExit exit = ExpectedSystemExit.none();

    /**
     * Test for {@link IntegrationCLI#main}. All settings are correct.
     * <ul>
     * <li>lockbox input file should be removed.</li>
     * <li>general ledger file should be generated.</li>
     * <li>GL files serialization file should be generated.</li>
     * </ul>
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_main_1() throws Exception {
        FileUtils.deleteDirectory(TEMP_DIR);
        TEMP_DIR.mkdir();

        // prepare the lockbox input file.
        TestHelper.writeLocalFileContent(LOCKBOX_INPUT_FILE,
            "R61875166 12345790110240050000110505 1                                          ");

        // application should exit normally
        exit.expectSystemExitWithStatus(0);

        // Callback to verify the processing logic
        exit.checkAssertionAfterwards(new Assertion() {

            /**
             * Checks whether the processing is correct. This method will be called after
             * <code>IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE })</code>
             *
             * @throws Exception to JUnit
             */
            @Override
            public void checkAssertion() throws Exception {

                assertFalse("lockbox input file should be removed.", new File(LOCKBOX_INPUT_FILE).exists());
                assertTrue("general ledger file should be generated.", new File(GENERAL_LEDGER_FILE_OUTPUT_DIRECTORY
                    + "SCGL" + DATE_FORMAT.format(new Date()) + ".txt").exists());
                assertTrue("generated GL files serialization file should be generated.", new File(
                    GENERATED_GLFILES_SERIALIZATION_FILE).exists());

                FileUtils.deleteDirectory(TEMP_DIR);
            }
        });

        IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE });
    }

    /**
     * Test for {@link IntegrationCLI#main}. No lockbox input file is provided.
     * <ul>
     * <li>general ledger file should not be generated.</li>
     * <li>GL files serialization file should be generated.</li>
     * </ul>
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_main_2() throws Exception {
        FileUtils.deleteDirectory(TEMP_DIR);
        TEMP_DIR.mkdir();

        // application should exit normally
        exit.expectSystemExitWithStatus(0);

        // Callback to verify the processing logic
        exit.checkAssertionAfterwards(new Assertion() {

            /**
             * Checks whether the processing is correct. This method will be called after
             * <code>IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE })</code>
             *
             * @throws Exception to JUnit
             */
            @Override
            public void checkAssertion() throws Exception {

                assertFalse("general ledger file should not be generated.", new File(
                    GENERAL_LEDGER_FILE_OUTPUT_DIRECTORY + "SCGL" + DATE_FORMAT.format(new Date()) + ".txt").exists());
                assertTrue("generated GL files serialization file should be generated.", new File(
                    GENERATED_GLFILES_SERIALIZATION_FILE).exists());

                FileUtils.deleteDirectory(TEMP_DIR);
            }
        });

        IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE });
    }

    /**
     * Test for {@link IntegrationCLI#main}. Incorrect lockbox input file is provided.
     * <ul>
     * <li>Incorrect lockbox input file should be removed.</li>
     * <li>general ledger file should be generated.</li>
     * <li>GL files serialization file should be generated.</li>
     * </ul>
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_main_3() throws Exception {
        FileUtils.deleteDirectory(TEMP_DIR);
        TEMP_DIR.mkdir();

        // prepare the lockbox input file.
        TestHelper.writeLocalFileContent(LOCKBOX_INPUT_FILE, "incorrect content");

        // application should exit normally
        exit.expectSystemExitWithStatus(0);

        // Callback to verify the processing logic
        exit.checkAssertionAfterwards(new Assertion() {

            /**
             * Checks whether the processing is correct. This method will be called after
             * <code>IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE })</code>
             *
             * @throws Exception to JUnit
             */
            @Override
            public void checkAssertion() throws Exception {

                assertFalse("lockbox input file should be removed.", new File(LOCKBOX_INPUT_FILE).exists());
                assertTrue("general ledger file should not be generated.", new File(
                    GENERAL_LEDGER_FILE_OUTPUT_DIRECTORY + "SCGL" + DATE_FORMAT.format(new Date()) + ".txt").exists());
                assertTrue("generated GL files serialization file should be generated.", new File(
                    GENERATED_GLFILES_SERIALIZATION_FILE).exists());

                FileUtils.deleteDirectory(TEMP_DIR);
            }
        });

        IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE });
    }

    /**
     * Test for {@link IntegrationCLI#main}. Incorrect serialization file. Application should exit abnormally.
     *
     * @throws Exception to JUnit
     */
    @Test
    public void test_main_4() throws Exception {
        FileUtils.deleteDirectory(TEMP_DIR);
        TEMP_DIR.mkdir();
        // prepare the wrong serialization file.
        TestHelper.writeLocalFileContent(GENERATED_GLFILES_SERIALIZATION_FILE, "wrong serialization file.");

        // application should exit abnormally
        exit.expectSystemExitWithStatus(-1);

        // Callback to verify the processing logic
        exit.checkAssertionAfterwards(new Assertion() {

            /**
             * Removes the temporary directory. This method will be called after
             * <code>IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE })</code>
             *
             * @throws Exception to JUnit
             */
            @Override
            public void checkAssertion() throws Exception {

                FileUtils.deleteDirectory(TEMP_DIR);
            }
        });

        IntegrationCLI.main(new String[] { TEST_SPRING_CONFIG_FILE });
    }
}
