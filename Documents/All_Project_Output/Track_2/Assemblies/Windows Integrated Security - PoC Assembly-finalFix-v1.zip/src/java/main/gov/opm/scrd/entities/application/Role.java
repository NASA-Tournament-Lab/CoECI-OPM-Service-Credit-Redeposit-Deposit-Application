/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import javax.persistence.Entity;

/**
 * This is the Role class to store role name.
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * 
 * @author argolite,TCSASSEMBLER
 * @version 1.0
 */
@Entity
public class Role extends NamedEntity {
    /**
     * Empty constructor.
     */
    public Role() {

    }
}
