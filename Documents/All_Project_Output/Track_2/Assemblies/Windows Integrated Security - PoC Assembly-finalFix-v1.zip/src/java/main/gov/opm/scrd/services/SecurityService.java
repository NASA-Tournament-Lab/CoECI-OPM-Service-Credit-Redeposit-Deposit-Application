/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import java.util.List;

import javax.ejb.Local;

/**
 * The Security Service is used to check authorization. <strong>Thread Safety:
 * </strong>Implementations need to be effectively thread safe.
 * 
 * @author argolite,TCSASSEMBLER
 * @version 1.0
 */
@Local
public interface SecurityService {

    /**
     * Check authorization by user name,roles and action
     * 
     * @param username
     *            the user name
     * @param roles
     *            the roles
     * @param action
     *            the action name
     * @return if authorized return true
     */
    public boolean authorize(String username, List<String> roles, String action);
}
