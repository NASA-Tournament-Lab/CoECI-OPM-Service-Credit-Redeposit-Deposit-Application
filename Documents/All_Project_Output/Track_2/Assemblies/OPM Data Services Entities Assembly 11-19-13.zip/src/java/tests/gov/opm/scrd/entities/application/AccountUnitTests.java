/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import gov.opm.scrd.TestsHelper;
import gov.opm.scrd.entities.lookup.AccountStatus;
import gov.opm.scrd.entities.lookup.FormType;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.JUnit4TestAdapter;

import org.junit.Before;
import org.junit.Test;

/**
 * <p>
 * Unit tests for {@link Account} class.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class AccountUnitTests {
    /**
     * <p>
     * Represents the <code>Account</code> instance used in tests.
     * </p>
     */
    private Account instance;

    /**
     * <p>
     * Adapter for earlier versions of JUnit.
     * </p>
     *
     * @return a test suite.
     */
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(AccountUnitTests.class);
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @Before
    public void setUp() throws Exception {
        instance = new Account();
    }

    /**
     * <p>
     * Accuracy test for the constructor <code>Account()</code>.<br>
     * Instance should be correctly created.
     * </p>
     */
    @Test
    public void testCtor() {
        instance = new Account();

        assertEquals("'claimNumber' should be correct.", 0L, TestsHelper.getField(instance, "claimNumber"));
        assertNull("'planType' should be correct.", TestsHelper.getField(instance, "planType"));
        assertNull("'formType' should be correct.", TestsHelper.getField(instance, "formType"));
        assertNull("'holder' should be correct.", TestsHelper.getField(instance, "holder"));
        assertNull("'status' should be correct.", TestsHelper.getField(instance, "status"));
        assertFalse("'grace' should be correct.", (Boolean) TestsHelper.getField(instance, "grace"));
        assertFalse("'frozen' should be correct.", (Boolean) TestsHelper.getField(instance, "frozen"));
        assertNull("'notes' should be correct.", TestsHelper.getField(instance, "notes"));
        assertNull("'claimOfficer' should be correct.", TestsHelper.getField(instance, "claimOfficer"));
        assertNull("'claimOfficerAssignmentDate' should be correct.",
            TestsHelper.getField(instance, "claimOfficerAssignmentDate"));
        assertNull("'claimantBirthdate' should be correct.", TestsHelper.getField(instance, "claimantBirthdate"));
        assertNull("'balance' should be correct.", TestsHelper.getField(instance, "balance"));
        assertNull("'returnedFromRecordsDate' should be correct.",
            TestsHelper.getField(instance, "returnedFromRecordsDate"));
        assertNull("'billingSummary' should be correct.", TestsHelper.getField(instance, "billingSummary"));
        assertNull("'fersDepositCalculationVersions' should be correct.",
            TestsHelper.getField(instance, "fersDepositCalculationVersions"));
        assertNull("'fersRedepositCalculationVersions' should be correct.",
            TestsHelper.getField(instance, "fersRedepositCalculationVersions"));
        assertNull("'paymentHistory' should be correct.", TestsHelper.getField(instance, "paymentHistory"));
        assertNull("'validity' should be correct.", TestsHelper.getField(instance, "validity"));
    }


    /**
     * <p>
     * Accuracy test for the method <code>getClaimNumber()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getClaimNumber() {
        long value = 1L;
        instance.setClaimNumber(value);

        assertEquals("'getClaimNumber' should be correct.",
            value, instance.getClaimNumber());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setClaimNumber(long claimNumber)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setClaimNumber() {
        long value = 1L;
        instance.setClaimNumber(value);

        assertEquals("'setClaimNumber' should be correct.",
            value, TestsHelper.getField(instance, "claimNumber"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getPlanType()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getPlanType() {
        String value = "new_value";
        instance.setPlanType(value);

        assertEquals("'getPlanType' should be correct.",
            value, instance.getPlanType());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setPlanType(String planType)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setPlanType() {
        String value = "new_value";
        instance.setPlanType(value);

        assertEquals("'setPlanType' should be correct.",
            value, TestsHelper.getField(instance, "planType"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getFormType()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getFormType() {
        FormType value = new FormType();
        instance.setFormType(value);

        assertSame("'getFormType' should be correct.",
            value, instance.getFormType());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setFormType(FormType formType)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setFormType() {
        FormType value = new FormType();
        instance.setFormType(value);

        assertSame("'setFormType' should be correct.",
            value, TestsHelper.getField(instance, "formType"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getHolder()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getHolder() {
        AccountHolder value = new AccountHolder();
        instance.setHolder(value);

        assertSame("'getHolder' should be correct.",
            value, instance.getHolder());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setHolder(AccountHolder holder)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setHolder() {
        AccountHolder value = new AccountHolder();
        instance.setHolder(value);

        assertSame("'setHolder' should be correct.",
            value, TestsHelper.getField(instance, "holder"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getStatus()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getStatus() {
        AccountStatus value = new AccountStatus();
        instance.setStatus(value);

        assertSame("'getStatus' should be correct.",
            value, instance.getStatus());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setStatus(AccountStatus status)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setStatus() {
        AccountStatus value = new AccountStatus();
        instance.setStatus(value);

        assertSame("'setStatus' should be correct.",
            value, TestsHelper.getField(instance, "status"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>isGrace()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_isGrace() {
        boolean value = true;
        instance.setGrace(value);

        assertTrue("'isGrace' should be correct.", instance.isGrace());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setGrace(boolean grace)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setGrace() {
        boolean value = true;
        instance.setGrace(value);

        assertTrue("'setGrace' should be correct.",
            (Boolean) TestsHelper.getField(instance, "grace"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>isFrozen()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_isFrozen() {
        boolean value = true;
        instance.setFrozen(value);

        assertTrue("'isFrozen' should be correct.", instance.isFrozen());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setFrozen(boolean frozen)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setFrozen() {
        boolean value = true;
        instance.setFrozen(value);

        assertTrue("'setFrozen' should be correct.",
            (Boolean) TestsHelper.getField(instance, "frozen"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getNotes()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getNotes() {
        List<AccountNote> value = new ArrayList<AccountNote>();
        instance.setNotes(value);

        assertSame("'getNotes' should be correct.",
            value, instance.getNotes());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setNotes(List&lt;AccountNote&gt; notes)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setNotes() {
        List<AccountNote> value = new ArrayList<AccountNote>();
        instance.setNotes(value);

        assertSame("'setNotes' should be correct.",
            value, TestsHelper.getField(instance, "notes"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getClaimOfficer()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getClaimOfficer() {
        String value = "new_value";
        instance.setClaimOfficer(value);

        assertEquals("'getClaimOfficer' should be correct.",
            value, instance.getClaimOfficer());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setClaimOfficer(String claimOfficer)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setClaimOfficer() {
        String value = "new_value";
        instance.setClaimOfficer(value);

        assertEquals("'setClaimOfficer' should be correct.",
            value, TestsHelper.getField(instance, "claimOfficer"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getClaimOfficerAssignmentDate()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getClaimOfficerAssignmentDate() {
        Date value = new Date();
        instance.setClaimOfficerAssignmentDate(value);

        assertSame("'getClaimOfficerAssignmentDate' should be correct.",
            value, instance.getClaimOfficerAssignmentDate());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setClaimOfficerAssignmentDate(Date claimOfficerAssignmentDate)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setClaimOfficerAssignmentDate() {
        Date value = new Date();
        instance.setClaimOfficerAssignmentDate(value);

        assertSame("'setClaimOfficerAssignmentDate' should be correct.",
            value, TestsHelper.getField(instance, "claimOfficerAssignmentDate"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getClaimantBirthdate()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getClaimantBirthdate() {
        Date value = new Date();
        instance.setClaimantBirthdate(value);

        assertSame("'getClaimantBirthdate' should be correct.",
            value, instance.getClaimantBirthdate());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setClaimantBirthdate(Date claimantBirthdate)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setClaimantBirthdate() {
        Date value = new Date();
        instance.setClaimantBirthdate(value);

        assertSame("'setClaimantBirthdate' should be correct.",
            value, TestsHelper.getField(instance, "claimantBirthdate"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getBalance()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getBalance() {
        BigDecimal value = new BigDecimal(1);
        instance.setBalance(value);

        assertSame("'getBalance' should be correct.",
            value, instance.getBalance());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setBalance(BigDecimal balance)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setBalance() {
        BigDecimal value = new BigDecimal(1);
        instance.setBalance(value);

        assertSame("'setBalance' should be correct.",
            value, TestsHelper.getField(instance, "balance"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getReturnedFromRecordsDate()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getReturnedFromRecordsDate() {
        Date value = new Date();
        instance.setReturnedFromRecordsDate(value);

        assertSame("'getReturnedFromRecordsDate' should be correct.",
            value, instance.getReturnedFromRecordsDate());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setReturnedFromRecordsDate(Date returnedFromRecordsDate)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setReturnedFromRecordsDate() {
        Date value = new Date();
        instance.setReturnedFromRecordsDate(value);

        assertSame("'setReturnedFromRecordsDate' should be correct.",
            value, TestsHelper.getField(instance, "returnedFromRecordsDate"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getBillingSummary()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getBillingSummary() {
        BillingSummary value = new BillingSummary();
        instance.setBillingSummary(value);

        assertSame("'getBillingSummary' should be correct.",
            value, instance.getBillingSummary());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setBillingSummary(BillingSummary billingSummary)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setBillingSummary() {
        BillingSummary value = new BillingSummary();
        instance.setBillingSummary(value);

        assertSame("'setBillingSummary' should be correct.",
            value, TestsHelper.getField(instance, "billingSummary"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getFersDepositCalculationVersions()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getFersDepositCalculationVersions() {
        List<CalculationVersion> value = new ArrayList<CalculationVersion>();
        instance.setFersDepositCalculationVersions(value);

        assertSame("'getFersDepositCalculationVersions' should be correct.",
            value, instance.getFersDepositCalculationVersions());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setFersDepositCalculationVersions(List&lt;CalculationVersion&gt;
     * fersDepositCalculationVersions)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setFersDepositCalculationVersions() {
        List<CalculationVersion> value = new ArrayList<CalculationVersion>();
        instance.setFersDepositCalculationVersions(value);

        assertSame("'setFersDepositCalculationVersions' should be correct.",
            value, TestsHelper.getField(instance, "fersDepositCalculationVersions"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getFersRedepositCalculationVersions()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getFersRedepositCalculationVersions() {
        List<CalculationVersion> value = new ArrayList<CalculationVersion>();
        instance.setFersRedepositCalculationVersions(value);

        assertSame("'getFersRedepositCalculationVersions' should be correct.",
            value, instance.getFersRedepositCalculationVersions());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setFersRedepositCalculationVersions(List&lt;CalculationVersion&gt;
     * fersRedepositCalculationVersions)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setFersRedepositCalculationVersions() {
        List<CalculationVersion> value = new ArrayList<CalculationVersion>();
        instance.setFersRedepositCalculationVersions(value);

        assertSame("'setFersRedepositCalculationVersions' should be correct.",
            value, TestsHelper.getField(instance, "fersRedepositCalculationVersions"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getPaymentHistory()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getPaymentHistory() {
        List<Payment> value = new ArrayList<Payment>();
        instance.setPaymentHistory(value);

        assertSame("'getPaymentHistory' should be correct.",
            value, instance.getPaymentHistory());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setPaymentHistory(List&lt;Payment&gt; paymentHistory)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setPaymentHistory() {
        List<Payment> value = new ArrayList<Payment>();
        instance.setPaymentHistory(value);

        assertSame("'setPaymentHistory' should be correct.",
            value, TestsHelper.getField(instance, "paymentHistory"));
    }

    /**
     * <p>
     * Accuracy test for the method <code>getValidity()</code>.<br>
     * The value should be properly retrieved.
     * </p>
     */
    @Test
    public void test_getValidity() {
        AccountConfirmationValidation value = new AccountConfirmationValidation();
        instance.setValidity(value);

        assertSame("'getValidity' should be correct.",
            value, instance.getValidity());
    }

    /**
     * <p>
     * Accuracy test for the method <code>setValidity(AccountConfirmationValidation validity)</code>.<br>
     * The value should be properly set.
     * </p>
     */
    @Test
    public void test_setValidity() {
        AccountConfirmationValidation value = new AccountConfirmationValidation();
        instance.setValidity(value);

        assertSame("'setValidity' should be correct.",
            value, TestsHelper.getField(instance, "validity"));
    }
}