/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import static org.junit.Assert.assertNotNull;
import junit.framework.JUnit4TestAdapter;

import org.junit.Before;
import org.junit.Test;

/**
 * <p>
 * Unit tests for {@link AppointmentType} class.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class AppointmentTypeUnitTests {
    /**
     * <p>
     * Represents the <code>AppointmentType</code> instance used in tests.
     * </p>
     */
    private AppointmentType instance;

    /**
     * <p>
     * Adapter for earlier versions of JUnit.
     * </p>
     *
     * @return a test suite.
     */
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(AppointmentTypeUnitTests.class);
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @Before
    public void setUp() throws Exception {
        instance = new AppointmentType();
    }

    /**
     * <p>
     * Accuracy test for the constructor <code>AppointmentType()</code>.<br>
     * Instance should be correctly created.
     * </p>
     */
    @Test
    public void testCtor() {
        instance = new AppointmentType();

        assertNotNull("Instance should be created.", instance);
    }

}