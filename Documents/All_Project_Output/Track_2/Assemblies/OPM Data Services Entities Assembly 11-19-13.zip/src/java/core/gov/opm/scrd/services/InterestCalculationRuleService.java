/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.CalculationRequest;
import gov.opm.scrd.entities.application.CalculationResponse;

/**
 * <p>
 * This interface materializes the generic parameters for the rule service to be used in interest calculation.
 * </p>
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public interface InterestCalculationRuleService extends RuleService<CalculationRequest, CalculationResponse> {

}
