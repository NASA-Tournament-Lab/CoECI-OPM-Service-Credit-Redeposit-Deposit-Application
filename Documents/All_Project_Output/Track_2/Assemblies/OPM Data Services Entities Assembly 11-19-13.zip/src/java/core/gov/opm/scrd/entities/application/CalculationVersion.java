/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * This is the class representing the FERS deposit/redeposit single total item of the calculation information. It
 * contains reference to smaller concrete calculations set in @see Calculation and the aggregated result data in @see
 * CalculationResult.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class CalculationVersion extends IdentifiableEntity {
    /**
     * <p>
     * Represents the name of calculation version. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private String name;
    /**
     * <p>
     * Represents the list of individual calculation items of calculation version. It is managed with a getter and
     * setter. It may have any value. It is fully mutable.
     * </p>
     */
    private List<Calculation> calculations;
    /**
     * <p>
     * Represents the result of calculation version. It is managed with a getter and setter. It may have any value. It
     * is fully mutable.
     * </p>
     */
    private CalculationResult calculationResult;
    /**
     * <p>
     * Represents the calculation date. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private Date calculationDate;

    /**
     * Creates an instance of CalculationVersion.
     */
    public CalculationVersion() {
        // Empty
    }

    /**
     * Gets the name of calculation version.
     *
     * @return the name of calculation version.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of calculation version.
     *
     * @param name
     *            the name of calculation version.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the list of individual calculation items of calculation version.
     *
     * @return the list of individual calculation items of calculation version.
     */
    public List<Calculation> getCalculations() {
        return calculations;
    }

    /**
     * Sets the list of individual calculation items of calculation version.
     *
     * @param calculations
     *            the list of individual calculation items of calculation version.
     */
    public void setCalculations(List<Calculation> calculations) {
        this.calculations = calculations;
    }

    /**
     * Gets the result of calculation version.
     *
     * @return the result of calculation version.
     */
    public CalculationResult getCalculationResult() {
        return calculationResult;
    }

    /**
     * Sets the result of calculation version.
     *
     * @param calculationResult
     *            the result of calculation version.
     */
    public void setCalculationResult(CalculationResult calculationResult) {
        this.calculationResult = calculationResult;
    }

    /**
     * Gets the calculation date.
     *
     * @return the calculation date.
     */
    public Date getCalculationDate() {
        return calculationDate;
    }

    /**
     * Sets the calculation date.
     *
     * @param calculationDate
     *            the calculation date.
     */
    public void setCalculationDate(Date calculationDate) {
        this.calculationDate = calculationDate;
    }
}