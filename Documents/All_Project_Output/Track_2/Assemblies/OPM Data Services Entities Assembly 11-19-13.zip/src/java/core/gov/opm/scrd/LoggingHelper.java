/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.slf4j.Logger;

/**
 * <p>
 * This is the helper class of this assembly.
 * </p>
 * <strong>Thread Safety: </strong> this class is immutable and thread-safe
 *
 * @author j3_guile
 * @version 1.0
 */
public class LoggingHelper {

    /**
     * Maximum log details text length. (See SDS 7.7)
     */
    private static final int MAX_ARGUMENTS = 4066;

    /**
     * Maximum log exception text length. (See SDS 7.7)
     */
    private static final int MAX_EXCEPTION = 1024;

    /**
     * Maximum log method text length. (See SDS 7.7)
     */
    private static final int MAX_SIGNATURE = 100;

    /**
     * Represents the entrance message.
     */
    private static final String MESSAGE_ENTRANCE = "Entering method %1$s.";

    /**
     * Represents the exit message.
     */
    private static final String MESSAGE_EXIT = "Exiting method %1$s.";

    /**
     * Represents the error message.
     */
    private static final String MESSAGE_ERROR = "Error in method %1$s. Details:";

    /**
     * Private empty constructor to prevent instantiating this class.
     */
    private LoggingHelper() {
    }

    /**
     * Logs for entrance into public methods at <code>DEBUG</code> level.
     *
     * @param logger the log service.
     * @param signature the signature.
     * @param paramNames the names of parameters to log (not Null).
     * @param params the values of parameters to log (not Null).
     */
    public static void logEntrance(Logger logger, String signature, String[] paramNames, Object[] params) {
        StringBuilder sb = new StringBuilder();
        sb.append(truncate(String.format(MESSAGE_ENTRANCE, signature), MAX_SIGNATURE));
        sb.append(truncate(toString(paramNames, params, MAX_ARGUMENTS), MAX_ARGUMENTS));
        logger.debug(sb.toString());
    }

    /**
     * Trims the message to a more manageable length.
     *
     * @param message the message to trim
     * @param max the threshold for the message length
     * @return the trimmed message only if it exceeds the threshold, otherwise, the same as the input
     */
    private static String truncate(String message, int max) {
        if (message.length() > max) {
            return message.substring(0, max);
        }
        return message;
    }

    /**
     * Logs for exit from public methods at <code>DEBUG</code> level.
     *
     * @param logger the log service.
     * @param signature the signature of the method to be logged.
     * @param value the return value to log.
     */
    public static void logExit(Logger logger, String signature, Object[] value) {
        StringBuilder sb = new StringBuilder();
        sb.append(truncate(String.format(MESSAGE_EXIT, signature), MAX_SIGNATURE));
        if (value != null) {
            sb.append(truncate(" Output parameter : " + toString(value[0]), MAX_ARGUMENTS));
        }
        logger.debug(sb.toString());
    }

    /**
     * Logs the given exception and message at <code>ERROR</code> level.
     *
     * @param <T> the exception type.
     * @param logger the log service.
     * @param signature the signature of the method to log.
     * @param e the exception to log.
     *
     * @return the passed in exception.
     */
    public static <T extends Throwable> T logException(Logger logger, String signature, T e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        logger.error(truncate(String.format(MESSAGE_ERROR, signature + " " + sw.toString()), MAX_EXCEPTION));
        return e;
    }

    /**
     * Converts the parameters to string.
     *
     * @param paramNames the names of parameters.
     * @param params the values of parameters.
     * @param max the maximum length of parameter logging allowed
     *
     * @return the string
     */
    static String toString(String[] paramNames, Object[] params, int max) {
        StringBuffer sb = new StringBuffer(" Input parameters: {");
        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                if (sb.length() >= max) {
                    break;
                }
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(paramNames[i]).append(":").append(toString(params[i]));
            }
        }
        sb.append("}.");
        return sb.toString();
    }

    /**
     * Converts the object to string.
     *
     * @param obj the object
     *
     * @return the string representation of the object.
     */
    static String toString(Object obj) {
        return String.valueOf(obj);
    }
}