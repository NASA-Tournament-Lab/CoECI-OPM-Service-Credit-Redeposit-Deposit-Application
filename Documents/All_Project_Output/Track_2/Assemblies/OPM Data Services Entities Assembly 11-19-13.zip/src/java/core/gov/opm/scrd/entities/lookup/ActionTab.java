/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

/**
 * <p>
 * Represents the enumeration specifying the home page for the user of the application.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This enumeration is immutable and thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public enum ActionTab {
    /**
     * Represents 'view account' action tab.
     */
    VIEW_ACCOUNT,

    /**
     * Represents 'create new account' action tab.
     */
    CREATE_NEW_ACCOUNT,

    /**
     * Represents 'disapproved' action tab.
     */
    DISAPPROVED,

    /**
     * Represents 'work queue' action tab.
     */
    WORK_QUEUE,

    /**
     * Represents 'reports' action tab.
     */
    REPORTS,

    /**
     * Represents 'suspense' action tab.
     */
    SUSPENSE,

    /**
     * Represents 'approval' action tab.
     */
    APPROVAL,

    /**
     * Represents 'payments' action tab.
     */
    PAYMENTS,

    /**
     * Represents 'tools' action tab.
     */
    TOOLS,

    /**
     * Represents 'admin' action tab.
     */
    ADMIN,

    /**
     * Represents 'notification log' action tab.
     */
    NOTIFICATION_LOG,

    /**
     * Represents 'help' action tab.
     */
    HELP
}
