/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * Represents the base search parameters for sorting.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public abstract class BaseSearchParameters {
    /**
     * <p>
     * Represents the column to sort on. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String sortColumn;
    /**
     * <p>
     * Represents the sort order. It is managed with a getter and setter. It may have any value. It is fully mutable.
     * </p>
     */
    private SortOrder sortOrder;

    /**
     * Creates an instance of BaseSearchParameters.
     */
    protected BaseSearchParameters() {
        // Empty
    }

    /**
     * Gets the column to sort on.
     *
     * @return the column to sort on.
     */
    public String getSortColumn() {
        return sortColumn;
    }

    /**
     * Sets the column to sort on.
     *
     * @param sortColumn
     *            the column to sort on.
     */
    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }

    /**
     * Gets the sort order.
     *
     * @return the sort order.
     */
    public SortOrder getSortOrder() {
        return sortOrder;
    }

    /**
     * Sets the sort order.
     *
     * @param sortOrder
     *            the sort order.
     */
    public void setSortOrder(SortOrder sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * Converts the entity to a string.
     *
     * @return the string with entity data.
     */
    @Override
    public String toString() {
        return Helper.toString(this);
    }
}