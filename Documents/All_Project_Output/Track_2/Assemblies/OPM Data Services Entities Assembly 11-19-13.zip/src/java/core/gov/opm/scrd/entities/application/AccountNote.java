/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

import java.util.Date;

/**
 * <p>
 * This is the class representing the notes associated with the account. There can be many notes associated with
 * account.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class AccountNote extends IdentifiableEntity {
    /**
     * <p>
     * Represents the date when the note was created. It is managed with a getter and setter. It may have any value. It
     * is fully mutable.
     * </p>
     */
    private Date date;
    /**
     * <p>
     * Represents the name of the user who created the note. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private String writer;
    /**
     * <p>
     * Represents the content of the note. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String text;
    /**
     * <p>
     * Represents the account associated with the note. It is managed with a getter and setter. It may have any value.
     * It is fully mutable.
     * </p>
     */
    private long accountId;

    /**
     * Creates an instance of AccountNote.
     */
    public AccountNote() {
        // Empty
    }

    /**
     * Gets the date when the note was created.
     *
     * @return the date when the note was created.
     */
    public Date getDate() {
        return date;
    }

    /**
     * Sets the date when the note was created.
     *
     * @param date
     *            the date when the note was created.
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Gets the name of the user who created the note.
     *
     * @return the name of the user who created the note.
     */
    public String getWriter() {
        return writer;
    }

    /**
     * Sets the name of the user who created the note.
     *
     * @param writer
     *            the name of the user who created the note.
     */
    public void setWriter(String writer) {
        this.writer = writer;
    }

    /**
     * Gets the content of the note.
     *
     * @return the content of the note.
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the content of the note.
     *
     * @param text
     *            the content of the note.
     */
    public void setText(String text) {
        this.text = text;
    }

    /**
     * Gets the account associated with the note.
     *
     * @return the account associated with the note.
     */
    public long getAccountId() {
        return accountId;
    }

    /**
     * Sets the account associated with the note.
     *
     * @param accountId
     *            the account associated with the note.
     */
    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }
}