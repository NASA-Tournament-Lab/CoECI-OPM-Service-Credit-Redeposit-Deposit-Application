/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;
import gov.opm.scrd.entities.lookup.AccountStatus;
import gov.opm.scrd.entities.lookup.FormType;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * This is the class representing the account used in the application. There will be always a dedicated person who is
 * holding the account. Once the account is created, it is status is set to PENDING(@see AccountStatus). Account can be
 * approved/disapproved by manager which changes the status to APPROVED/DISAPPROVED respectively.
 * </p>
 *
 * <p>
 * The account can be assigned for the investigation to the claim officer. In such case
 * claimOfficer/claimOfficerAssignmentDate fields are set. Similarly, account can be unassigned.
 * </p>
 *
 * <p>
 * The account is associated with number of the payments stored in the payment history. There can be different types of
 * payments(@see Payment). Based on it the billing data contained in @see BillingSummary is calculated.
 * </p>
 *
 * <p>
 * Additionally, the FERS deposit/redeposit calculation data is present in the entity. This data is populated by the
 * business rules.
 * </p>
 *
 * <p>
 * Each account before approval should be valid. The validation information is present in @see
 * AccountConfirmationValidation.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class Account extends IdentifiableEntity {
    /**
     * <p>
     * Represents the claim number of account. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private long claimNumber;
    /**
     * <p>
     * Represents the plan type of account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String planType;
    /**
     * <p>
     * Represents the form type of account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private FormType formType;
    /**
     * <p>
     * Represents the holder of account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private AccountHolder holder;
    /**
     * <p>
     * Represents the status of account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private AccountStatus status;
    /**
     * <p>
     * Represents the flag specifying whether account is grace. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private boolean grace;
    /**
     * <p>
     * Represents the flag specifying whether account is frozen. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private boolean frozen;
    /**
     * <p>
     * Represents the notes associated with account. It is managed with a getter and setter. It may have any value. It
     * is fully mutable.
     * </p>
     */
    private List<AccountNote> notes;
    /**
     * <p>
     * Represents the claim officer assigned to the account. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private String claimOfficer;
    /**
     * <p>
     * Represents the assigned date of account. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private Date claimOfficerAssignmentDate;
    /**
     * <p>
     * Represents the claimant birthdate of the assigned account. It is managed with a getter and setter. It may have
     * any value. It is fully mutable.
     * </p>
     */
    private Date claimantBirthdate;
    /**
     * <p>
     * Represents the balance of account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private BigDecimal balance;
    /**
     * <p>
     * Represents the timestamp when account was returned from records. It is managed with a getter and setter. It may
     * have any value. It is fully mutable.
     * </p>
     */
    private Date returnedFromRecordsDate;
    /**
     * <p>
     * Represents the billing summary of account. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private BillingSummary billingSummary;
    /**
     * <p>
     * Represents the calculation data for FERS deposit of account. It is managed with a getter and setter. It may have
     * any value. It is fully mutable.
     * </p>
     */
    private List<CalculationVersion> fersDepositCalculationVersions;
    /**
     * <p>
     * Represents the calculation data for FERS redeposit of account. It is managed with a getter and setter. It may
     * have any value. It is fully mutable.
     * </p>
     */
    private List<CalculationVersion> fersRedepositCalculationVersions;
    /**
     * <p>
     * Represents the payments of account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private List<Payment> paymentHistory;
    /**
     * <p>
     * Represents the account validity data of account. It is managed with a getter and setter. It may have any value.
     * It is fully mutable.
     * </p>
     */
    private AccountConfirmationValidation validity;

    /**
     * Creates an instance of Account.
     */
    public Account() {
        // Empty
    }

    /**
     * Gets the claim number of account.
     *
     * @return the claim number of account.
     */
    public long getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the claim number of account.
     *
     * @param claimNumber
     *            the claim number of account.
     */
    public void setClaimNumber(long claimNumber) {
        this.claimNumber = claimNumber;
    }

    /**
     * Gets the plan type of account.
     *
     * @return the plan type of account.
     */
    public String getPlanType() {
        return planType;
    }

    /**
     * Sets the plan type of account.
     *
     * @param planType
     *            the plan type of account.
     */
    public void setPlanType(String planType) {
        this.planType = planType;
    }

    /**
     * Gets the form type of account.
     *
     * @return the form type of account.
     */
    public FormType getFormType() {
        return formType;
    }

    /**
     * Sets the form type of account.
     *
     * @param formType
     *            the form type of account.
     */
    public void setFormType(FormType formType) {
        this.formType = formType;
    }

    /**
     * Gets the holder of account.
     *
     * @return the holder of account.
     */
    public AccountHolder getHolder() {
        return holder;
    }

    /**
     * Sets the holder of account.
     *
     * @param holder
     *            the holder of account.
     */
    public void setHolder(AccountHolder holder) {
        this.holder = holder;
    }

    /**
     * Gets the status of account.
     *
     * @return the status of account.
     */
    public AccountStatus getStatus() {
        return status;
    }

    /**
     * Sets the status of account.
     *
     * @param status
     *            the status of account.
     */
    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    /**
     * Gets the flag specifying whether account is grace.
     *
     * @return the flag specifying whether account is grace.
     */
    public boolean isGrace() {
        return grace;
    }

    /**
     * Sets the flag specifying whether account is grace.
     *
     * @param grace
     *            the flag specifying whether account is grace.
     */
    public void setGrace(boolean grace) {
        this.grace = grace;
    }

    /**
     * Gets the flag specifying whether account is frozen.
     *
     * @return the flag specifying whether account is frozen.
     */
    public boolean isFrozen() {
        return frozen;
    }

    /**
     * Sets the flag specifying whether account is frozen.
     *
     * @param frozen
     *            the flag specifying whether account is frozen.
     */
    public void setFrozen(boolean frozen) {
        this.frozen = frozen;
    }

    /**
     * Gets the notes associated with account.
     *
     * @return the notes associated with account.
     */
    public List<AccountNote> getNotes() {
        return notes;
    }

    /**
     * Sets the notes associated with account.
     *
     * @param notes
     *            the notes associated with account.
     */
    public void setNotes(List<AccountNote> notes) {
        this.notes = notes;
    }

    /**
     * Gets the claim officer assigned to the account.
     *
     * @return the claim officer assigned to the account.
     */
    public String getClaimOfficer() {
        return claimOfficer;
    }

    /**
     * Sets the claim officer assigned to the account.
     *
     * @param claimOfficer
     *            the claim officer assigned to the account.
     */
    public void setClaimOfficer(String claimOfficer) {
        this.claimOfficer = claimOfficer;
    }

    /**
     * Gets the assigned date of account.
     *
     * @return the assigned date of account.
     */
    public Date getClaimOfficerAssignmentDate() {
        return claimOfficerAssignmentDate;
    }

    /**
     * Sets the assigned date of account.
     *
     * @param claimOfficerAssignmentDate
     *            the assigned date of account.
     */
    public void setClaimOfficerAssignmentDate(Date claimOfficerAssignmentDate) {
        this.claimOfficerAssignmentDate = claimOfficerAssignmentDate;
    }

    /**
     * Gets the claimant birthdate of the assigned account.
     *
     * @return the claimant birthdate of the assigned account.
     */
    public Date getClaimantBirthdate() {
        return claimantBirthdate;
    }

    /**
     * Sets the claimant birthdate of the assigned account.
     *
     * @param claimantBirthdate
     *            the claimant birthdate of the assigned account.
     */
    public void setClaimantBirthdate(Date claimantBirthdate) {
        this.claimantBirthdate = claimantBirthdate;
    }

    /**
     * Gets the balance of account.
     *
     * @return the balance of account.
     */
    public BigDecimal getBalance() {
        return balance;
    }

    /**
     * Sets the balance of account.
     *
     * @param balance
     *            the balance of account.
     */
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    /**
     * Gets the timestamp when account was returned from records.
     *
     * @return the timestamp when account was returned from records.
     */
    public Date getReturnedFromRecordsDate() {
        return returnedFromRecordsDate;
    }

    /**
     * Sets the timestamp when account was returned from records.
     *
     * @param returnedFromRecordsDate
     *            the timestamp when account was returned from records.
     */
    public void setReturnedFromRecordsDate(Date returnedFromRecordsDate) {
        this.returnedFromRecordsDate = returnedFromRecordsDate;
    }

    /**
     * Gets the billing summary of account.
     *
     * @return the billing summary of account.
     */
    public BillingSummary getBillingSummary() {
        return billingSummary;
    }

    /**
     * Sets the billing summary of account.
     *
     * @param billingSummary
     *            the billing summary of account.
     */
    public void setBillingSummary(BillingSummary billingSummary) {
        this.billingSummary = billingSummary;
    }

    /**
     * Gets the calculation data for FERS deposit of account.
     *
     * @return the calculation data for FERS deposit of account.
     */
    public List<CalculationVersion> getFersDepositCalculationVersions() {
        return fersDepositCalculationVersions;
    }

    /**
     * Sets the calculation data for FERS deposit of account.
     *
     * @param fersDepositCalculationVersions
     *            the calculation data for FERS deposit of account.
     */
    public void setFersDepositCalculationVersions(List<CalculationVersion> fersDepositCalculationVersions) {
        this.fersDepositCalculationVersions = fersDepositCalculationVersions;
    }

    /**
     * Gets the calculation data for FERS redeposit of account.
     *
     * @return the calculation data for FERS redeposit of account.
     */
    public List<CalculationVersion> getFersRedepositCalculationVersions() {
        return fersRedepositCalculationVersions;
    }

    /**
     * Sets the calculation data for FERS redeposit of account.
     *
     * @param fersRedepositCalculationVersions
     *            the calculation data for FERS redeposit of account.
     */
    public void setFersRedepositCalculationVersions(List<CalculationVersion> fersRedepositCalculationVersions) {
        this.fersRedepositCalculationVersions = fersRedepositCalculationVersions;
    }

    /**
     * Gets the payments of account.
     *
     * @return the payments of account.
     */
    public List<Payment> getPaymentHistory() {
        return paymentHistory;
    }

    /**
     * Sets the payments of account.
     *
     * @param paymentHistory
     *            the payments of account.
     */
    public void setPaymentHistory(List<Payment> paymentHistory) {
        this.paymentHistory = paymentHistory;
    }

    /**
     * Gets the account validity data of account.
     *
     * @return the account validity data of account.
     */
    public AccountConfirmationValidation getValidity() {
        return validity;
    }

    /**
     * Sets the account validity data of account.
     *
     * @param validity
     *            the account validity data of account.
     */
    public void setValidity(AccountConfirmationValidation validity) {
        this.validity = validity;
    }
}