/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * Represents basic search filter that sorts and pages.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class BasicPagedSearchFilter extends BasePagedSearchParameters {

    /**
     * Creates an instance of BasicPagedSearchFilter.
     */
    public BasicPagedSearchFilter() {
        // Empty
    }

}