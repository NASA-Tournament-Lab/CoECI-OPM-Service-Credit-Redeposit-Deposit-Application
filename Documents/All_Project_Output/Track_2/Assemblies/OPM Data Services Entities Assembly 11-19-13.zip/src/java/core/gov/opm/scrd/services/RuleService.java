/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.RuleRequest;
import gov.opm.scrd.entities.application.RuleResponse;

/**
 * This is a base interface for rule engine services.
 *
 * @author argolite, j3_guile
 * @version 1.0
 * @param <S> the type of the request supported by the interface
 * @param <T> the type of the response supported by the interface
 */
public interface RuleService<S extends RuleRequest, T extends RuleResponse> {

    /**
     * Executes rules for the given request.
     *
     * @param request the request for rule execution
     * @return the corresponding response to the given rule request
     * @throws IllegalArgumentException if the request is null
     * @throws OPMException for any problems encountered while executing the request
     */
    public T execute(S request) throws OPMException;
}
