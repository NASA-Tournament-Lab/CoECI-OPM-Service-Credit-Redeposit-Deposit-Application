/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

/**
 * <p>
 * Represents the enumeration specifying the deposit type.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This enumeration is immutable and thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public enum DepositType {
    /**
     * Represents deposit type used after 10/82.
     */
    POST_10_82,

    /**
     * Represents deposit type used before 10/82.
     */
    PRE_10_82
}
