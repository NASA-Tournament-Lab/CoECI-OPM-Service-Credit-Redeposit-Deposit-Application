/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

import java.util.Date;

/**
 * <p>
 * Represents the printout that was already printed in the application. This entity will hold only details about
 * printout name and date omitting the actual contents.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class Printout extends IdentifiableEntity {
    /**
     * <p>
     * Represents the name of the printout. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String name;
    /**
     * <p>
     * Represents the print date of the printout. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private Date printDate;

    /**
     * Creates an instance of Printout.
     */
    public Printout() {
        // Empty
    }

    /**
     * Gets the name of the printout.
     *
     * @return the name of the printout.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the printout.
     *
     * @param name
     *            the name of the printout.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the print date of the printout.
     *
     * @return the print date of the printout.
     */
    public Date getPrintDate() {
        return printDate;
    }

    /**
     * Sets the print date of the printout.
     *
     * @param printDate
     *            the print date of the printout.
     */
    public void setPrintDate(Date printDate) {
        this.printDate = printDate;
    }
}