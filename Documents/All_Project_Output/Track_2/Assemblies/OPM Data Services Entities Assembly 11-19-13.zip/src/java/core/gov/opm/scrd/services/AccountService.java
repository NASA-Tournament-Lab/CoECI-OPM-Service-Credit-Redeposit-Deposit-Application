/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.Account;

/**
 * <p>
 * This interface defines the management functions for an account.
 * </p>
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public interface AccountService {

    /**
     * Creates a new account.
     *
     * @param account The account to be created.
     * @return the id of the newly created account.
     * @throws IllegalArgumentException if the account is null
     * @throws OPMException for any errors encountered
     */
    public long create(Account account) throws OPMException;

    /**
     * Updates an account.
     *
     * @param account The account to be updated.
     * @throws IllegalArgumentException if the account is null
     * @throws EntityNotFoundException When the account to be updated is not found in the database or is already
     *             deleted.
     * @throws OPMException for any other errors encountered
     */
    public void update(Account account) throws OPMException;

    /**
     * Deletes an account using the given account id.
     *
     * @throws IllegalArgumentException if the account ID is less than or equal to 0
     * @param accountId The id of the account to be deleted.
     * @throws EntityNotFoundException When the account to be deleted is not found in the database or is already
     *             deleted.
     * @throws OPMException for any other errors encountered
     */
    public void delete(long accountId) throws OPMException;

    /**
     * Retrieve an account given an account id. Deleted accounts will not be retrieved.
     *
     * @param accountId The id of the account to be retrieved from the database.
     * @return the account being retrieved, null if not found
     * @throws IllegalArgumentException if the account ID is less than or equal to 0
     * @throws OPMException for any errors encountered
     */
    public Account get(long accountId) throws OPMException;

}
