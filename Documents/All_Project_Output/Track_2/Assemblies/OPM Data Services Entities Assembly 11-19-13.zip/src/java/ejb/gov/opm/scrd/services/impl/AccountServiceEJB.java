/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import gov.opm.scrd.LoggingHelper;
import gov.opm.scrd.entities.application.Account;
import gov.opm.scrd.services.AccountService;
import gov.opm.scrd.services.EntityNotFoundException;
import gov.opm.scrd.services.OPMException;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Session Bean implementation of the account service using JPA.
 *
 * <b>Thread Safety</b> This class is thread safe when used as a session EJB.
 *
 * @author j3_guile
 * @version 1.0
 */
@Stateless
@Local(AccountService.class)
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class AccountServiceEJB implements AccountService {

    /**
     * Query to fetch a non-deleted account.
     */
    private static final String GET_ACCOUNT = "SELECT a FROM Account a WHERE a.deleted = false AND a.id = :accountId";

    /**
     * Class logger.
     */
    private static final Logger LOG = LoggerFactory.getLogger(AccountServiceEJB.class);

    /**
     * Entity manager for database operations.
     */
    @PersistenceContext
    private EntityManager em;

    /**
     * Default constructor.
     */
    public AccountServiceEJB() {
    }

    /**
     * Retrieve an account given an account id. Deleted accounts will not be retrieved.
     *
     * @param accountId The id of the account to be retrieved from the database.
     * @return the account being retrieved, null if not found
     * @throws IllegalArgumentException if the account ID is less than or equal to 0
     * @throws OPMException for any errors encountered
     */
    @SuppressWarnings("rawtypes")
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Account get(long accountId) throws OPMException {
        String signature = AccountServiceEJB.class.getName() + "#get(long accountId)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"accountId"}, new Object[] {accountId});

        if (accountId <= 0) {
            throw new IllegalArgumentException("Account ID to retrieve cannot be less than or equal to 0.");
        }

        Account account = null;
        try {
            List results = em.createQuery(GET_ACCOUNT).setParameter("accountId", accountId).getResultList();
            if (results != null && !results.isEmpty()) {
                account = (Account) results.get(0);
            }
        } catch (RuntimeException t) {
            // http://apps.topcoder.com/forums/?module=Thread&threadID=800759&start=0&mc=3#1787514
            // wrap any framework exceptions
            throw LoggingHelper.logException(LOG, signature, new OPMException("Unable to retrieve account.", t));
        }

        LoggingHelper.logExit(LOG, signature, new Object[] {account});
        return account;
    }

    /**
     * Creates a new account.
     *
     * @param account The account to be created.
     * @return the id of the newly created account.
     * @throws IllegalArgumentException if the account is null
     * @throws OPMException for any errors encountered
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public long create(Account account) throws OPMException {
        String signature = AccountServiceEJB.class.getName() + "#create(Account account)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"account"}, new Object[] {account});

        if (account == null) {
            throw new IllegalArgumentException("account to be created cannot be null.");
        }

        try {
            em.persist(account);
        } catch (RuntimeException t) {
            // http://apps.topcoder.com/forums/?module=Thread&threadID=800759&start=0&mc=3#1787514
            // wrap any framework exceptions
            throw LoggingHelper.logException(LOG, signature, new OPMException("Unable to create account.", t));
        }

        long id = account.getId();
        LoggingHelper.logExit(LOG, signature, new Object[] {id});
        return id;
    }

    /**
     * Deletes an account using the given account id.
     *
     * @throws IllegalArgumentException if the account ID is less than or equal to 0
     * @param accountId The id of the account to be deleted.
     * @throws EntityNotFoundException When the account to be deleted is not found in the database or is already
     *             deleted.
     * @throws OPMException for any other errors encountered
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delete(long accountId) throws OPMException {
        String signature = AccountServiceEJB.class.getName() + "#delete(long accountId)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"accountId"}, new Object[] {accountId});

        try {
            Account account = checkIfAccountExists(signature, accountId); // will check accountId argument
            account.setDeleted(true);
            em.merge(account);
        } catch (RuntimeException t) {
            // http://apps.topcoder.com/forums/?module=Thread&threadID=800759&start=0&mc=3#1787514
            // wrap any framework exceptions
            throw LoggingHelper.logException(LOG, signature, new OPMException("Unable to delete account.", t));
        }

        LoggingHelper.logExit(LOG, signature, null);
    }

    /**
     * Updates an account.
     *
     * @param account The account to be updated.
     * @throws IllegalArgumentException if the account is null or account ID is less that or equal to 0
     * @throws EntityNotFoundException When the account to be updated is not found in the database or is already
     *             deleted.
     * @throws OPMException for any other errors encountered
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Account account) throws OPMException {
        String signature = AccountServiceEJB.class.getName() + "#update(Account account)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"account"}, new Object[] {account});

        if (account == null) {
            throw new IllegalArgumentException("account to be updated cannot be null.");
        }

        checkIfAccountExists(signature, account.getId()); // will check accountId argument
        
        try {
            em.merge(account);
        } catch (RuntimeException t) {
            // http://apps.topcoder.com/forums/?module=Thread&threadID=800759&start=0&mc=3#1787514
            // wrap any framework exceptions
            throw LoggingHelper.logException(LOG, signature, new OPMException("Unable to update account.", t));
        }

        LoggingHelper.logExit(LOG, signature, null);
    }

    /**
     * Checks if the Account already exists in the database.
     * @param signature the public method signature
     *
     * @param accountId The id of the account to be checked in the database.
     * @return the account if it exists.
     * @throws EntityNotFoundException if the account does not exist
     * @throws OPMException for any other errors encountered during retrieval
     */
    private Account checkIfAccountExists(String signature, long accountId) throws OPMException {
        Account oldAccount = get(accountId);
        if (oldAccount == null) {
            throw LoggingHelper.logException(LOG, signature, new EntityNotFoundException(
                "Account does not exist or was already deleted."));
        }
        return oldAccount;
    }
}
