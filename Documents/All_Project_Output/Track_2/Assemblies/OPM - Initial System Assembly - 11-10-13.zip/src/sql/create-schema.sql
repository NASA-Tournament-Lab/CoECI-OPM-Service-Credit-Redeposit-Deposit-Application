CREATE TABLE retirementtype
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  name character varying(200),
  CONSTRAINT retirementtype_pkey PRIMARY KEY (id)
);

CREATE TABLE formtype
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  name character varying(200),
  CONSTRAINT formtype_pkey PRIMARY KEY (id)
);

CREATE TABLE accountstatus
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  name character varying(200),
  CONSTRAINT accountstatus_pkey PRIMARY KEY (id)
);

CREATE TABLE account
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  claim_no bigint,
  claim_officer character varying(200),
  claim_officer_assignment_dt timestamp without time zone,
  frozen_ind boolean,
  grace_ind boolean,
  ret_from_records_dt timestamp without time zone,
  formtype_id bigint,
  plantype_id bigint,
  status_id bigint,
  CONSTRAINT account_pkey PRIMARY KEY (id),
  CONSTRAINT fk1d0c220d1695f5cb FOREIGN KEY (formtype_id)
      REFERENCES formtype (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk1d0c220d1cd253bb FOREIGN KEY (plantype_id)
      REFERENCES retirementtype (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk1d0c220d1e9502f6 FOREIGN KEY (status_id)
      REFERENCES accountstatus (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE periodtype
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  name character varying(200),
  CONSTRAINT periodtype_pkey PRIMARY KEY (id)
);

CREATE TABLE appointmenttype
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  name character varying(200),
  CONSTRAINT appointmenttype_pkey PRIMARY KEY (id)
);

CREATE TABLE servicetype
(
  id bigserial NOT NULL,
  deleted boolean NOT NULL,
  name character varying(200),
  CONSTRAINT servicetype_pkey PRIMARY KEY (id)
);