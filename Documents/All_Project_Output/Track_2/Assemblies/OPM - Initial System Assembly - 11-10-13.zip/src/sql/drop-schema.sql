ALTER TABLE account DROP CONSTRAINT fk1d0c220d1e9502f6;

ALTER TABLE account DROP CONSTRAINT fk1d0c220d1695f5cb;

ALTER TABLE account DROP CONSTRAINT fk1d0c220d1cd253bb;

ALTER TABLE formtype DROP CONSTRAINT formtype_pkey;

ALTER TABLE retirementtype DROP CONSTRAINT retirementtype_pkey;

ALTER TABLE accountstatus DROP CONSTRAINT accountstatus_pkey;

ALTER TABLE account DROP CONSTRAINT account_pkey;

ALTER TABLE periodtype DROP CONSTRAINT periodtype_pkey;

ALTER TABLE appointmenttype DROP CONSTRAINT appointmenttype_pkey;

ALTER TABLE servicetype DROP CONSTRAINT servicetype_pkey;

DROP TABLE account;

DROP TABLE retirementtype;

DROP TABLE formtype;

DROP TABLE accountstatus;

DROP TABLE periodtype;

DROP TABLE appointmenttype;

DROP TABLE servicetype;