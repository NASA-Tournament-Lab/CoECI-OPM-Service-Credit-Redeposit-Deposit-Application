DELETE FROM account;

DELETE FROM retirementtype;

DELETE FROM formtype;

DELETE FROM accountstatus;

DELETE FROM periodtype;

DELETE FROM appointmenttype;

DELETE FROM servicetype;