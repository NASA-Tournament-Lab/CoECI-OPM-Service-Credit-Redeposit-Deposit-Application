INSERT INTO retirementtype (id, deleted, name) VALUES (1, false, 'Retirement Type 1');
INSERT INTO retirementtype (id, deleted, name) VALUES (2, false, 'Retirement Type 2');
INSERT INTO retirementtype (id, deleted, name) VALUES (3, false, 'Retirement Type 3');
INSERT INTO retirementtype (id, deleted, name) VALUES (4, false, 'Retirement Type 4');
INSERT INTO retirementtype (id, deleted, name) VALUES (5, false, 'Retirement Type 5');

INSERT INTO formtype (id, deleted, name) VALUES (1, false, 'Form Type 1');
INSERT INTO formtype (id, deleted, name) VALUES (2, false, 'Form Type 2');
INSERT INTO formtype (id, deleted, name) VALUES (3, false, 'Form Type 3');
INSERT INTO formtype (id, deleted, name) VALUES (4, false, 'Form Type 4');
INSERT INTO formtype (id, deleted, name) VALUES (5, false, 'Form Type 5');

INSERT INTO accountstatus (id, deleted, name) VALUES (1, false, 'Account Status 1');
INSERT INTO accountstatus (id, deleted, name) VALUES (2, false, 'Account Status 2');
INSERT INTO accountstatus (id, deleted, name) VALUES (3, false, 'Account Status 3');
INSERT INTO accountstatus (id, deleted, name) VALUES (4, false, 'Account Status 4');
INSERT INTO accountstatus (id, deleted, name) VALUES (5, false, 'Account Status 5');