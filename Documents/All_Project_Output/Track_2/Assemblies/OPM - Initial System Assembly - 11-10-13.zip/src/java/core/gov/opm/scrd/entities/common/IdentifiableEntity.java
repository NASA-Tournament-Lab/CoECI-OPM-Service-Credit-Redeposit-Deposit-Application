/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * This is the base class for all entities that have an identification number. Also has a flag for soft deletes.
 *
 * <b>Thread Safety</b> This class is mutable and not thread safe.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public abstract class IdentifiableEntity {

    /**
     * Represents the primary identifier of the entity. It is managed with a getter and setter and have any value.It is
     * fully mutable.
     */
    private long id;

    /**
     * Represents the flag whether the entity is logically deleted.
     *
     * It is managed with a getter and setter, may have any value and is fully mutable.
     */
    private boolean deleted;

    /**
     * Empty constructor.
     */
    protected IdentifiableEntity() {
    }

    /**
     * Determines whether the specified Object is equal to the current Object.
     *
     * @param obj - The Object to compare with the current Object
     * @return true if the specified Object is equal to the current Object; otherwise, false.
     */
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        // subclasses don't qualify as equal
        if (obj.getClass() != getClass()) {
            return false;
        }

        return this.id == ((IdentifiableEntity) obj).id;
    }

    /**
     * Serves as a hash function for a particular type.
     *
     * @return - hash code for the current Object.
     */
    public int hashCode() {
        return (int) id;
    }

    /**
     * Gets the value of the field <code>id</code>.
     *
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the field <code>id</code>.
     *
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Gets the value of the field <code>deleted</code>.
     *
     * @return the deleted
     */
    public boolean isDeleted() {
        return deleted;
    }

    /**
     * Sets the value of the field <code>deleted</code>.
     *
     * @param deleted the deleted to set
     */
    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}
