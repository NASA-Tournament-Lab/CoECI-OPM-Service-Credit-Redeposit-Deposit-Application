/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * This is the base class for all entities with a name.
 *
 * <b>Thread Safety</b> This class is mutable and not thread safe.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public abstract class NamedEntity extends IdentifiableEntity {

    /**
     * Represents the name of the entity.
     *
     * It is managed with a getter and setter, may have any value and is fully mutable
     */
    private String name;

    /**
     * Empty constructor.
     */
    protected NamedEntity() {
    }

    /**
     * Gets the value of the field <code>name</code>.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the field <code>name</code>.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets a readable string representation of this entity.
     *
     * @return this entity as a string.
     */
    @Override
    public String toString() {
        return getClass().getSimpleName() + " [id=" + getId() + ", deleted=" + isDeleted() + ", name=" + name + "]";
    }
}
