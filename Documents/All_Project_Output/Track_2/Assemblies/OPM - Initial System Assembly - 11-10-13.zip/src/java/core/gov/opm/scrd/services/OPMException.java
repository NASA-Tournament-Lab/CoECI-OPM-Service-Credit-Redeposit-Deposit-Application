/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import javax.ejb.ApplicationException;

/**
 * This is the top-level exception. It is thrown by all methods if there is an error.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
@ApplicationException(rollback = true)
public class OPMException extends Exception {

    /**
     * Default serial ID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new exception instance with no error message and no cause of error.
     */
    public OPMException() {
    }

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message - the error message
     */
    public OPMException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with no error message and the given cause of error.
     *
     * @param cause - the cause of error
     */
    public OPMException(Throwable cause) {
        super(cause);
    }

    /**
     * Creates a new exception instance with an error message and the given cause of error.
     *
     * @param message - the error message
     * @param cause - the cause of error
     */
    public OPMException(String message, Throwable cause) {
        super(message, cause);
    }
}
