/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

/**
 * This exception is thrown by implementations' checkProperties methods if there are required injection fields that are
 * not injected.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public class OPMConfigurationException extends RuntimeException {

    /**
     * Default serial ID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new exception instance with no error message and no cause of error.
     */
    public OPMConfigurationException() {
    }

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message - the error message
     */
    public OPMConfigurationException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with no error message and the given cause of error.
     *
     * @param cause - the cause of error
     */
    public OPMConfigurationException(Throwable cause) {
        super(cause);
    }

    /**
     * Creates a new exception instance with an error message and the given cause of error.
     *
     * @param message - the error message
     * @param cause - the cause of error
     */
    public OPMConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
