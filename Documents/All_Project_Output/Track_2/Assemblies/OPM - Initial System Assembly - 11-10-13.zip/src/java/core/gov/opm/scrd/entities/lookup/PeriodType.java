/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import gov.opm.scrd.entities.common.NamedEntity;

/**
 * Represents a period type.
 *
 * <b>Thread Safety</b> This class is mutable and not thread safe.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public class PeriodType extends NamedEntity {

    /**
     * Empty constructor.
     */
    public PeriodType() {
    }
}
