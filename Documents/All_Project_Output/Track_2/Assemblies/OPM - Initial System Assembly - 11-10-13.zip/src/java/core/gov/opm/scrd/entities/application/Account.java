/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;
import gov.opm.scrd.entities.lookup.AccountStatus;
import gov.opm.scrd.entities.lookup.FormType;
import gov.opm.scrd.entities.lookup.RetirementType;

import java.util.Date;

/**
 * Represents an account.
 *
 * <b>Thread Safety</b> This class is mutable and not thread safe.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public class Account extends IdentifiableEntity {

    /**
     * The claim number.
     */
    private long claimNumber;

    /**
     * The plan type.
     */
    private RetirementType planType;

    /**
     * The form type.
     */
    private FormType formType;

    /**
     * The account status.
     */
    private AccountStatus status;

    /**
     * The claim officer.
     */
    private String claimOfficer;

    /**
     * The claim officer assignment date.
     */
    private Date claimOfficerAssignmentDate;

    /**
     * The return from records date.
     */
    private Date returnedFromRecordsDate;

    /**
     * Frozen account indicator.
     */
    private boolean frozen;

    /**
     * Grace period indicator.
     */
    private boolean grace;

    /**
     * Empty constructor.
     */
    public Account() {
    }

    /**
     * Gets the value of the field <code>claimNumber</code>.
     *
     * @return the claimNumber
     */
    public long getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the value of the field <code>claimNumber</code>.
     *
     * @param claimNumber the claimNumber to set
     */
    public void setClaimNumber(long claimNumber) {
        this.claimNumber = claimNumber;
    }

    /**
     * Gets the value of the field <code>planType</code>.
     *
     * @return the planType
     */
    public RetirementType getPlanType() {
        return planType;
    }

    /**
     * Sets the value of the field <code>planType</code>.
     *
     * @param planType the planType to set
     */
    public void setPlanType(RetirementType planType) {
        this.planType = planType;
    }

    /**
     * Gets the value of the field <code>formType</code>.
     *
     * @return the formType
     */
    public FormType getFormType() {
        return formType;
    }

    /**
     * Sets the value of the field <code>formType</code>.
     *
     * @param formType the formType to set
     */
    public void setFormType(FormType formType) {
        this.formType = formType;
    }

    /**
     * Gets the value of the field <code>status</code>.
     *
     * @return the status
     */
    public AccountStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the field <code>status</code>.
     *
     * @param status the status to set
     */
    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    /**
     * Gets the value of the field <code>claimOfficer</code>.
     *
     * @return the claimOfficer
     */
    public String getClaimOfficer() {
        return claimOfficer;
    }

    /**
     * Sets the value of the field <code>claimOfficer</code>.
     *
     * @param claimOfficer the claimOfficer to set
     */
    public void setClaimOfficer(String claimOfficer) {
        this.claimOfficer = claimOfficer;
    }

    /**
     * Gets the value of the field <code>claimOfficerAssignmentDate</code>.
     *
     * @return the claimOfficerAssignmentDate
     */
    public Date getClaimOfficerAssignmentDate() {
        return claimOfficerAssignmentDate;
    }

    /**
     * Sets the value of the field <code>claimOfficerAssignmentDate</code>.
     *
     * @param claimOfficerAssignmentDate the claimOfficerAssignmentDate to set
     */
    public void setClaimOfficerAssignmentDate(Date claimOfficerAssignmentDate) {
        this.claimOfficerAssignmentDate = claimOfficerAssignmentDate;
    }

    /**
     * Gets the value of the field <code>returnedFromRecordsDate</code>.
     *
     * @return the returnedFromRecordsDate
     */
    public Date getReturnedFromRecordsDate() {
        return returnedFromRecordsDate;
    }

    /**
     * Sets the value of the field <code>returnedFromRecordsDate</code>.
     *
     * @param returnedFromRecordsDate the returnedFromRecordsDate to set
     */
    public void setReturnedFromRecordsDate(Date returnedFromRecordsDate) {
        this.returnedFromRecordsDate = returnedFromRecordsDate;
    }

    /**
     * Gets the value of the field <code>frozen</code>.
     *
     * @return the frozen
     */
    public boolean isFrozen() {
        return frozen;
    }

    /**
     * Sets the value of the field <code>frozen</code>.
     *
     * @param frozen the frozen to set
     */
    public void setFrozen(boolean frozen) {
        this.frozen = frozen;
    }

    /**
     * Gets the value of the field <code>grace</code>.
     *
     * @return the grace
     */
    public boolean isGrace() {
        return grace;
    }

    /**
     * Sets the value of the field <code>grace</code>.
     *
     * @param grace the grace to set
     */
    public void setGrace(boolean grace) {
        this.grace = grace;
    }

    /**
     * Gets a readable string representation of this entity.
     *
     * @return this entity as a string.
     */
    @Override
    public String toString() {
        return "Account [claimNumber=" + claimNumber + ", planType=" + planType + ", formType=" + formType
            + ", status=" + status + ", claimOfficer=" + claimOfficer + ", claimOfficerAssignmentDate="
            + claimOfficerAssignmentDate + ", returnedFromRecordsDate=" + returnedFromRecordsDate + ", frozen="
            + frozen + ", grace=" + grace + ", getId()=" + getId() + ", isDeleted()=" + isDeleted() + "]";
    }
}
