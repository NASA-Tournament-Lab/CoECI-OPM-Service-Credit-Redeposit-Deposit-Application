/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

/**
 * This exception is thrown by update and delete methods if an entity was not found.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public class EntityNotFoundException extends OPMException {

    /**
     * Default serial ID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new exception instance with no error message and no cause of error.
     */
    public EntityNotFoundException() {
    }

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message - the error message
     */
    public EntityNotFoundException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with no error message and the given cause of error.
     *
     * @param cause - the cause of error
     */
    public EntityNotFoundException(Throwable cause) {
        super(cause);
    }

    /**
     * Creates a new exception instance with an error message and the given cause of error.
     *
     * @param message - the error message
     * @param cause - the cause of error
     */
    public EntityNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
