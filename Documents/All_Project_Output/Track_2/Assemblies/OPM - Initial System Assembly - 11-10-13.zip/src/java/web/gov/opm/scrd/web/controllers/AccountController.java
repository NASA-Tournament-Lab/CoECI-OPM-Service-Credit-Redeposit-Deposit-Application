/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.web.controllers;

import gov.opm.scrd.LoggingHelper;
import gov.opm.scrd.entities.application.Account;
import gov.opm.scrd.entities.application.CalculationRequest;
import gov.opm.scrd.entities.application.CalculationResponse;
import gov.opm.scrd.services.AccountService;
import gov.opm.scrd.services.EntityNotFoundException;
import gov.opm.scrd.services.InterestCalculationRuleService;
import gov.opm.scrd.services.OPMException;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ejb.EJB;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Performs demonstration functionality for this system assembly.
 *
 * @author j3_guile
 * @version 1.0
 */
@Controller
public class AccountController {

    /**
     * JNDI binding for the rule service.
     */
    private static final String RULE_SERVICE_JNDI = "java:app/opm-scrd-ejb/InterestCalculationRuleServiceEJB!"
        + "gov.opm.scrd.services.InterestCalculationRuleService";

    /**
     * JNDI binding for the account service.
     */
    private static final String ACCOUNT_SERVICE_JNDI = "java:app/opm-scrd-ejb/AccountServiceEJB!"
        + "gov.opm.scrd.services.impl.AccountServiceEJB";

    /**
     * Class logger.
     */
    private static final Logger LOG = LoggerFactory.getLogger(AccountController.class);

    /**
     * The account service EJB.
     */
    @EJB(mappedName = ACCOUNT_SERVICE_JNDI)
    private AccountService accountService;

    /**
     * The interest calculation service.
     */
    @EJB(mappedName = RULE_SERVICE_JNDI)
    private InterestCalculationRuleService interestCalculationRuleService;

    /**
     * Sets up custom formatters and binders.
     *
     * @param binder the web binder from the spring MVC framework
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    /**
     * Shows the initial demonstration screen.
     *
     * @return the model and view.
     * @throws OPMException for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping("/")
    public ModelAndView view() throws OPMException {
        String signature = AccountController.class.getName() + "#view()";
        LoggingHelper.logEntrance(LOG, signature, null, null);
        ModelAndView mv = new ModelAndView("account");
        mv.addObject("account", new Account());

        CalculationRequest calculationRequest = new CalculationRequest();
        calculationRequest.setBeginDate(new Date());
        calculationRequest.setEndDate(new Date());
        mv.addObject("calculationRequest", calculationRequest);

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Demonstrates a call to retrieve an entity.
     *
     * @param id the ID of the account to retrieve
     * @param forUpdate if true, the retrieval will show the update screen
     * @return the model and view
     * @throws OPMException for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/retrieve", method = RequestMethod.GET)
    public ModelAndView retrieve(@RequestParam long id, @RequestParam boolean forUpdate) throws OPMException {
        String signature = AccountController.class.getName() + "#retrieve(long id, boolean forUpdate)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"id", "forUpdate"}, new Object[] {id, forUpdate});

        ModelAndView mv = new ModelAndView();
        Account account = accountService.get(id);
        if (account == null) {
            mv.addObject("msg", "Account does not exists or was already deleted!");
            mv.setViewName("accountResult");
        } else {
            mv.addObject("account", account);
            mv.setViewName(forUpdate ? "accountUpdate" : "accountResult");
        }

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Demonstrates a call to create an entity.
     *
     * @param account the account create
     * @return the model and view
     * @throws OPMException for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public ModelAndView create(@ModelAttribute Account account) throws OPMException {
        String signature = AccountController.class.getName() + "#create(Account account)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"account"}, new Object[] {account});

        ModelAndView mv = new ModelAndView("accountResult");
        accountService.create(account);
        // get the created account
        mv.addObject("account", accountService.get(account.getId()));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Demonstrates a call to update an entity.
     *
     * @param account the account updates
     * @return the model and view
     * @throws OPMException for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public ModelAndView update(@ModelAttribute Account account) throws OPMException {
        String signature = AccountController.class.getName() + "#update(Account account)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"account"}, new Object[] {account});
        ModelAndView mv = new ModelAndView("accountResult");

        try {
            accountService.update(account);
            // get the updated account
            mv.addObject("account", accountService.get(account.getId()));
        } catch (EntityNotFoundException e) {
            mv.addObject("msg", "Account does not exists or was already deleted!");
        }

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Demonstrates a call to delete an entity.
     *
     * @param id the ID of the entity to delete
     * @return the model and view
     * @throws OPMException for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public ModelAndView delete(@RequestParam long id) throws OPMException {
        String signature = AccountController.class.getName() + "#delete(long id)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"id"}, new Object[] {id});

        ModelAndView mv = new ModelAndView("accountResult");
        try {
            accountService.delete(id);
            mv.addObject("msg", "Account [ID=" + id + "] was successfully deleted");
        } catch (EntityNotFoundException e) {
            mv.addObject("msg", "Account does not exists or was already deleted!");
        }

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Executes the business rules for the given request.
     *
     * @param request the request to execute
     * @return the model and view
     * @throws OPMException for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/execute", method = RequestMethod.POST)
    public ModelAndView execute(@ModelAttribute CalculationRequest request) throws OPMException {
        String signature = AccountController.class.getName() + "#execute(CalculationRequest request)";
        LoggingHelper.logEntrance(LOG, signature, new String[] {"request"}, new Object[] {request});

        ModelAndView mv = new ModelAndView("calculationResult");
        CalculationResponse response = interestCalculationRuleService.execute(new CalculationRequest());
        mv.addObject("calculationResult", response);

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }
}
