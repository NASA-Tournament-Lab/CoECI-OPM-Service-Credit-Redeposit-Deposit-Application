-- -----------------------------------------------------
-- Table app_user trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.app_user_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.app_user_history(id, deleted, username, default_tab, network_id, role_id, first_name, last_name, email, telephone, user_status_id, supervisor_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.username, NEW.default_tab, NEW.network_id, NEW.role_id, NEW.first_name, NEW.last_name, NEW.email, NEW.telephone, NEW.user_status_id, NEW.supervisor_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.app_user_history(id, deleted, username, default_tab, network_id, role_id, first_name, last_name, email, telephone, user_status_id, supervisor_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.username, OLD.default_tab, OLD.network_id, OLD.role_id, OLD.first_name, OLD.last_name, OLD.email, OLD.telephone, OLD.user_status_id, OLD.supervisor_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER app_user_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.app_user
  FOR EACH ROW EXECUTE PROCEDURE opm.app_user_func();
  
-- -----------------------------------------------------
-- Table notification trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.notification_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.notification_history(id, deleted, date, details, sender, read, recipient, recipient_role_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.date, NEW.details, NEW.sender, NEW.read, NEW.recipient, NEW.recipient_role_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.notification_history(id, deleted, date, details, sender, read, recipient, recipient_role_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.date, OLD.details, OLD.sender, OLD.read, OLD.recipient, OLD.recipient_role_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER notification_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.notification
  FOR EACH ROW EXECUTE PROCEDURE opm.notification_func();
  
-- -----------------------------------------------------
-- Table info trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.info_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.info_history(id, deleted, date, details, action)
            VALUES (NEW.id, NEW.deleted, NEW.date, NEW.details, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.info_history(id, deleted, date, details, action)
            VALUES (OLD.id, OLD.deleted, OLD.date, OLD.details, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER info_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.info
  FOR EACH ROW EXECUTE PROCEDURE opm.info_func();
  
-- -----------------------------------------------------
-- Table error trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.error_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.error_history(id, deleted, date, details, action)
            VALUES (NEW.id, NEW.deleted, NEW.date, NEW.details, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.error_history(id, deleted, date, details, action)
            VALUES (OLD.id, OLD.deleted, OLD.date, OLD.details, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER error_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.error
  FOR EACH ROW EXECUTE PROCEDURE opm.error_func();
  
-- -----------------------------------------------------
-- Table account_holder trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.account_holder_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.account_holder_history(id, deleted, last_name, first_name, middle_initial, suffix_id, birth_date, ssn, telephone, email, title, department_code, geo_code, city_of_employment, state_of_employment_id, address_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.last_name, NEW.first_name, NEW.middle_initial, NEW.suffix_id, NEW.birth_date, NEW.ssn, NEW.telephone, NEW.email, NEW.title, NEW.department_code, NEW.geo_code, NEW.city_of_employment, NEW.state_of_employment_id, NEW.address_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.account_holder_history(id, deleted, last_name, first_name, middle_initial, suffix_id, birth_date, ssn, telephone, email, title, department_code, geo_code, city_of_employment, state_of_employment_id, address_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.last_name, OLD.first_name, OLD.middle_initial, OLD.suffix_id, OLD.birth_date, OLD.ssn, OLD.telephone, OLD.email, OLD.title, OLD.department_code, OLD.geo_code, OLD.city_of_employment, OLD.state_of_employment_id, OLD.address_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER account_holder_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.account_holder
  FOR EACH ROW EXECUTE PROCEDURE opm.account_holder_func();
  
-- -----------------------------------------------------
-- Table account trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.account_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.account_history(id, deleted, claim_number, plan_type, form_type_id, account_holder_id, account_status_id, grace, frozen, claim_officer, claim_officer_assignment_date, returned_from_record_date, claimant_birthdate, balance, billing_summary_id, account_confirmation_validation_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.claim_number, NEW.plan_type, NEW.form_type_id, NEW.account_holder_id, NEW.account_status_id, NEW.grace, NEW.frozen, NEW.claim_officer, NEW.claim_officer_assignment_date, NEW.returned_from_record_date, NEW.claimant_birthdate, NEW.balance, NEW.billing_summary_id, NEW.account_confirmation_validation_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.account_history(id, deleted, claim_number, plan_type, form_type_id, account_holder_id, account_status_id, grace, frozen, claim_officer, claim_officer_assignment_date, returned_from_record_date, claimant_birthdate, balance, billing_summary_id, account_confirmation_validation_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.claim_number, OLD.plan_type, OLD.form_type_id, OLD.account_holder_id, OLD.account_status_id, OLD.grace, OLD.frozen, OLD.claim_officer, OLD.claim_officer_assignment_date, OLD.returned_from_record_date, OLD.claimant_birthdate, OLD.balance, OLD.billing_summary_id, OLD.account_confirmation_validation_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER account_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.account
  FOR EACH ROW EXECUTE PROCEDURE opm.account_func();
  
-- -----------------------------------------------------
-- Table address trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.address_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.address_history(id, deleted, street1, street2, street3, street4, street5, city, state_id, zip_code, country_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.street1, NEW.street2, NEW.street3, NEW.street4, NEW.street5, NEW.city, NEW.state_id, NEW.zip_code, NEW.country_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.address_history(id, deleted, street1, street2, street3, street4, street5, city, state_id, zip_code, country_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.street1, OLD.street2, OLD.street3, OLD.street4, OLD.street5, OLD.city, OLD.state_id, OLD.zip_code, OLD.country_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER address_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.address
  FOR EACH ROW EXECUTE PROCEDURE opm.address_func();
  
-- -----------------------------------------------------
-- Table account_note trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.account_note_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.account_note_history(id, deleted, date, writer, text, account_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.date, NEW.writer, NEW.text, NEW.account_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.account_note_history(id, deleted, date, writer, text, account_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.date, OLD.writer, OLD.text, OLD.account_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER account_note_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.account_note
  FOR EACH ROW EXECUTE PROCEDURE opm.account_note_func();
  
-- -----------------------------------------------------
-- Table billing_summary trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.billing_summary_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.billing_summary_history(id, deleted, computed_date, last_deposit_date, first_billing_date, last_interest_calculation, transaction_type, last_transaction_date, stop_ach_payments, action)
            VALUES (NEW.id, NEW.deleted, NEW.computed_date, NEW.last_deposit_date, NEW.first_billing_date, NEW.last_interest_calculation, NEW.transaction_type, NEW.last_transaction_date, NEW.stop_ach_payments, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.billing_summary_history(id, deleted, computed_date, last_deposit_date, first_billing_date, last_interest_calculation, transaction_type, last_transaction_date, stop_ach_payments, action)
            VALUES (OLD.id, OLD.deleted, OLD.computed_date, OLD.last_deposit_date, OLD.first_billing_date, OLD.last_interest_calculation, OLD.transaction_type, OLD.last_transaction_date, OLD.stop_ach_payments, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER billing_summary_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.billing_summary
  FOR EACH ROW EXECUTE PROCEDURE opm.billing_summary_func();
  
-- -----------------------------------------------------
-- Table billing trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.billing_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.billing_history(id, deleted, name, initial_billing, additional_interest, total_payments, balance, payment_order, billing_summary_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.name, NEW.initial_billing, NEW.additional_interest, NEW.total_payments, NEW.balance, NEW.payment_order, NEW.billing_summary_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.billing_history(id, deleted, name, initial_billing, additional_interest, total_payments, balance, payment_order, billing_summary_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.name, OLD.initial_billing, OLD.additional_interest, OLD.total_payments, OLD.balance, OLD.payment_order, OLD.billing_summary_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER billing_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.billing
  FOR EACH ROW EXECUTE PROCEDURE opm.billing_func();
  
-- -----------------------------------------------------
-- Table calculation_version trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.calculation_version_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.calculation_version_history(id, deleted, name, calculation_date, calculation_result_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.name, NEW.calculation_date, NEW.calculation_result_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.calculation_version_history(id, deleted, name, calculation_date, calculation_result_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.name, OLD.calculation_date, OLD.calculation_result_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER calculation_version_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.calculation_version
  FOR EACH ROW EXECUTE PROCEDURE opm.calculation_version_func();
  
-- -----------------------------------------------------
-- Table fers_deposit trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.fers_deposit_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.fers_deposit_history(id, account_id, calculation_version_id, action)
            VALUES (NEW.id, NEW.account_id, NEW.calculation_version_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.fers_deposit_history(id, account_id, calculation_version_id, action)
            VALUES (OLD.id, OLD.account_id, OLD.calculation_version_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER fers_deposit_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.fers_deposit
  FOR EACH ROW EXECUTE PROCEDURE opm.fers_deposit_func();
  
-- -----------------------------------------------------
-- Table fers_redeposit trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.fers_redeposit_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.fers_redeposit_history(id, account_id, calculation_version_id, action)
            VALUES (NEW.id, NEW.account_id, NEW.calculation_version_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.fers_redeposit_history(id, account_id, calculation_version_id, action)
            VALUES (OLD.id, OLD.account_id, OLD.calculation_version_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER fers_redeposit_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.fers_redeposit
  FOR EACH ROW EXECUTE PROCEDURE opm.fers_redeposit_func();
  
-- -----------------------------------------------------
-- Table calculation trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.calculation_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.calculation_history(id, deleted, begin_date, end_date, retirement_type_id, period_type_id, appointment_type_id, service_type_id, amount, pay_type_id, calculation_version_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.begin_date, NEW.end_date, NEW.retirement_type_id, NEW.period_type_id, NEW.appointment_type_id, NEW.service_type_id, NEW.amount, NEW.pay_type_id, NEW.calculation_version_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.calculation_history(id, deleted, begin_date, end_date, retirement_type_id, period_type_id, appointment_type_id, service_type_id, amount, pay_type_id, calculation_version_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.begin_date, OLD.end_date, OLD.retirement_type_id, OLD.period_type_id, OLD.appointment_type_id, OLD.service_type_id, OLD.amount, OLD.pay_type_id, OLD.calculation_version_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER calculation_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.calculation
  FOR EACH ROW EXECUTE PROCEDURE opm.calculation_func();
  
-- -----------------------------------------------------
-- Table calculation_result trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.calculation_result_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.calculation_result_history(id, deleted, calculation_status_id, official, apply_to_real_payment, summary_data_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.calculation_status_id, NEW.official, NEW.apply_to_real_payment, NEW.summary_data_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.calculation_result_history(id, deleted, calculation_status_id, official, apply_to_real_payment, summary_data_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.calculation_status_id, OLD.official, OLD.apply_to_real_payment, OLD.summary_data_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER calculation_result_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.calculation_result
  FOR EACH ROW EXECUTE PROCEDURE opm.calculation_result_func();
  
-- -----------------------------------------------------
-- Table calculation_result_item trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.calculation_result_item_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.calculation_result_item_history(id, deleted, start_date, end_date, mid_date, effective_date, period_type_id, deduction_amount, total_interest, payment_applied, balance, calculation_result_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.start_date, NEW.end_date, NEW.mid_date, NEW.effective_date, NEW.period_type_id, NEW.deduction_amount, NEW.total_interest, NEW.payment_applied, NEW.balance, NEW.calculation_result_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.calculation_result_item_history(id, deleted, start_date, end_date, mid_date, effective_date, period_type_id, deduction_amount, total_interest, payment_applied, balance, calculation_result_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.start_date, OLD.end_date, OLD.mid_date, OLD.effective_date, OLD.period_type_id, OLD.deduction_amount, OLD.total_interest, OLD.payment_applied, OLD.balance, OLD.calculation_result_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER calculation_result_item_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.calculation_result_item
  FOR EACH ROW EXECUTE PROCEDURE opm.calculation_result_item_func();
  
-- -----------------------------------------------------
-- Table redeposit trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.redeposit_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.redeposit_history(id, deleted, label, deposit, interest, total, calculation_result_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.label, NEW.deposit, NEW.interest, NEW.total, NEW.calculation_result_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.redeposit_history(id, deleted, label, deposit, interest, total, calculation_result_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.label, OLD.deposit, OLD.interest, OLD.total, OLD.calculation_result_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER redeposit_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.redeposit
  FOR EACH ROW EXECUTE PROCEDURE opm.redeposit_func();
  
-- -----------------------------------------------------
-- Table dedeposit trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.dedeposit_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.dedeposit_history(id, deleted, label, deposit, interest, total, calculation_result_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.label, NEW.deposit, NEW.interest, NEW.total, NEW.calculation_result_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.dedeposit_history(id, deleted, label, deposit, interest, total, calculation_result_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.label, OLD.deposit, OLD.interest, OLD.total, OLD.calculation_result_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER dedeposit_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.dedeposit
  FOR EACH ROW EXECUTE PROCEDURE opm.dedeposit_func();
  
-- -----------------------------------------------------
-- Table summary_data trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.summary_data_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.summary_data_history(id, deleted, total_payments_required, total_initial_interest, total_payments_applied, total_balance, action)
            VALUES (NEW.id, NEW.deleted, NEW.total_payments_required, NEW.total_initial_interest, NEW.total_payments_applied, NEW.total_balance, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.summary_data_history(id, deleted, total_payments_required, total_initial_interest, total_payments_applied, total_balance, action)
            VALUES (OLD.id, OLD.deleted, OLD.total_payments_required, OLD.total_initial_interest, OLD.total_payments_applied, OLD.total_balance, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER summary_data_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.summary_data
  FOR EACH ROW EXECUTE PROCEDURE opm.summary_data_func();
  
-- -----------------------------------------------------
-- Table refund_transaction trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.refund_transaction_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.refund_transaction_history(id, deleted, transaction_key, amount, claim_number, refund_date, refund_username, transfer_type_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.transaction_key, NEW.amount, NEW.claim_number, NEW.refund_date, NEW.refund_username, NEW.transfer_type_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.refund_transaction_history(id, deleted, transaction_key, amount, claim_number, refund_date, refund_username, transfer_type_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.transaction_key, OLD.amount, OLD.claim_number, OLD.refund_date, OLD.refund_username, OLD.transfer_type_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER refund_transaction_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.refund_transaction
  FOR EACH ROW EXECUTE PROCEDURE opm.refund_transaction_func();
  
-- -----------------------------------------------------
-- Table notification_READBY trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.notification_READBY_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.notification_READBY_history(id, notification_id, value, action)
            VALUES (NEW.id, NEW.notification_id, NEW.value, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.notification_READBY_history(id, notification_id, value, action)
            VALUES (OLD.id, OLD.notification_id, OLD.value, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER notification_READBY_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.notification_READBY
  FOR EACH ROW EXECUTE PROCEDURE opm.notification_READBY_func();
  
-- -----------------------------------------------------
-- Table payment trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.payment_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.payment_history(id, deleted, batch_number, block_number, sequence_number, claim_number, payment_status_id, account_holder_birthdate, deposit_date, amount, ssn, claimant, claimant_birthday, import_id, sequence, transaction_date, status_date, apply_designation_id, apply_to_gl, note, transaction_key, ach, account_balance, account_status_id, master_claim_number, master_claimant_birthday, master_account_status_id, master_account_balance, master_account_id, pre_deposit_amount, pre_redeposit_amount, post_deposit_amount, post_redeposit_amount, approval_user, approval_status, payment_type, account_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.batch_number, NEW.block_number, NEW.sequence_number, NEW.claim_number, NEW.payment_status_id, NEW.account_holder_birthdate, NEW.deposit_date, NEW.amount, NEW.ssn, NEW.claimant, NEW.claimant_birthday, NEW.import_id, NEW.sequence, NEW.transaction_date, NEW.status_date, NEW.apply_designation_id, NEW.apply_to_gl, NEW.note, NEW.transaction_key, NEW.ach, NEW.account_balance, NEW.account_status_id, NEW.master_claim_number, NEW.master_claimant_birthday, NEW.master_account_status_id, NEW.master_account_balance, NEW.master_account_id, NEW.pre_deposit_amount, NEW.pre_redeposit_amount, NEW.post_deposit_amount, NEW.post_redeposit_amount, NEW.approval_user, NEW.approval_status, NEW.payment_type, NEW.account_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.payment_history(id, deleted, batch_number, block_number, sequence_number, claim_number, payment_status_id, account_holder_birthdate, deposit_date, amount, ssn, claimant, claimant_birthday, import_id, sequence, transaction_date, status_date, apply_designation_id, apply_to_gl, note, transaction_key, ach, account_balance, account_status_id, master_claim_number, master_claimant_birthday, master_account_status_id, master_account_balance, master_account_id, pre_deposit_amount, pre_redeposit_amount, post_deposit_amount, post_redeposit_amount, approval_user, approval_status, payment_type, account_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.batch_number, OLD.block_number, OLD.sequence_number, OLD.claim_number, OLD.payment_status_id, OLD.account_holder_birthdate, OLD.deposit_date, OLD.amount, OLD.ssn, OLD.claimant, OLD.claimant_birthday, OLD.import_id, OLD.sequence, OLD.transaction_date, OLD.status_date, OLD.apply_designation_id, OLD.apply_to_gl, OLD.note, OLD.transaction_key, OLD.ach, OLD.account_balance, OLD.account_status_id, OLD.master_claim_number, OLD.master_claimant_birthday, OLD.master_account_status_id, OLD.master_account_balance, OLD.master_account_id, OLD.pre_deposit_amount, OLD.pre_redeposit_amount, OLD.post_deposit_amount, OLD.post_redeposit_amount, OLD.approval_user, OLD.approval_status, OLD.payment_type, OLD.account_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER payment_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.payment
  FOR EACH ROW EXECUTE PROCEDURE opm.payment_func();
  
-- -----------------------------------------------------
-- Table payment_reverse trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.payment_reverse_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.payment_reverse_history(id, deleted, payment_id, payment_reversal_reason_id, apply_to_gl, reverser, action)
            VALUES (NEW.id, NEW.deleted, NEW.payment_id, NEW.payment_reversal_reason_id, NEW.apply_to_gl, NEW.reverser, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.payment_reverse_history(id, deleted, payment_id, payment_reversal_reason_id, apply_to_gl, reverser, action)
            VALUES (OLD.id, OLD.deleted, OLD.payment_id, OLD.payment_reversal_reason_id, OLD.apply_to_gl, OLD.reverser, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER payment_reverse_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.payment_reverse
  FOR EACH ROW EXECUTE PROCEDURE opm.payment_reverse_func();
  
-- -----------------------------------------------------
-- Table account_confirmation_validation trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.account_confirmation_validation_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.account_confirmation_validation_history(id, deleted, account_id, data_check_status, data_check_status_validator, data_check_status_reason, action)
            VALUES (NEW.id, NEW.deleted, NEW.account_id, NEW.data_check_status, NEW.data_check_status_validator, NEW.data_check_status_reason, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.account_confirmation_validation_history(id, deleted, account_id, data_check_status, data_check_status_validator, data_check_status_reason, action)
            VALUES (OLD.id, OLD.deleted, OLD.account_id, OLD.data_check_status, OLD.data_check_status_validator, OLD.data_check_status_reason, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER account_confirmation_validation_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.account_confirmation_validation
  FOR EACH ROW EXECUTE PROCEDURE opm.account_confirmation_validation_func();
  
-- -----------------------------------------------------
-- Table account_confirmation_validation_entry trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.account_confirmation_validation_entry_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.account_confirmation_validation_entry_history(id, deleted, field_name, valid, account_confirmation_validation_id, action)
            VALUES (NEW.id, NEW.deleted, NEW.field_name, NEW.valid, NEW.account_confirmation_validation_id, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.account_confirmation_validation_entry_history(id, deleted, field_name, valid, account_confirmation_validation_id, action)
            VALUES (OLD.id, OLD.deleted, OLD.field_name, OLD.valid, OLD.account_confirmation_validation_id, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER account_confirmation_validation_entry_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.account_confirmation_validation_entry
  FOR EACH ROW EXECUTE PROCEDURE opm.account_confirmation_validation_entry_func();
  
-- -----------------------------------------------------
-- Table service_credit_preference trigger
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION opm.service_credit_preference_func() RETURNS TRIGGER AS $$
    BEGIN
    	  IF (TG_OP = 'UPDATE') OR (TG_OP = 'INSERT') THEN
            INSERT INTO opm.service_credit_preference_history(id, deleted, use_agents, use_status_bar, use_message_box, other, action)
            VALUES (NEW.id, NEW.deleted, NEW.use_agents, NEW.use_status_bar, NEW.use_message_box, NEW.other, substring(TG_OP,1,1));
            RETURN NEW;
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO opm.service_credit_preference_history(id, deleted, use_agents, use_status_bar, use_message_box, other, action)
            VALUES (OLD.id, OLD.deleted, OLD.use_agents, OLD.use_status_bar, OLD.use_message_box, OLD.other, substring(TG_OP,1,1));
            RETURN OLD;
        END IF;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER service_credit_preference_trigger 
  AFTER INSERT OR UPDATE OR DELETE ON opm.service_credit_preference
  FOR EACH ROW EXECUTE PROCEDURE opm.service_credit_preference_func();