
INSERT INTO opm.service_credit_preference (id, deleted, use_agents, use_status_bar, use_message_box, other) VALUES (1, false, false, false, false, 'Other 1');

INSERT INTO opm.printout (id, deleted, name, print_date, content) VALUES (1, false, 'Printout 1', CURRENT_TIMESTAMP, 'Printout content 1');
INSERT INTO opm.printout (id, deleted, name, print_date, content) VALUES (2, false, 'Printout 2', CURRENT_TIMESTAMP, 'Printout content 2');
INSERT INTO opm.printout (id, deleted, name, print_date, content) VALUES (3, false, 'Printout 3', CURRENT_TIMESTAMP, 'Printout content 3');

INSERT INTO opm.help_item (id, deleted, title, summary, content) VALUES (1, false, 'Help title 1', 'Help summary 1', 'Help content 1');
INSERT INTO opm.help_item (id, deleted, title, summary, content) VALUES (2, false, 'Help title 2', 'Help summary 2', 'Help content 2');
INSERT INTO opm.help_item (id, deleted, title, summary, content) VALUES (3, false, 'Help title 3', 'Help summary 3', 'Help content 3');

INSERT INTO opm.retirement_type (id, deleted, name) VALUES (1, false, 'Retirement Type 1');
INSERT INTO opm.retirement_type (id, deleted, name) VALUES (2, false, 'Retirement Type 2');
INSERT INTO opm.retirement_type (id, deleted, name) VALUES (3, false, 'Retirement Type 3');
INSERT INTO opm.retirement_type (id, deleted, name) VALUES (4, false, 'Retirement Type 4');
INSERT INTO opm.retirement_type (id, deleted, name) VALUES (5, false, 'Retirement Type 5');

INSERT INTO opm.form_type (id, deleted, name) VALUES (1, false, 'Form Type 1');
INSERT INTO opm.form_type (id, deleted, name) VALUES (2, false, 'Form Type 2');
INSERT INTO opm.form_type (id, deleted, name) VALUES (3, false, 'Form Type 3');
INSERT INTO opm.form_type (id, deleted, name) VALUES (4, false, 'Form Type 4');
INSERT INTO opm.form_type (id, deleted, name) VALUES (5, false, 'Form Type 5');

INSERT INTO opm.account_status (id, deleted, name) VALUES (1, false, 'Account Status 1');
INSERT INTO opm.account_status (id, deleted, name) VALUES (2, false, 'Account Status 2');
INSERT INTO opm.account_status (id, deleted, name) VALUES (3, false, 'Account Status 3');
INSERT INTO opm.account_status (id, deleted, name) VALUES (4, false, 'Account Status 4');
INSERT INTO opm.account_status (id, deleted, name) VALUES (5, false, 'Account Status 5');

INSERT INTO opm.suffix (id, deleted, name) VALUES (1, false, 'Suffix 1');
INSERT INTO opm.suffix (id, deleted, name) VALUES (2, false, 'Suffix 2');

INSERT INTO opm.state (id, deleted, name) VALUES (1, false, 'State 1');
INSERT INTO opm.state (id, deleted, name) VALUES (2, false, 'State 2');

INSERT INTO opm.country (id, deleted, name) VALUES (1, false, 'Country 1');
INSERT INTO opm.country (id, deleted, name) VALUES (2, false, 'Country 2');

INSERT INTO opm.role (id, deleted, name) VALUES (1, false, 'supervisor');
INSERT INTO opm.role (id, deleted, name) VALUES (2, false, 'Role 2');

INSERT INTO opm.user_status (id, deleted, name) VALUES (1, false, 'User Status 1');
INSERT INTO opm.user_status (id, deleted, name) VALUES (2, false, 'User Status 2');

INSERT INTO opm.address(id, deleted, street1, city, state_id, zip_code, country_id) VALUES(1, false, 'Street1', 'City 1', 1, 'Zip 1', 1);
INSERT INTO opm.address(id, deleted, street1, city, state_id, zip_code, country_id) VALUES(2, false, 'Street2', 'City 2', 2, 'Zip 2', 2);

INSERT INTO opm.account_holder(id, deleted, last_name, first_name, suffix_id, birth_date, ssn, email, city_of_employment, state_of_employment_id, address_id) VALUES(1, false, 'Hughes', 'Jack', 1, CURRENT_TIMESTAMP, 'SSN 1', 'Email 1', 'City 1', 1, 1);
INSERT INTO opm.account_holder(id, deleted, last_name, first_name, suffix_id, birth_date, ssn, email, city_of_employment, state_of_employment_id, address_id) VALUES(2, false, 'Zuckerberg', 'Mark', 2, CURRENT_TIMESTAMP, 'SSN 2', 'Email 2', 'City 2', 2, 2);


INSERT INTO opm.app_user (id, deleted, username, default_tab, network_id, role_id, first_name, last_name, email, telephone, user_status_id) VALUES (1, false, 'username1', 'VIEW_ACCOUNT', 'networkId1', 1, 'Jack', 'Hughes', 'Email 1', 'Telephone 1', 1);
INSERT INTO opm.app_user (id, deleted, username, default_tab, network_id, role_id, first_name, last_name, email, telephone, user_status_id) VALUES (2, false, 'username2', 'VIEW_ACCOUNT', 'networkId2', 2, 'Mark', 'Zuckerberg', 'Email 2', 'Telephone 2', 2);

INSERT INTO opm.user_permission (id, deleted, username, action) VALUES (1, false, 'username1', 'action1');
INSERT INTO opm.user_permission (id, deleted, username, action) VALUES (2, false, 'username2', 'action2');

INSERT INTO opm.role_permission (id, deleted, rolename, action) VALUES (1, false, 'role1', 'action1');
INSERT INTO opm.role_permission (id, deleted, rolename, action) VALUES (2, false, 'role2', 'action2');
