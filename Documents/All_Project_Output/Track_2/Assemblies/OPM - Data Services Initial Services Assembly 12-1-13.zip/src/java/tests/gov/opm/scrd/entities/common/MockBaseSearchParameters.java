/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * A mockup class of BaseSearchParameters. Used for testing.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class MockBaseSearchParameters extends BaseSearchParameters {
    /**
     * Creates an instance of MockBaseSearchParameters.
     */
    public MockBaseSearchParameters() {
        // Empty
    }
}
