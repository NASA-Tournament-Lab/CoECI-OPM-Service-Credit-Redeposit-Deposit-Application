/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import java.lang.reflect.Field;

/**
 * <p>
 * The base class for unit tests.
 * </p>
 *
 * <p>
 * <em>Changes in 1.1 (OPM - Data Services - Initial Services Assembly 1.0):</em>
 * <ol>
 * <li>Added EMPTY_STRING constant and setField method.</li>
 * </ol>
 * </p>
 *
 * @author sparemax
 * @version 1.1
 * @since OPM - Data Services - Entities Assembly 1.0
 */
public class TestsHelper {
    /**
     * <p>
     * Represents the empty string.
     * </p>
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static final String EMPTY_STRING = " \t ";

    /**
     * Creates an instance of TestsHelper.
     */
    private TestsHelper() {
        // Empty
    }

    /**
     * <p>
     * Gets value for field of given object.
     * </p>
     *
     * @param obj
     *            the given object.
     * @param field
     *            the field name.
     *
     * @return the field value.
     */
    public static Object getField(Object obj, String field) {
        Object value = null;
        try {
            Field declaredField = null;
            try {
                declaredField = obj.getClass().getDeclaredField(field);
            } catch (NoSuchFieldException e) {
                // Ignore
            }

            try {
                if (declaredField == null) {
                    declaredField = obj.getClass().getSuperclass().getDeclaredField(field);
                }
            } catch (NoSuchFieldException e) {
                // Ignore
            }

            if (declaredField == null) {
                declaredField = obj.getClass().getSuperclass().getSuperclass().getDeclaredField(field);
            }

            declaredField.setAccessible(true);

            try {
                value = declaredField.get(obj);
            } finally {
                declaredField.setAccessible(false);
            }
        } catch (IllegalAccessException e) {
            // Ignore
        } catch (NoSuchFieldException e) {
            // Ignore
        }

        return value;
    }

    /**
     * <p>
     * Sets value for field of given object.
     * </p>
     *
     * @param obj
     *            the given object.
     * @param field
     *            the field name.
     * @param value
     *            the field value.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void setField(Object obj, String field, Object value) {
        try {
            Field declaredField = null;
            try {
                declaredField = obj.getClass().getDeclaredField(field);
            } catch (NoSuchFieldException e) {
                // Ignore
            }

            try {
                if (declaredField == null) {
                    declaredField = obj.getClass().getSuperclass().getDeclaredField(field);
                }
            } catch (NoSuchFieldException e) {
                // Ignore
            }

            if (declaredField == null) {
                declaredField = obj.getClass().getSuperclass().getSuperclass().getDeclaredField(field);
            }

            declaredField.setAccessible(true);

            try {
                declaredField.set(obj, value);
            } finally {
                declaredField.setAccessible(false);
            }
        } catch (IllegalAccessException e) {
            // Ignore
        } catch (NoSuchFieldException e) {
            // Ignore
        }
    }
}
