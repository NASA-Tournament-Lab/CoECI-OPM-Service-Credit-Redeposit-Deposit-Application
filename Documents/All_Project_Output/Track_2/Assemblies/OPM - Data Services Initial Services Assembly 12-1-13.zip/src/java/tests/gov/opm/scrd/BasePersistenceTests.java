/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import gov.opm.scrd.entities.common.IdentifiableEntity;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.JUnit4TestAdapter;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

/**
 * <p>
 * Base persistence tests.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class BasePersistenceTests {
    /**
     * <p>
     * Represents the path of SQL files.
     * </p>
     */
    private static final String SQL_FILES = "src" + File.separator + "sql" + File.separator;

    /**
     * <p>
     * Represents the <code>EntityManagerFactory </code> for tests.
     * </p>
     */
    private static EntityManagerFactory factory;

    /**
     * <p>
     * Represents the entity manager used in tests.
     * </p>
     */
    private static EntityManager entityManager;

    /**
     * <p>
     * Adapter for earlier versions of JUnit.
     * </p>
     *
     * @return a test suite.
     */
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(BasePersistenceTests.class);
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @BeforeClass
    public static void setUpClass() throws Exception {
        factory = Persistence.createEntityManagerFactory("opmUnitName");
        entityManager = factory.createEntityManager();
        clearDB();
    }

    /**
     * <p>
     * Cleans up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @AfterClass
    public static void tearDownClass() throws Exception {
        clearDB();
        entityManager.close();
        entityManager = null;
        factory.close();
        factory = null;
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @Before
    public void setUp() throws Exception {
        clearDB();
    }

    /**
     * <p>
     * Cleans up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @After
    public void tearDown() throws Exception {
        clearDB();
    }

    /**
     * Gets the entity manager.
     *
     * @return the entity manager.
     */
    public static EntityManager getEntityManager() {
        return entityManager;
    }

    /**
     * <p>
     * Deletes the entity.
     * </p>
     *
     * @param entity
     *            the entity.
     */
    protected void delete(Object entity) {
        entityManager.getTransaction().begin();

        entityManager.remove(entity);

        entityManager.getTransaction().commit();
    }

    /**
     * <p>
     * Updates the entity.
     * </p>
     *
     * @param entity
     *            the entity.
     */
    protected void update(Object entity) {
        entityManager.getTransaction().begin();

        entityManager.merge(entity);

        entityManager.getTransaction().commit();
    }

    /**
     * <p>
     * Creates the entity.
     * </p>
     *
     * @param <T>
     *            the entity type.
     * @param entity
     *            the entity.
     *
     * @return the id
     */
    protected <T extends IdentifiableEntity> long create(T entity) {
        entityManager.getTransaction().begin();

        entityManager.persist(entity);

        entityManager.getTransaction().commit();
        entityManager.clear();

        return entity.getId();
    }

    /**
     * <p>
     * Clears the database.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    protected static void clearDB() throws Exception {
        executeSQL(SQL_FILES + "clear-data.sql");
    }

    /**
     * <p>
     * Executes the SQL statements in the file. Lines that are empty or starts with '#' will be ignore.
     * </p>
     *
     * @param file
     *            the file.
     *
     * @throws Exception
     *             to JUnit.
     */
    private static void executeSQL(String file) throws Exception {
        entityManager.getTransaction().begin();

        String[] values = readFile(file).split(";");

        for (int i = 0; i < values.length; i++) {
            String sql = values[i].trim();
            if ((sql.length() != 0) && (!sql.startsWith("#"))) {
                entityManager.createNativeQuery(sql).executeUpdate();
            }
        }

        entityManager.getTransaction().commit();
    }

    /**
     * <p>
     * Reads the content of a given file.
     * </p>
     *
     * @param fileName
     *            the name of the file to read.
     *
     * @return a string represents the content.
     *
     * @throws IOException
     *             if any error occurs during reading.
     */
    private static String readFile(String fileName) throws IOException {
        Reader reader = new FileReader(fileName);

        try {
            // Create a StringBuilder instance
            StringBuilder sb = new StringBuilder();

            // Buffer for reading
            char[] buffer = new char[1024];

            // Number of read chars
            int k = 0;

            // Read characters and append to string builder
            while ((k = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, k);
            }

            // Return read content
            return sb.toString();
        } finally {
            try {
                reader.close();
            } catch (IOException ioe) {
                // Ignore
            }
        }
    }
}