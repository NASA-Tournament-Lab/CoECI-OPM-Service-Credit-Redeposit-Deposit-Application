/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * A mockup class of IdentifiableEntity. Used for testing.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class MockIdentifiableEntity extends IdentifiableEntity {
    /**
     * Creates an instance of MockIdentifiableEntity.
     */
    public MockIdentifiableEntity() {
        // Empty
    }
}
