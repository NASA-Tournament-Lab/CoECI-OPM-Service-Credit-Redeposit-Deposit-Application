/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.web.controllers;

import gov.opm.scrd.LoggingHelper;
import gov.opm.scrd.entities.application.AuditRecord;
import gov.opm.scrd.entities.application.ServiceCreditPreference;
import gov.opm.scrd.entities.application.User;
import gov.opm.scrd.entities.lookup.ActionTab;
import gov.opm.scrd.services.AuditService;
import gov.opm.scrd.services.AuthorizationException;
import gov.opm.scrd.services.BatchPrintoutArchiveService;
import gov.opm.scrd.services.EntityNotFoundException;
import gov.opm.scrd.services.HelpService;
import gov.opm.scrd.services.LookupService;
import gov.opm.scrd.services.OPMException;
import gov.opm.scrd.services.SecurityService;
import gov.opm.scrd.services.ServiceCreditPreferenceService;
import gov.opm.scrd.services.UserService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Performs demonstration functionality for this assembly.
 *
 * @author sparemax
 * @version 1.0
 */
@Controller
public class TestController {
    /**
     * JNDI binding for the audit service.
     */
    private static final String AUDIT_SERVICE_JNDI = "java:app/opm-scrd-ejb/AuditServiceImpl!"
        + "gov.opm.scrd.services.impl.AuditServiceImpl";

    /**
     * JNDI binding for the lookup service.
     */
    private static final String LOOKUP_SERVICE_JNDI = "java:app/opm-scrd-ejb/LookupServiceImpl!"
        + "gov.opm.scrd.services.impl.LookupServiceImpl";

    /**
     * JNDI binding for the batch printout archive service.
     */
    private static final String PRINTOUT_SERVICE_JNDI = "java:app/opm-scrd-ejb/BatchPrintoutArchiveServiceImpl!"
        + "gov.opm.scrd.services.impl.BatchPrintoutArchiveServiceImpl";

    /**
     * JNDI binding for the help service.
     */
    private static final String HELP_SERVICE_JNDI = "java:app/opm-scrd-ejb/HelpServiceImpl!"
        + "gov.opm.scrd.services.impl.HelpServiceImpl";

    /**
     * JNDI binding for the service credit preference service.
     */
    private static final String PREFERENCE_SERVICE_JNDI = "java:app/opm-scrd-ejb/ServiceCreditPreferenceServiceImpl!"
        + "gov.opm.scrd.services.impl.ServiceCreditPreferenceServiceImpl";

    /**
     * JNDI binding for the user service.
     */
    private static final String USER_SERVICE_JNDI = "java:app/opm-scrd-ejb/UserServiceImpl!"
        + "gov.opm.scrd.services.impl.UserServiceImpl";

    /**
     * JNDI binding for the security service.
     */
    private static final String SECURITY_SERVICE_JNDI = "java:app/opm-scrd-ejb/SecurityServiceImpl!"
        + "gov.opm.scrd.services.impl.SecurityServiceImpl";

    /**
     * Class logger.
     */
    private static final Logger LOG = LoggerFactory.getLogger(TestController.class);

    /**
     * The lookup service.
     */
    @EJB(mappedName = LOOKUP_SERVICE_JNDI)
    private LookupService lookupService;

    /**
     * The audit service.
     */
    @EJB(mappedName = AUDIT_SERVICE_JNDI)
    private AuditService auditService;

    /**
     * The batch printout archive service.
     */
    @EJB(mappedName = PRINTOUT_SERVICE_JNDI)
    private BatchPrintoutArchiveService batchPrintoutArchiveService;

    /**
     * The help service.
     */
    @EJB(mappedName = HELP_SERVICE_JNDI)
    private HelpService helpService;

    /**
     * The service credit preference service.
     */
    @EJB(mappedName = PREFERENCE_SERVICE_JNDI)
    private ServiceCreditPreferenceService serviceCreditPreferenceService;

    /**
     * The security service.
     */
    @EJB(mappedName = SECURITY_SERVICE_JNDI)
    private SecurityService securityService;

    /**
     * The user service.
     */
    @EJB(mappedName = USER_SERVICE_JNDI)
    private UserService userService;

    /**
     * Sets up custom formatters and binders.
     *
     * @param binder
     *            the web binder from the spring MVC framework
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    /**
     * Shows the demonstration screen.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping("/test")
    public ModelAndView view() throws OPMException {
        String signature = AccountController.class.getName() + "#view()";
        LoggingHelper.logEntrance(LOG, signature, null, null);

        ModelAndView mv = new ModelAndView("test");

        mv.addObject("audit", new AuditRecord());

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Retrieves all available users.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewUsers", method = RequestMethod.GET)
    public ModelAndView viewAllUsers() throws OPMException {
        String signature = TestController.class.getName() + "#viewAllUsers()";

        LoggingHelper.logEntrance(LOG, signature, null, null);

        ModelAndView mv = new ModelAndView("usersResult");

        mv.addObject("users", userService.getAll());

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Retrieves all available supervisors.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewSupervisors", method = RequestMethod.GET)
    public ModelAndView viewSupervisors() throws OPMException {
        String signature = TestController.class.getName() + "#viewSupervisors()";

        LoggingHelper.logEntrance(LOG, signature, null, null);

        ModelAndView mv = new ModelAndView("usersResult");

        mv.addObject("users", userService.getSupervisors());

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Retrieves user by id.
     *
     * @param userId
     *            the user id
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewUser", method = RequestMethod.GET)
    public ModelAndView viewUser(@RequestParam long userId) throws OPMException {
        String signature = TestController.class.getName() + "#viewUser(long userId)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"userId"}, new Object[] {userId});

        ModelAndView mv = new ModelAndView("userResult");

        mv.addObject("user", userService.get(userId));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Retrieves user by username.
     *
     * @param username
     *            the username
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewUserByUsername", method = RequestMethod.GET)
    public ModelAndView viewUserByUsername(@RequestParam String username) throws OPMException {
        String signature = TestController.class.getName() + "#viewUserByUsername(String username)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"username"}, new Object[] {username});

        ModelAndView mv = new ModelAndView("userResult");

        mv.addObject("user", userService.getByUsername(username));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Updates user.
     *
     * @param user
     *            the user
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
    public ModelAndView updateUser(@ModelAttribute User user) throws OPMException {
        String signature = TestController.class.getName() + "#updateUser(User user)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"user"}, new Object[] {user});

        ModelAndView mv = new ModelAndView("userResult");
        try {
            userService.update(user);
            mv.addObject("msg", "User was successfully updated.");
        } catch (EntityNotFoundException e) {
            mv.addObject("msg", "User does not exists or was already deleted!");
        }

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Sets the default tab for user.
     *
     * @param userId
     *            the user id
     * @param tab
     *            the tab
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/setUserDefaultTab", method = RequestMethod.POST)
    public ModelAndView setUserDefaultTab(@RequestParam long userId, @RequestParam ActionTab tab) throws OPMException {
        String signature = TestController.class.getName() + "#setUserDefaultTab(long userId, ActionTab tab)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"userId", "tab"}, new Object[] {userId, tab});

        ModelAndView mv = new ModelAndView("userResult");

        try {
            userService.setDefaultTab(userId, tab);
            mv.addObject("msg", "The default tab for user was successfully set.");
        } catch (EntityNotFoundException e) {
            mv.addObject("msg", "User does not exists or was already deleted!");
        }

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Checks whether user is authorized to perform a particular action or access a given widget.
     *
     * @param username
     *            the username
     * @param roles
     *            the roles
     * @param action
     *            the action
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/authorize", method = RequestMethod.GET)
    public ModelAndView authorize(@RequestParam String username, @RequestParam String roles,
        @RequestParam String action) throws OPMException {
        String signature = TestController.class.getName() + "#authorize(String username, String roles, String action)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"username", "roles", "action"}, new Object[] {username,
            roles, action});

        ModelAndView mv = new ModelAndView("securityResult");
        try {

            List<String> list = new ArrayList<String>();
            if (roles != null) {
                String[] values = roles.split(",");
                for (String value : values) {
                    if (value.trim().length() != 0) {
                        list.add(value);
                    }
                }
            }

            securityService.authorize(username, list, action);
            mv.addObject("msg", "Authorization succeeded.");
        } catch (AuthorizationException e) {
            mv.addObject("msg", "Authorization failed.");
        }

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Clears security cache data.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/clearSecurityCacheData", method = RequestMethod.GET)
    public ModelAndView clearSecurityCacheData() throws OPMException {
        String signature = TestController.class.getName() + "#clearSecurityCacheData()";

        LoggingHelper.logEntrance(LOG, signature, null, null);

        securityService.clearSecurityCacheData();

        ModelAndView mv = new ModelAndView("securityResult");
        mv.addObject("msg", "Security cache data was successfully cleared.");

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Shows the preference.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewPreference", method = RequestMethod.GET)
    public ModelAndView viewPreference() throws OPMException {
        String signature = TestController.class.getName() + "#viewPreference()";

        LoggingHelper.logEntrance(LOG, signature, null, null);

        ModelAndView mv = new ModelAndView("viewPreference");

        ServiceCreditPreference preference = serviceCreditPreferenceService.getServiceCreditPreference();
        if (preference == null) {
            preference = new ServiceCreditPreference();
        }

        mv.addObject("preference", preference);

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Sets the preference.
     *
     * @param preference
     *            the preference
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/setPreference", method = RequestMethod.POST)
    public ModelAndView setPreference(@ModelAttribute ServiceCreditPreference preference) throws OPMException {
        String signature = TestController.class.getName() + "#setPreference(ServiceCreditPreference preference)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"preference"}, new Object[] {preference});

        serviceCreditPreferenceService.setServiceCreditPreference(preference);

        ModelAndView mv = new ModelAndView("setPreference");
        mv.addObject("msg", "Preference was successfully updated.");

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Shows the lookup entities.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/lookup", method = RequestMethod.GET)
    public ModelAndView viewLookup() throws OPMException {
        String signature = TestController.class.getName() + "#viewLookup()";

        LoggingHelper.logEntrance(LOG, signature, null, null);

        ModelAndView mv = new ModelAndView("lookup");
        mv.addObject("retirementTypes", lookupService.getLookups("RetirementType"));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Shows the printouts.
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewPrintouts", method = RequestMethod.GET)
    public ModelAndView viewPrintouts() throws OPMException {
        String signature = TestController.class.getName() + "#viewPrintouts()";

        LoggingHelper.logEntrance(LOG, signature, null, null);

        ModelAndView mv = new ModelAndView("viewPrintouts");
        mv.addObject("printouts", batchPrintoutArchiveService.getAvailablePrintouts());

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Shows the printout content.
     *
     * @param name
     *            the name
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewPrintout", method = RequestMethod.GET)
    public ModelAndView viewPrintout(@RequestParam String name) throws OPMException {
        String signature = TestController.class.getName() + "#viewPrintout(String name)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"name"}, new Object[] {name});

        ModelAndView mv = new ModelAndView("viewPrintout");
        mv.addObject("printoutContent", new String(batchPrintoutArchiveService.getPrintout(name)));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Shows the help items.
     *
     * @param term
     *            the term
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewHelpItems", method = RequestMethod.GET)
    public ModelAndView viewHelpItems(@RequestParam String term) throws OPMException {
        String signature = TestController.class.getName() + "#viewHelpItems(String term)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"term"}, new Object[] {term});

        ModelAndView mv = new ModelAndView("viewHelpItems");
        mv.addObject("helpItems", helpService.search(term));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Shows the help item.
     *
     * @param id
     *            the id
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/viewHelpItem", method = RequestMethod.GET)
    public ModelAndView viewHelpItem(@RequestParam long id) throws OPMException {
        String signature = TestController.class.getName() + "#viewHelpItem(long id)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"id"}, new Object[] {id});

        ModelAndView mv = new ModelAndView("viewHelpItem");
        mv.addObject("helpItem", helpService.get(id));

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }

    /**
     * Demonstrates a call to add an audit record.
     *
     * @param audit
     *            the audit record
     *
     * @return the model and view.
     * @throws OPMException
     *             for any errors encountered, expected to be handled by exception resolvers future iterations.
     */
    @RequestMapping(value = "/addAudit", method = RequestMethod.POST)
    public ModelAndView addAudit(@ModelAttribute AuditRecord audit) throws OPMException {
        String signature = TestController.class.getName() + "#addAudit(AuditRecord audit)";

        LoggingHelper.logEntrance(LOG, signature, new String[] {"audit"}, new Object[] {audit});

        audit.setDate(new Date());

        ModelAndView mv = new ModelAndView("auditResult");
        auditService.audit(audit);
        mv.addObject("audit", audit);

        // exceptions are expected to be logged by the exception resolver
        LoggingHelper.logExit(LOG, signature, new Object[] {mv});
        return mv;
    }
}
