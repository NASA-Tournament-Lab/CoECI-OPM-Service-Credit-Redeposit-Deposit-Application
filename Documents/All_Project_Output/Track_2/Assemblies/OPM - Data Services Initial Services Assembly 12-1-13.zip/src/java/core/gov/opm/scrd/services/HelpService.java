/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.HelpItem;

import java.util.List;

/**
 * <p>
 * This interface defines a contract for retrieving help data.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> Implementations should be thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public interface HelpService {
    /**
     * Searches for the help items based on the search term.
     *
     * @param term
     *            the search term to appear in the help item.
     *
     * @return The list of HelpItem instances containing help information, can not be null/contain null elements.
     *
     * @throws IllegalArgumentException
     *             if term is null/empty.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public List<HelpItem> search(String term) throws OPMException;

    /**
     * Retrieves the help item by id.
     *
     * @param helpItemId
     *            the id of help item to retrieve.
     *
     * @return The help item for id or null if it can not be found.
     *
     * @throws IllegalArgumentException
     *             if helpItemId is not positive.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public HelpItem get(long helpItemId) throws OPMException;
}
