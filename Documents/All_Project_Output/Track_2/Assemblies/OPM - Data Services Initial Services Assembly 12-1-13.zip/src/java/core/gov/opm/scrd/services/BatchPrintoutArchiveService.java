/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import java.util.List;
import gov.opm.scrd.entities.application.Printout;

/**
 * <p>
 * This interface defines a contract for retrieving printout data.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> Implementations should be thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public interface BatchPrintoutArchiveService {
    /**
     * Returns the list of available printouts in the application.
     *
     * @return List of available printouts, can not be null
     *
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public List<Printout> getAvailablePrintouts() throws OPMException;

    /**
     * Return the content of the printout by name.
     *
     * @param name
     *            the printout name.
     *
     * @return Printout contents as byte array, can be null.
     *
     * @throws IllegalArgumentException
     *             if name is null/empty.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public byte[] getPrintout(String name) throws OPMException;
}
