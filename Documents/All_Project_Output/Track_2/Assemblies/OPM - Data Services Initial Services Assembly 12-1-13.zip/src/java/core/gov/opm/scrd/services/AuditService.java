/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.AuditRecord;

/**
 * <p>
 * This interface defines a contract for managing audit. It provides single method for persisting audit record.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> Implementations should be thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public interface AuditService {
    /**
     * Stores the audit record.
     *
     * @param entity
     *            the audit record to store.
     *
     * @throws IllegalArgumentException
     *             if entity is null.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public void audit(AuditRecord entity) throws OPMException;
}
