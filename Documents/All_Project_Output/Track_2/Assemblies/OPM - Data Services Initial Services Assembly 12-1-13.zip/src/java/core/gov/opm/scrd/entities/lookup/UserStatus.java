/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import gov.opm.scrd.entities.common.NamedEntity;

/**
 * <p>
 * Represents the named entity specifying the status of the user.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class UserStatus extends NamedEntity {
    /**
     * Creates an instance of UserStatus.
     */
    public UserStatus() {
        // Empty
    }
}