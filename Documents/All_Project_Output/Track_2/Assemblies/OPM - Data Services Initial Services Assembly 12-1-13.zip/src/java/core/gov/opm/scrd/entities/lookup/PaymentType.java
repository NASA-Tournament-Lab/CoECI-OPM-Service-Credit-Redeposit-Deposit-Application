/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

/**
 * <p>
 * Represents the enumeration specifying the type of the payment. This enumeration is used to differentiate the payments
 * and use proper payment view when showing the item.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This enumeration is immutable and thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public enum PaymentType {
    /**
     * Represents ordinary payment status. Payment with such status will be returned as Payment entity.
     */
    ORDINARY,

    /**
     * Represents suspended payment status. Payment with such status will be returned as SuspendedPayment view of the
     * Payment entity.
     */
    SUSPENDED_PAYMENT,

    /**
     * Represents payment move status. Payment with such status will be returned as PaymentMove view of the Payment
     * entity.
     */
    PAYMENT_MOVE,

    /**
     * Represents interest adjustment payment status. Payment with such status will be returned as InterestAdjustment
     * view of the Payment entity.
     */
    INTEREST_ADJUSTMENT,

    /**
     * Represents pending payment status. Payment with such status will be returned as PendingPayment view of the
     * Payment entity.
     */
    PENDING_PAYMENT
}
