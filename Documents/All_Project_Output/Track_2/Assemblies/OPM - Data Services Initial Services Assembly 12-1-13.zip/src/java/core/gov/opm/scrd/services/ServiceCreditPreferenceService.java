/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.ServiceCreditPreference;

/**
 * <p>
 * This interface defines a contract for retrieving and saving service credit preference data.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> Implementations should be thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public interface ServiceCreditPreferenceService {
    /**
     * Returns the service credit preference used in the application.
     *
     * @return the service credit preference used in the application or null if it is not set yet.
     *
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public ServiceCreditPreference getServiceCreditPreference() throws OPMException;

    /**
     * Saves the service credit preference used in the application.
     *
     * @param preference
     *            the service credit preference used in the application.
     *
     * @throws IllegalArgumentException
     *             if preference is null.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public void setServiceCreditPreference(ServiceCreditPreference preference) throws OPMException;
}
