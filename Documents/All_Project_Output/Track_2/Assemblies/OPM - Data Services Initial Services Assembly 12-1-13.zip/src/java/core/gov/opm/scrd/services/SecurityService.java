/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import java.util.List;

/**
 * <p>
 * This interface defines a contract for managing security related functionality, specifically authorization. It
 * provides a single method to check whether user given his list of roles is authorized to perform the given action.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> Implementations should be thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public interface SecurityService {
    /**
     * Checks whether user is authorized to perform a particular action or access a given widget.
     *
     * @param username
     *            the name of the user performing the operation.
     * @param roles
     *            the list of roles associated with user.
     * @param action
     *            the name of the action or the widget user is accessing.
     *
     * @throws IllegalArgumentException
     *             if username or action is null/empty, roles is null or contain null/empty elements.
     * @throws AuthorizationException
     *             if authorization fails.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public void authorize(String username, List<String> roles, String action) throws OPMException;

    /**
     * Clears the cache security data.
     *
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public void clearSecurityCacheData() throws OPMException;
}
