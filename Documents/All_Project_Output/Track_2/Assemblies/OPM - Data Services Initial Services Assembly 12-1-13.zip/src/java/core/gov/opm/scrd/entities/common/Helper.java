/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

import gov.opm.scrd.services.OPMConfigurationException;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <p>
 * Helper class for the component. It provides useful common methods for all the classes in this component.
 * </p>
 *
 * <p>
 * <em>Changes in 1.1 (OPM - Data Services - Initial Services Assembly 1.0):</em>
 * <ol>
 * <li>Added new methods (except toString).</li>
 * </ol>
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class has no state, and thus it is thread safe.
 * </p>
 *
 * @author sparemax
 * @version 1.1
 * @since OPM - Data Services - Entities Assembly 1.0
 */
public final class Helper {
    /**
     * <p>
     * Represents the object mapper.
     * </p>
     */
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    /**
     * Maximum log details text length.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    private static final int MAX_ARGUMENTS = 4066;

    /**
     * Maximum log exception text length.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    private static final int MAX_EXCEPTION = 1024;

    /**
     * Maximum log method text length.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    private static final int MAX_SIGNATURE = 100;

    /**
     * <p>
     * Represents the entrance message.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     * </p>
     */
    private static final String MESSAGE_ENTRANCE = "Entering method %1$s.";

    /**
     * <p>
     * Represents the exit message.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     * </p>
     */
    private static final String MESSAGE_EXIT = "Exiting method %1$s.";

    /**
     * <p>
     * Represents the error message.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     * </p>
     */
    private static final String MESSAGE_ERROR = "Error in method %1$s. Details:";

    /**
     * <p>
     * Prevents to create a new instance.
     * </p>
     */
    private Helper() {
        // empty
    }

    /**
     * <p>
     * Validates the value of a variable. The value can not be <code>null</code>.
     * </p>
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the value of the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     *
     * @throws IllegalArgumentException
     *             if the value of the variable is <code>null</code>.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void checkNull(Logger logger, String signature, Object value, String name) {
        if (value == null) {
            // Log exception
            throw Helper.logException(logger, signature, new IllegalArgumentException("'" + name
                + "' should not be null."));
        }
    }

    /**
     * <p>
     * Validates the value of a string. The value can not be <code>null</code> or an empty string.
     * </p>
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the value of the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     *
     * @throws IllegalArgumentException
     *             if the given string is <code>null</code> or an empty string.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void checkNullOrEmpty(Logger logger, String signature, String value, String name) {
        checkNull(logger, signature, value, name);

        if (value.trim().length() == 0) {
            // Log exception
            throw Helper.logException(logger, signature, new IllegalArgumentException("'" + name
                + "' should not be an empty string."));
        }
    }

    /**
     * <p>
     * Validates the value of a long.
     * </p>
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the value of the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     *
     * @throws IllegalArgumentException
     *             if the given long value is not positive.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void checkPositive(Logger logger, String signature, long value, String name) {
        if (value <= 0) {
            // Log the exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name + "' should be positive."));
        }
    }

    /**
     * Converts the object to string.
     *
     * @param obj
     *            the object
     *
     * @return the string representation of the object.
     */
    public static String toString(Object obj) {
        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            return "";
        }
    }

    /**
     * <p>
     * Checks state of object.
     * </p>
     *
     * @param isInvalid
     *            the state of object.
     * @param message
     *            the error message.
     *
     * @throws OPMConfigurationException
     *             if isInvalid is <code>true</code>
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void checkState(boolean isInvalid, String message) {
        if (isInvalid) {
            throw new OPMConfigurationException(message);
        }
    }

    /**
     * <p>
     * Logs for entrance into public methods at <code>DEBUG</code> level.
     * </p>
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param paramNames
     *            the names of parameters to log .
     * @param params
     *            the values of parameters to log.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void logEntrance(Logger logger, String signature, String[] paramNames, Object[] params) {
        if (logger == null) {
            // No logging
            return;
        }

        // Do logging
        logger.debug(truncate(String.format(MESSAGE_ENTRANCE, signature), MAX_SIGNATURE));

        if (paramNames != null) {
            // Log parameters
            logParameters(logger, paramNames, params);
        }
    }

    /**
     * <p>
     * Logs for exit from public methods at <code>DEBUG</code> level.
     * </p>
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the return value to log.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static void logExit(Logger logger, String signature, Object[] value) {
        if (logger == null) {
            // No logging
            return;
        }

        // Do logging
        logger.debug(truncate(String.format(MESSAGE_EXIT, signature), MAX_SIGNATURE));

        if (value != null) {
            // Log return value
            logger.debug(truncate(String.format("Output parameter: " + value[0], signature), MAX_ARGUMENTS));
        }
    }

    /**
     * <p>
     * Logs the given exception and message at <code>ERROR</code> level.
     * </p>
     *
     * @param <T>
     *            the exception type.
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to log.
     * @param e
     *            the exception to log.
     *
     * @return the passed in exception.
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    public static <T extends Throwable> T logException(Logger logger, String signature, T e) {
        if (logger != null) {
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));

            // Do logging
            logger.error(truncate(String.format(MESSAGE_ERROR, signature) + writer.toString(), MAX_EXCEPTION));
        }
        return e;
    }

    /**
     * <p>
     * Logs the parameters at <code>DEBUG</code> level.
     * </p>
     *
     *
     * @param logger
     *            the logger object (not <code>null</code>).
     * @param paramNames
     *            the names of parameters to log (not <code>null</code>).
     * @param params
     *            the values of parameters to log (not <code>null</code>).
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    private static void logParameters(Logger logger, String[] paramNames, Object[] params) {
        StringBuilder sb = new StringBuilder("Input parameters: {");

        for (int i = 0; i < params.length; i++) {

            if (i > 0) {
                // Append a comma
                sb.append(", ");
            }

            sb.append(paramNames[i]).append(":").append(params[i]);
        }
        sb.append("}.");

        // Do logging
        logger.debug(truncate(sb.toString(), MAX_ARGUMENTS));
    }

    /**
     * Trims the message to a more manageable length.
     *
     * @param message
     *            the message to trim
     * @param max
     *            the threshold for the message length
     * @return the trimmed message only if it exceeds the threshold, otherwise, the same as the input
     *
     * @since 1.1 (OPM - Data Services - Initial Services Assembly 1.0)
     */
    private static String truncate(String message, int max) {
        if (message.length() > max) {
            return message.substring(0, max);
        }
        return message;
    }
}
