/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.common.NamedEntity;

import java.util.List;

/**
 * <p>
 * This interface defines a contract for retrieving lookup entities.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> Implementations should be thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public interface LookupService {
    /**
     * Returns the list of entities for the given lookup type.
     *
     * @param lookupType
     *            the lookup type to retrieve.
     *
     * @return The list of lookup entities for the given type, can not be null/contain null elements.
     *
     * @throws IllegalArgumentException
     *             if lookupType is null/empty.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    public List<NamedEntity> getLookups(String lookupType) throws OPMException;
}
