/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import gov.opm.scrd.entities.common.Helper;
import gov.opm.scrd.services.OPMConfigurationException;

import javax.annotation.PostConstruct;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ejb.interceptor.SpringBeanAutowiringInterceptor;

/**
 * <p>
 * This class is the base class for all services the use persistence. It simply aggregates JPA EntityManager and the
 * logger of the application.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
@Interceptors(SpringBeanAutowiringInterceptor.class)
public abstract class BaseService {
    /**
     * Represents logger used for logging. It is injected by Spring. It can be null if logging is turned off.
     */
    @Autowired
    private Logger logger;

    /**
     * Represents the EntityManager instance for managing data in the persistence. It is injected by Spring. It can not
     * be null after injected.
     */
    @PersistenceContext(unitName = "opmUnitName")
    private EntityManager entityManager;

    /**
     * Creates an instance of BaseService.
     */
    protected BaseService() {
        // Empty
    }

    /**
     * Gets the logger used for logging.
     *
     * @return the logger used for logging.
     */
    protected Logger getLogger() {
        return logger;
    }

    /**
     * Gets the EntityManager instance for managing data in the persistence.
     *
     * @return the EntityManager instance for managing data in the persistence.
     */
    protected EntityManager getEntityManager() {
        return entityManager;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws OPMConfigurationException
     *             if the instance was not initialized properly (entityManager is null).
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(entityManager == null, "'entityManager' can't be null.");
    }
}
