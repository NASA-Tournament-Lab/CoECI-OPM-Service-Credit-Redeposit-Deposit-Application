/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

import gov.opm.scrd.entities.application.User;
import gov.opm.scrd.entities.common.Helper;
import gov.opm.scrd.entities.lookup.ActionTab;
import gov.opm.scrd.services.EntityNotFoundException;
import gov.opm.scrd.services.OPMConfigurationException;
import gov.opm.scrd.services.OPMException;
import gov.opm.scrd.services.UserService;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.PersistenceException;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <p>
 * This class is the implementation of the UserService. It utilizes JPA EntityManager for necessary operations.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
@Stateless
@Local(UserService.class)
@LocalBean
@TransactionManagement(TransactionManagementType.CONTAINER)
public class UserServiceImpl extends BaseService implements UserService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASS_NAME = UserServiceImpl.class.getName();

    /**
     * <p>
     * Represents the JPQL to query User.
     * </p>
     */
    private static final String JPQL_QUERY_USER = "SELECT e FROM User e WHERE e.deleted = false";

    /**
     * <p>
     * Represents the JPQL to query User by role name.
     * </p>
     */
    private static final String JPQL_QUERY_USER_BY_ROLE_NAME = "SELECT e FROM User e"
        + " WHERE e.deleted = false AND e.role.name = :supervisorRoleName";

    /**
     * <p>
     * Represents the JPQL to query User by username.
     * </p>
     */
    private static final String JPQL_QUERY_USER_BY_USERNAME = "SELECT e FROM User e"
        + " WHERE e.deleted = false AND e.username = :username";

    /**
     * <p>
     * Represents the JPQL to query User by id.
     * </p>
     */
    private static final String JPQL_QUERY_USER_BY_ID = "SELECT e FROM User e"
        + " WHERE e.deleted = false AND e.id = :id";

    /**
     * Represents the name of Role instance which corresponds to supervisor role. It is injected by Spring. It can not
     * be null after injected.
     */
    @Autowired
    private String supervisorRoleName;

    /**
     * Creates an instance of UserServiceImpl.
     */
    public UserServiceImpl() {
        // Empty
    }

    /**
     * Retrieves all available users.
     *
     * @return List of available users, can not be null/contain null elements.
     *
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<User> getAll() throws OPMException {
        String signature = CLASS_NAME + "#getAll()";
        Logger logger = getLogger();

        Helper.logEntrance(logger, signature, null, null);

        try {
            List<User> result = getEntityManager().createQuery(JPQL_QUERY_USER, User.class)
                .getResultList();

            Helper.logExit(logger, signature, new Object[] {result});
            return result;
        } catch (IllegalStateException e) {
            throw Helper.logException(logger, signature,
                new OPMException("The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            throw Helper.logException(logger, signature, new OPMException(
                "An error has occurred when accessing persistence.", e));
        }
    }

    /**
     * Retrieves all available supervisors.
     *
     * @return List of available users with supervisor role, can not be null/contain null elements.
     *
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<User> getSupervisors() throws OPMException {
        String signature = CLASS_NAME + "#getSupervisors()";
        Logger logger = getLogger();

        Helper.logEntrance(logger, signature, null, null);

        try {
            List<User> result = getEntityManager().createQuery(JPQL_QUERY_USER_BY_ROLE_NAME, User.class)
                .setParameter("supervisorRoleName", supervisorRoleName)
                .getResultList();

            Helper.logExit(logger, signature, new Object[] {result});
            return result;
        } catch (IllegalStateException e) {
            throw Helper.logException(logger, signature,
                new OPMException("The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            throw Helper.logException(logger, signature, new OPMException(
                "An error has occurred when accessing persistence.", e));
        }
    }

    /**
     * Retrieves user by id.
     *
     * @param userId
     *            the id of user to retrieve.
     *
     * @return User for the id or null if there is no such user.
     *
     * @throws IllegalArgumentException
     *             if userId is not positive.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public User get(long userId) throws OPMException {
        String signature = CLASS_NAME + "#get(long userId)";
        Logger logger = getLogger();

        Helper.logEntrance(logger, signature,
            new String[] {"userId"},
            new Object[] {userId});

        Helper.checkPositive(logger, signature, userId, "userId");

        try {
            User result = getById(logger, signature, userId, false);

            Helper.logExit(logger, signature, new Object[] {result});
            return result;
        } catch (IllegalStateException e) {
            throw Helper.logException(logger, signature,
                new OPMException("The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            throw Helper.logException(logger, signature, new OPMException(
                "An error has occurred when accessing persistence.", e));
        }
    }

    /**
     * Retrieves user by username.
     *
     * @param username
     *            the name of user to retrieve.
     *
     * @return User for the name or null if there is no such user.
     *
     * @throws IllegalArgumentException
     *             if username is null/empty.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public User getByUsername(String username) throws OPMException {
        String signature = CLASS_NAME + "#getByUsername(String username)";
        Logger logger = getLogger();

        Helper.logEntrance(logger, signature,
            new String[] {"username"},
            new Object[] {username});

        Helper.checkNullOrEmpty(logger, signature, username, "username");

        try {
            List<User> list = getEntityManager().createQuery(JPQL_QUERY_USER_BY_USERNAME, User.class)
                .setParameter("username", username)
                .getResultList();

            User result = list.isEmpty() ? null : list.get(0);

            Helper.logExit(logger, signature, new Object[] {result});
            return result;
        } catch (IllegalStateException e) {
            throw Helper.logException(logger, signature,
                new OPMException("The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            throw Helper.logException(logger, signature, new OPMException(
                "An error has occurred when accessing persistence.", e));
        }
    }

    /**
     * Updates user.
     *
     * @param user
     *            the user to update.
     *
     * @throws IllegalArgumentException
     *             if user is null.
     * @throws EntityNotFoundException
     *             if there is no such user to update.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(User user) throws OPMException {
        String signature = CLASS_NAME + "#update(User user)";
        Logger logger = getLogger();

        Helper.logEntrance(logger, signature,
            new String[] {"user"},
            new Object[] {user});

        Helper.checkNull(logger, signature, user, "user");

        try {
            // Check user
            getById(logger, signature, user.getId(), true);

            getEntityManager().merge(user);

            Helper.logExit(logger, signature, null);
        } catch (IllegalStateException e) {
            throw Helper.logException(logger, signature,
                new OPMException("The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            throw Helper.logException(logger, signature, new OPMException(
                "An error has occurred when accessing persistence.", e));
        }
    }

    /**
     * Sets the default tab for user.
     *
     * @param userId
     *            the id of user to set default tab.
     * @param tab
     *            the tab to set for default.
     *
     * @throws IllegalArgumentException
     *             if tab is null or userId is not positive.
     * @throws EntityNotFoundException
     *             if there is no such user to update.
     * @throws OPMException
     *             if there is any problem when executing the method.
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void setDefaultTab(long userId, ActionTab tab) throws OPMException {
        String signature = CLASS_NAME + "#setDefaultTab(long userId, ActionTab tab)";
        Logger logger = getLogger();

        Helper.logEntrance(logger, signature,
            new String[] {"userId", "tab"},
            new Object[] {userId, tab});

        Helper.checkPositive(logger, signature, userId, "userId");
        Helper.checkNull(logger, signature, tab, "tab");

        try {
            // Get user
            User user = getById(logger, signature, userId, true);

            user.setDefaultTab(tab);
            getEntityManager().merge(user);

            Helper.logExit(logger, signature, null);
        } catch (IllegalStateException e) {
            throw Helper.logException(logger, signature,
                new OPMException("The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            throw Helper.logException(logger, signature, new OPMException(
                "An error has occurred when accessing persistence.", e));
        }
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws OPMConfigurationException
     *             if the instance was not initialized properly (entityManager or supervisorRoleName is null).
     */
    @PostConstruct
    @Override
    protected void checkInit() {
        super.checkInit();

        Helper.checkState(supervisorRoleName == null, "'supervisorRoleName' can't be null.");
    }


    /**
     * Retrieves user by id.
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to log.
     * @param userId
     *            the id of user to retrieve.
     * @param checkIfExists
     *            true for checking if the user exists.
     *
     * @return User for the id or null if there is no such user when checkIfExists is false.
     *
     * @throws IllegalStateException
     *             if the entity manager has been closed.
     * @throws PersistenceException
     *             if there is any problem when executing the method.
     * @throws EntityNotFoundException
     *             if there is no such user when checkIfExists is true.
     */
    private User getById(Logger logger, String signature, long userId, boolean checkIfExists)
        throws EntityNotFoundException {
        List<User> list = getEntityManager().createQuery(JPQL_QUERY_USER_BY_ID, User.class)
            .setParameter("id", userId)
            .getResultList();

        if (list.isEmpty()) {
            if (checkIfExists) {
                throw Helper.logException(logger, signature, new EntityNotFoundException("User with id '" + userId
                    + "' is not found."));
            }

            return null;
        }

        return list.get(0);
    }
}
