/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * This is the base class for all entities with a name.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public abstract class NamedEntity extends IdentifiableEntity {
    /**
     * <p>
     * Represents the name of the entity. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String name;

    /**
     * Creates an instance of NamedEntity.
     */
    protected NamedEntity() {
        // Empty
    }

    /**
     * Gets the name of the entity.
     *
     * @return the name of the entity.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the entity.
     *
     * @param name
     *            the name of the entity.
     */
    public void setName(String name) {
        this.name = name;
    }
}