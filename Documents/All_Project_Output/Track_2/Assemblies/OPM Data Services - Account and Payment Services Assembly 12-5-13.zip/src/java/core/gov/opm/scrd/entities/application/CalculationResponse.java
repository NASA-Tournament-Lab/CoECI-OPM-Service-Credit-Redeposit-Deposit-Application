/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

/**
 * Represents a calculation response.
 *
 * <b>Thread Safety</b> This class is mutable and not thread safe.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public class CalculationResponse implements RuleResponse {

    /**
     * The calculated amount.
     */
    private float amount;

    /**
     * Empty constructor.
     */
    public CalculationResponse() {
    }

    /**
     * Gets the value of the field <code>amount</code>.
     *
     * @return the amount
     */
    public float getAmount() {
        return amount;
    }

    /**
     * Sets the value of the field <code>amount</code>.
     *
     * @param amount the amount to set
     */
    public void setAmount(float amount) {
        this.amount = amount;
    }

    /**
     * Gets a readable string representation of this entity.
     *
     * @return this entity as a string.
     */
    @Override
    public String toString() {
        return "CalculationResponse [amount=" + amount + "]";
    }
}
