/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;



/**
 * <p>
 * Base class for calculation response.
 * </p>
 * <p>
 * <b>Thread Safety:</b> This class is thread safe since it does not contain properties.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 * @since OPM Rules Engine Models Exceptions and Interest Calculation v1.0 Assembly
 */
public abstract class BaseCalculationResponse implements RuleResponse {

    /**
     * Creates the instance of BaseCalculationResponse.
     */
    protected BaseCalculationResponse() {
        // does nothing
    }
}
