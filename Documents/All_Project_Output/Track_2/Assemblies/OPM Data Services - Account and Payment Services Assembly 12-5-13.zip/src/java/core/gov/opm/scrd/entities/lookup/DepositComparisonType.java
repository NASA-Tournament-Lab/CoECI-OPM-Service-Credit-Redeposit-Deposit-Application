/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

/**
 * <p>
 * Represents the enumeration specifying the comparison type of deposit date to be used in PaymentSearchFilter.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This enumeration is immutable and thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public enum DepositComparisonType {
    /**
     * Represents '&lt;' comparison type.
     */
    DEPOSITED_BEFORE,

    /**
     * Represents '&lt;=' comparison type.
     */
    DEPOSITED_BEFORE_OR_ON,

    /**
     * Represents '=' comparison type.
     */
    DEPOSITED_ON,

    /**
     * Represents '&gt;=' comparison type.
     */
    DEPOSITED_ON_OR_AFTER,

    /**
     * Represents '&gt;' comparison type.
     */
    DEPOSITED_AFTER,

    /**
     * Represents 'BETWEEN' comparison type.
     */
    DEPOSITED_BETWEEN
}
