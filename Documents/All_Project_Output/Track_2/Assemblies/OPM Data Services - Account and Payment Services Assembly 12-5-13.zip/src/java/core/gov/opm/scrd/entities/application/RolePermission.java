/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

/**
 * <p>
 * This is the class representing the permissions table for the specific user role.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class RolePermission extends IdentifiableEntity {
    /**
     * <p>
     * Represents the role of the user. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String role;
    /**
     * <p>
     * Represents the action performed by the user. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private String action;

    /**
     * Creates an instance of RolePermission.
     */
    public RolePermission() {
        // Empty
    }

    /**
     * Gets the role of the user.
     *
     * @return the role of the user.
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the role of the user.
     *
     * @param role
     *            the role of the user.
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * Gets the action performed by the user.
     *
     * @return the action performed by the user.
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the action performed by the user.
     *
     * @param action
     *            the action performed by the user.
     */
    public void setAction(String action) {
        this.action = action;
    }
}