/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import gov.opm.scrd.entities.common.NamedEntity;

/**
 * <p>
 * Represents the named entity specifying the role of the user.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class Role extends NamedEntity {
    /**
     * Creates an instance of Role.
     */
    public Role() {
        // Empty
    }

}