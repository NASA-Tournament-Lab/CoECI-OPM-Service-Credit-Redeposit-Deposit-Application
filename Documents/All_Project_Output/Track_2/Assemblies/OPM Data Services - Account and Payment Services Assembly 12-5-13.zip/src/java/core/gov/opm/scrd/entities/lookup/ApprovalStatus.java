/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

/**
 * <p>
 * Represents the enumeration specifying the approval status of the account.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This enumeration is immutable and thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public enum ApprovalStatus {
    /**
     * Represents pending account status.
     */
    PENDING,

    /**
     * Represents approved account status.
     */
    APPROVED,

    /**
     * Represents disapproved account status.
     */
    DISAPPROVED
}
