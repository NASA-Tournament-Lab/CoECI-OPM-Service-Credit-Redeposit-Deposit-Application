/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;
import gov.opm.scrd.entities.lookup.AppointmentType;
import gov.opm.scrd.entities.lookup.PayType;
import gov.opm.scrd.entities.lookup.PeriodType;
import gov.opm.scrd.entities.lookup.RetirementType;
import gov.opm.scrd.entities.lookup.ServiceType;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * This is the class representing the single item of the calculation.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class Calculation extends IdentifiableEntity {
    /**
     * <p>
     * Represents the begin date of calculation item. It is managed with a getter and setter. It may have any value. It
     * is fully mutable.
     * </p>
     */
    private Date beginDate;
    /**
     * <p>
     * Represents the end date of calculation item. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private Date endDate;
    /**
     * <p>
     * Represents the retirement type of calculation item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private RetirementType retirementType;
    /**
     * <p>
     * Represents the period type of calculation item. It is managed with a getter and setter. It may have any value. It
     * is fully mutable.
     * </p>
     */
    private PeriodType periodType;
    /**
     * <p>
     * Represents the appointment type of calculation item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private AppointmentType appointmentType;
    /**
     * <p>
     * Represents the service type of calculation item. It is managed with a getter and setter. It may have any value.
     * It is fully mutable.
     * </p>
     */
    private ServiceType serviceType;
    /**
     * <p>
     * Represents the amount of calculation item. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private BigDecimal amount;
    /**
     * <p>
     * Represents the pay type of calculation item. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private PayType payType;

    /**
     * Creates an instance of Calculation.
     */
    public Calculation() {
        // Empty
    }

    /**
     * Gets the begin date of calculation item.
     *
     * @return the begin date of calculation item.
     */
    public Date getBeginDate() {
        return beginDate;
    }

    /**
     * Sets the begin date of calculation item.
     *
     * @param beginDate
     *            the begin date of calculation item.
     */
    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    /**
     * Gets the end date of calculation item.
     *
     * @return the end date of calculation item.
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the end date of calculation item.
     *
     * @param endDate
     *            the end date of calculation item.
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * Gets the retirement type of calculation item.
     *
     * @return the retirement type of calculation item.
     */
    public RetirementType getRetirementType() {
        return retirementType;
    }

    /**
     * Sets the retirement type of calculation item.
     *
     * @param retirementType
     *            the retirement type of calculation item.
     */
    public void setRetirementType(RetirementType retirementType) {
        this.retirementType = retirementType;
    }

    /**
     * Gets the period type of calculation item.
     *
     * @return the period type of calculation item.
     */
    public PeriodType getPeriodType() {
        return periodType;
    }

    /**
     * Sets the period type of calculation item.
     *
     * @param periodType
     *            the period type of calculation item.
     */
    public void setPeriodType(PeriodType periodType) {
        this.periodType = periodType;
    }

    /**
     * Gets the appointment type of calculation item.
     *
     * @return the appointment type of calculation item.
     */
    public AppointmentType getAppointmentType() {
        return appointmentType;
    }

    /**
     * Sets the appointment type of calculation item.
     *
     * @param appointmentType
     *            the appointment type of calculation item.
     */
    public void setAppointmentType(AppointmentType appointmentType) {
        this.appointmentType = appointmentType;
    }

    /**
     * Gets the service type of calculation item.
     *
     * @return the service type of calculation item.
     */
    public ServiceType getServiceType() {
        return serviceType;
    }

    /**
     * Sets the service type of calculation item.
     *
     * @param serviceType
     *            the service type of calculation item.
     */
    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    /**
     * Gets the amount of calculation item.
     *
     * @return the amount of calculation item.
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the amount of calculation item.
     *
     * @param amount
     *            the amount of calculation item.
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * Gets the pay type of calculation item.
     *
     * @return the pay type of calculation item.
     */
    public PayType getPayType() {
        return payType;
    }

    /**
     * Sets the pay type of calculation item.
     *
     * @param payType
     *            the pay type of calculation item.
     */
    public void setPayType(PayType payType) {
        this.payType = payType;
    }
}