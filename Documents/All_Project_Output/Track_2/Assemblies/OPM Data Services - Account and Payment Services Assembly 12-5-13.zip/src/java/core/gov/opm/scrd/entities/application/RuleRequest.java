/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

/**
 * This is a marker interface for rule service requests.
 *
 * @author argolite, j3_guile
 * @version 1.0
 */
public interface RuleRequest {

}
