/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * Represents the sort order used in search operations of the application.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This enumeration is immutable and thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public enum SortOrder {
    /**
     * Represents the ascending sort order.
     */
    ASC,

    /**
     * Represents the descending sort order.
     */
    DESC
}
