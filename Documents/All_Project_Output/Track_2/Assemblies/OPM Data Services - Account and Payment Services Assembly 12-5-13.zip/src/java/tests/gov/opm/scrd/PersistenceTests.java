/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import gov.opm.scrd.entities.application.Account;
import gov.opm.scrd.entities.application.AccountConfirmationValidation;
import gov.opm.scrd.entities.application.AccountConfirmationValidationEntry;
import gov.opm.scrd.entities.application.AccountHolder;
import gov.opm.scrd.entities.application.AccountNote;
import gov.opm.scrd.entities.application.Address;
import gov.opm.scrd.entities.application.AuditParameterRecord;
import gov.opm.scrd.entities.application.AuditRecord;
import gov.opm.scrd.entities.application.Billing;
import gov.opm.scrd.entities.application.BillingSummary;
import gov.opm.scrd.entities.application.CalculationResult;
import gov.opm.scrd.entities.application.CalculationResultItem;
import gov.opm.scrd.entities.application.CalculationVersion;
import gov.opm.scrd.entities.application.Dedeposit;
import gov.opm.scrd.entities.application.Error;
import gov.opm.scrd.entities.application.HelpItem;
import gov.opm.scrd.entities.application.Info;
import gov.opm.scrd.entities.application.Notification;
import gov.opm.scrd.entities.application.Payment;
import gov.opm.scrd.entities.application.PaymentReverse;
import gov.opm.scrd.entities.application.Printout;
import gov.opm.scrd.entities.application.Redeposit;
import gov.opm.scrd.entities.application.RefundTransaction;
import gov.opm.scrd.entities.application.RolePermission;
import gov.opm.scrd.entities.application.ServiceCreditPreference;
import gov.opm.scrd.entities.application.SummaryData;
import gov.opm.scrd.entities.application.User;
import gov.opm.scrd.entities.application.UserPermission;
import gov.opm.scrd.entities.lookup.AccountStatus;
import gov.opm.scrd.entities.lookup.ApplicationDesignation;
import gov.opm.scrd.entities.lookup.AppointmentType;
import gov.opm.scrd.entities.lookup.CalculationStatus;
import gov.opm.scrd.entities.lookup.ClaimOfficer;
import gov.opm.scrd.entities.lookup.Country;
import gov.opm.scrd.entities.lookup.FormType;
import gov.opm.scrd.entities.lookup.PayType;
import gov.opm.scrd.entities.lookup.PaymentReversalReason;
import gov.opm.scrd.entities.lookup.PaymentStatus;
import gov.opm.scrd.entities.lookup.PeriodType;
import gov.opm.scrd.entities.lookup.RetirementType;
import gov.opm.scrd.entities.lookup.Role;
import gov.opm.scrd.entities.lookup.ServiceType;
import gov.opm.scrd.entities.lookup.State;
import gov.opm.scrd.entities.lookup.Suffix;
import gov.opm.scrd.entities.lookup.TransferType;
import gov.opm.scrd.entities.lookup.UserStatus;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import junit.framework.JUnit4TestAdapter;

import org.junit.Before;
import org.junit.Test;

/**
 * <p>
 * Persistence tests for entities.
 * </p>
 *
 * <p>
 * <em>Changes in OPM - Data Services - Account and Payment Services Assembly 1.0:</em>
 * <ol>
 * <li>Changed to extend BasePersistenceTests.</li>
 * <li>Updated test cases for Account and Payment.</li>
 * </ol>
 * </p>
 *
 * @author sparemax, TCSASSEMBLER
 * @version 1.0
 */
public class PersistenceTests extends BasePersistenceTests {
    /**
     * <p>
     * Represents the schema.
     * </p>
     */
    private static final String SCHEMA = "opm.";

    /**
     * <p>
     * Represents the 'insert' action.
     * </p>
     */
    private static final String ACTION_I = "I";

    /**
     * <p>
     * Represents the 'update' action.
     * </p>
     */
    private static final String ACTION_U = "U";

    /**
     * <p>
     * Represents the 'delete' action.
     * </p>
     */
    private static final String ACTION_D = "D";

    /**
     * <p>
     * Represents the entity manager used in tests.
     * </p>
     */
    private static EntityManager entityManager;

    /**
     * <p>
     * Adapter for earlier versions of JUnit.
     * </p>
     *
     * @return a test suite.
     */
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(PersistenceTests.class);
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        entityManager = getEntityManager();
    }

    /**
     * <p>
     * Accuracy test for the class <code>Payment</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Payment() {
        Account account = getAccount();
        create(account);

        Payment entity = getPayment();
        entity.setAccountId(account.getId());

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("payment_history", "id", id, ACTION_I);

        // Retrieve
        Payment res =
            (Payment) entityManager.find(Payment.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getBatchNumber(), res.getBatchNumber());
        assertEquals("The result should be correct.", entity.getBlockNumber(), res.getBlockNumber());
        assertEquals("The result should be correct.", entity.getSequenceNumber(), res.getSequenceNumber());
        assertEquals("The result should be correct.",
            entity.getPaymentStatus().getId(), res.getPaymentStatus().getId());
        assertEquals("The result should be correct.", entity.getClaimNumber(), res.getClaimNumber());
        assertNotNull("The result should be correct.", res.getAccountHolderBirthdate());
        assertNotNull("The result should be correct.", res.getDepositDate());
        assertEquals("The result should be correct.", entity.getAmount().intValue(), res.getAmount().intValue());
        assertEquals("The result should be correct.", entity.getSsn(), res.getSsn());
        assertEquals("The result should be correct.", entity.getClaimant(), res.getClaimant());
        assertNotNull("The result should be correct.", res.getClaimantBirthdate());
        assertEquals("The result should be correct.", entity.getImportId(), res.getImportId());
        assertEquals("The result should be correct.", entity.getSequence(), res.getSequence());
        assertNotNull("The result should be correct.", res.getTransactionDate());
        assertNotNull("The result should be correct.", res.getStatusDate());
        assertEquals("The result should be correct.", entity.getApplyTo().getId(), res.getApplyTo().getId());
        assertEquals("The result should be correct.", entity.isApplyToGL(), res.isApplyToGL());
        assertEquals("The result should be correct.", entity.getNote(), res.getNote());
        assertEquals("The result should be correct.", entity.getTransactionKey(), res.getTransactionKey());
        assertEquals("The result should be correct.", entity.isAch(), res.isAch());
        assertEquals("The result should be correct.",
            entity.getAccountBalance().intValue(), res.getAccountBalance().intValue());
        assertEquals("The result should be correct.",
            entity.getAccountStatus().getId(), res.getAccountStatus().getId());
        assertEquals("The result should be correct.", entity.getMasterClaimNumber(), res.getMasterClaimNumber());
        assertNotNull("The result should be correct.", res.getMasterClaimantBirthdate());
        assertEquals("The result should be correct.",
            entity.getMasterAccountStatus().getId(), res.getMasterAccountStatus().getId());
        assertEquals("The result should be correct.",
            entity.getMasterAccountBalance().intValue(), res.getMasterAccountBalance().intValue());
        assertEquals("The result should be correct.", entity.getMasterAccountId(), res.getMasterAccountId());
        assertEquals("The result should be correct.",
            entity.getPreDepositAmount().intValue(), res.getPreDepositAmount().intValue());
        assertEquals("The result should be correct.",
            entity.getPreRedepositAmount().intValue(), res.getPreRedepositAmount().intValue());
        assertEquals("The result should be correct.",
            entity.getPostDepositAmount().intValue(), res.getPostDepositAmount().intValue());
        assertEquals("The result should be correct.",
            entity.getPostRedepositAmount().intValue(), res.getPostRedepositAmount().intValue());
        assertEquals("The result should be correct.", entity.getApprovalUser(), res.getApprovalUser());
        assertEquals("The result should be correct.",
            entity.getApprovalStatus(), res.getApprovalStatus());
        assertEquals("The result should be correct.",
            entity.getApprovalReason(), res.getApprovalReason());
        assertEquals("The result should be correct.", entity.getPaymentType(), res.getPaymentType());
        assertEquals("The result should be correct.", entity.getAccountId(), res.getAccountId());

        entity.setBatchNumber("new");

        // Update
        update(entity);

        res = (Payment) entityManager.find(Payment.class, id);

        assertEquals("The result should be correct.",
            entity.getBatchNumber(), res.getBatchNumber());

        checkHistory("payment_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (Payment) entityManager.find(Payment.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("payment_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>AccountConfirmationValidation</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_AccountConfirmationValidation() {
        Account account = getAccount();
        create(account);

        AccountConfirmationValidation entity = getAccountConfirmationValidation();
        entity.setAccountId(account.getId());

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("account_confirmation_validation_history", "id", id, ACTION_I);

        checkHistory("account_confirmation_validation_entry_history", "id", entity.getEntries().get(0).getId(),
            ACTION_I);

        // Retrieve
        AccountConfirmationValidation res =
            (AccountConfirmationValidation) entityManager.find(AccountConfirmationValidation.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getAccountId(), res.getAccountId());
        assertEquals("The result should be correct.", entity.getDataCheckStatus(), res.getDataCheckStatus());
        assertEquals("The result should be correct.",
            entity.getDataCheckStatusValidator(), res.getDataCheckStatusValidator());
        assertEquals("The result should be correct.",
            entity.getDataCheckStatusReason(), res.getDataCheckStatusReason());
        assertEquals("The result should be correct.", entity.getEntries().size(), res.getEntries().size());

        AccountConfirmationValidationEntry entry = entity.getEntries().get(0);
        AccountConfirmationValidationEntry retrievedEntry = res.getEntries().get(0);
        assertTrue("The result should be correct.", retrievedEntry.getId() > 0);
        assertEquals("The result should be correct.", entry.getFieldName(), retrievedEntry.getFieldName());
        assertEquals("The result should be correct.", entry.getValid(), retrievedEntry.getValid());

        entity.setDataCheckStatusValidator("new");

        // Update
        update(entity);

        res = (AccountConfirmationValidation) entityManager.find(AccountConfirmationValidation.class, id);

        assertEquals("The result should be correct.",
            entity.getDataCheckStatusValidator(), res.getDataCheckStatusValidator());

        checkHistory("account_confirmation_validation_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (AccountConfirmationValidation) entityManager.find(AccountConfirmationValidation.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("account_confirmation_validation_history", "id", id, ACTION_D);
        checkHistory("account_confirmation_validation_entry_history", "id", entity.getEntries().get(0).getId(),
            ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>AccountNote</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_AccountNote() {
        Account account = getAccount();
        create(account);

        AccountNote entity = getAccountNote();
        entity.setAccountId(account.getId());

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("account_note_history", "id", id, ACTION_I);

        // Retrieve
        AccountNote res = (AccountNote) entityManager.find(AccountNote.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertNotNull("The result should be correct.", res.getDate());
        assertEquals("The result should be correct.", entity.getWriter(), res.getWriter());
        assertEquals("The result should be correct.", entity.getText(), res.getText());
        assertEquals("The result should be correct.", entity.getAccountId(), res.getAccountId());

        entity.setWriter("new");

        // Update
        update(entity);

        res = (AccountNote) entityManager.find(AccountNote.class, id);

        assertEquals("The result should be correct.", entity.getWriter(), res.getWriter());

        checkHistory("account_note_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (AccountNote) entityManager.find(AccountNote.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("account_note_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Account</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Account() {
        Account entity = getAccount();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("account_history", "id", id, ACTION_I);

        AccountNote accountNote = getAccountNote();
        accountNote.setAccountId(id);
        create(accountNote);
        Payment payment = getPayment();
        payment.setAccountId(id);
        create(payment);
        AccountConfirmationValidation accountConfirmationValidation = getAccountConfirmationValidation();
        accountConfirmationValidation.setAccountId(id);
        create(accountConfirmationValidation);

        // Retrieve
        Account res = (Account) entityManager.find(Account.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getClaimNumber(), res.getClaimNumber());
        assertEquals("The result should be correct.", entity.getPlanType(), res.getPlanType());
        assertEquals("The result should be correct.", entity.getFormType().getId(), res.getFormType().getId());
        assertEquals("The result should be correct.", entity.getHolder().getId(), res.getHolder().getId());
        assertEquals("The result should be correct.", entity.getStatus().getId(), res.getStatus().getId());
        assertEquals("The result should be correct.", entity.isGrace(), res.isGrace());
        assertEquals("The result should be correct.", entity.isFrozen(), res.isFrozen());
        assertEquals("The result should be correct.", entity.getClaimOfficer(), res.getClaimOfficer());
        assertNotNull("The result should be correct.", res.getClaimOfficerAssignmentDate());
        assertNotNull("The result should be correct.", res.getClaimantBirthdate());
        assertEquals("The result should be correct.", entity.getBalance().intValue(), res.getBalance().intValue());
        assertNotNull("The result should be correct.", res.getReturnedFromRecordsDate());
        assertEquals("The result should be correct.",
            entity.getFersDepositCalculationVersions().size(), res.getFersDepositCalculationVersions().size());

        assertEquals("The result should be correct.", 1, res.getNotes().size());
        assertEquals("The result should be correct.", accountNote.getId(), res.getNotes().get(0).getId());

        BillingSummary billingSummary = entity.getBillingSummary();
        BillingSummary retrievedBillingSummary = res.getBillingSummary();
        assertTrue("The result should be correct.", retrievedBillingSummary.getId() > 0);
        assertNotNull("The result should be correct.",
            retrievedBillingSummary.getComputedDate());
        assertNotNull("The result should be correct.",
            retrievedBillingSummary.getLastDepositDate());
        assertNotNull("The result should be correct.",
            retrievedBillingSummary.getFirstBillingDate());
        assertNotNull("The result should be correct.",
            retrievedBillingSummary.getLastInterestCalculation());
        assertEquals("The result should be correct.",
            billingSummary.getTransactionType(), retrievedBillingSummary.getTransactionType());
        assertNotNull("The result should be correct.",
            retrievedBillingSummary.getLastTransactionDate());
        assertEquals("The result should be correct.",
            billingSummary.getStopACHPayments(), retrievedBillingSummary.getStopACHPayments());
        assertEquals("The result should be correct.",
            billingSummary.getBillings().size(), retrievedBillingSummary.getBillings().size());

        Billing billing = billingSummary.getBillings().get(0);
        Billing retrievedBilling = retrievedBillingSummary.getBillings().get(0);
        assertEquals("The result should be correct.",
            billing.getName(), retrievedBilling.getName());
        assertEquals("The result should be correct.",
            billing.getInitialBilling().intValue(), retrievedBilling.getInitialBilling().intValue());
        assertEquals("The result should be correct.",
            billing.getAdditionalInterest().intValue(), retrievedBilling.getAdditionalInterest().intValue());
        assertEquals("The result should be correct.",
            billing.getTotalPayments().intValue(), retrievedBilling.getTotalPayments().intValue());
        assertEquals("The result should be correct.",
            billing.getBalance().intValue(), retrievedBilling.getBalance().intValue());
        assertEquals("The result should be correct.",
            billing.getPaymentOrder(), retrievedBilling.getPaymentOrder());


        entity.setPlanType("new");

        // Update
        update(entity);

        res = (Account) entityManager.find(Account.class, id);

        assertEquals("The result should be correct.", entity.getPlanType(), res.getPlanType());

        checkHistory("account_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (Account) entityManager.find(Account.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("account_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>CalculationVersion</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_CalculationVersion() {
        CalculationVersion entity = getCalculationVersion();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("calculation_version_history", "id", id, ACTION_I);
        checkHistory("calculation_history", "id", entity.getCalculations().get(0).getId(), ACTION_I);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getId(), ACTION_I);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getItems().get(0).getId(),
            ACTION_I);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getSummary().getId(), ACTION_I);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getRedeposits().get(0).getId(),
            ACTION_I);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getDedeposits().get(0).getId(),
            ACTION_I);

        // Retrieve
        CalculationVersion res = (CalculationVersion) entityManager.find(CalculationVersion.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertEquals("The result should be correct.", entity.getCalculations().size(), res.getCalculations().size());

        assertNotNull("The result should be correct.", res.getCalculationDate());

        CalculationResult calculationResult = entity.getCalculationResult();
        CalculationResult retrievedCalculationResult = res.getCalculationResult();
        assertTrue("The result should be correct.", retrievedCalculationResult.getId() > 0);
        assertEquals("The result should be correct.",
            calculationResult.isOfficial(), retrievedCalculationResult.isOfficial());
        assertEquals("The result should be correct.",
            calculationResult.isApplyToRealPayments(), retrievedCalculationResult.isApplyToRealPayments());

        CalculationResultItem calculationResultItem = calculationResult.getItems().get(0);
        CalculationResultItem retrievedCalculationResultItem = retrievedCalculationResult.getItems().get(0);
        assertTrue("The result should be correct.", retrievedCalculationResultItem.getId() > 0);
        assertNotNull("The result should be correct.", retrievedCalculationResultItem.getStartDate());
        assertNotNull("The result should be correct.", retrievedCalculationResultItem.getEndDate());
        assertNotNull("The result should be correct.", retrievedCalculationResultItem.getMidDate());
        assertNotNull("The result should be correct.", retrievedCalculationResultItem.getEffectiveDate());
        assertEquals("The result should be correct.",
            calculationResultItem.getPeriodType().getId(), retrievedCalculationResultItem.getPeriodType().getId());
        assertEquals("The result should be correct.",
            calculationResultItem.getDeductionAmount().intValue(),
            retrievedCalculationResultItem.getDeductionAmount().intValue());
        assertEquals("The result should be correct.",
            calculationResultItem.getTotalInterest().intValue(),
            retrievedCalculationResultItem.getTotalInterest().intValue());
        assertEquals("The result should be correct.",
            calculationResultItem.getPaymentsApplied().intValue(),
            retrievedCalculationResultItem.getPaymentsApplied().intValue());
        assertEquals("The result should be correct.",
            calculationResultItem.getBalance().intValue(),
            retrievedCalculationResultItem.getBalance().intValue());

        Redeposit redeposit = calculationResult.getRedeposits().get(0);
        Redeposit retrievedRedeposit = retrievedCalculationResult.getRedeposits().get(0);
        assertTrue("The result should be correct.", retrievedRedeposit.getId() > 0);
        assertEquals("The result should be correct.",
            redeposit.getDepositType(), retrievedRedeposit.getDepositType());
        assertEquals("The result should be correct.",
            redeposit.getDeposit().intValue(),
            retrievedRedeposit.getDeposit().intValue());
        assertEquals("The result should be correct.",
            redeposit.getDeposit().intValue(),
            retrievedRedeposit.getDeposit().intValue());
        assertEquals("The result should be correct.",
            redeposit.getInterest().intValue(),
            retrievedRedeposit.getInterest().intValue());
        assertEquals("The result should be correct.",
            redeposit.getTotal().intValue(),
            retrievedRedeposit.getTotal().intValue());

        Dedeposit dedeposit = calculationResult.getDedeposits().get(0);
        Dedeposit retrievedDedeposit = retrievedCalculationResult.getDedeposits().get(0);
        assertTrue("The result should be correct.", retrievedDedeposit.getId() > 0);
        assertEquals("The result should be correct.",
            dedeposit.getDepositType(), retrievedDedeposit.getDepositType());
        assertEquals("The result should be correct.",
            dedeposit.getDeposit().intValue(),
            retrievedDedeposit.getDeposit().intValue());
        assertEquals("The result should be correct.",
            dedeposit.getDeposit().intValue(),
            retrievedDedeposit.getDeposit().intValue());
        assertEquals("The result should be correct.",
            dedeposit.getInterest().intValue(),
            retrievedDedeposit.getInterest().intValue());
        assertEquals("The result should be correct.",
            dedeposit.getTotal().intValue(),
            retrievedDedeposit.getTotal().intValue());

        SummaryData summaryData = calculationResult.getSummary();
        SummaryData retrievedSummaryData = retrievedCalculationResult.getSummary();
        assertTrue("The result should be correct.", retrievedSummaryData.getId() > 0);
        assertEquals("The result should be correct.",
            summaryData.getTotalPaymentsRequired().intValue(),
            retrievedSummaryData.getTotalPaymentsRequired().intValue());
        assertEquals("The result should be correct.",
            summaryData.getTotalInitialInterest().intValue(),
            retrievedSummaryData.getTotalInitialInterest().intValue());
        assertEquals("The result should be correct.",
            summaryData.getTotalPaymentsApplied().intValue(),
            retrievedSummaryData.getTotalPaymentsApplied().intValue());
        assertEquals("The result should be correct.",
            summaryData.getTotalBalance().intValue(),
            retrievedSummaryData.getTotalBalance().intValue());


        entity.setName("new");

        // Update
        update(entity);

        res = (CalculationVersion) entityManager.find(CalculationVersion.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        checkHistory("calculation_version_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (CalculationVersion) entityManager.find(CalculationVersion.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("calculation_version_history", "id", id, ACTION_D);
        checkHistory("calculation_history", "id", entity.getCalculations().get(0).getId(), ACTION_D);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getId(), ACTION_D);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getItems().get(0).getId(),
            ACTION_D);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getSummary().getId(), ACTION_D);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getRedeposits().get(0).getId(),
            ACTION_D);
        checkHistory("calculation_result_history", "id", entity.getCalculationResult().getDedeposits().get(0).getId(),
            ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>AccountHolder</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_AccountHolder() {
        AccountHolder entity = getAccountHolder();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("account_holder_history", "id", id, ACTION_I);
        checkHistory("address_history", "id", entity.getAddress().getId(), ACTION_I);

        // Retrieve
        AccountHolder res = (AccountHolder) entityManager.find(AccountHolder.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getLastName(), res.getLastName());
        assertEquals("The result should be correct.", entity.getFirstName(), res.getFirstName());
        assertEquals("The result should be correct.", entity.getMiddleInitial(), res.getMiddleInitial());
        assertEquals("The result should be correct.", entity.getSuffix().getId(), res.getSuffix().getId());
        assertNotNull("The result should be correct.", res.getBirthDate());
        assertEquals("The result should be correct.", entity.getSsn(), res.getSsn());
        assertEquals("The result should be correct.", entity.getTelephone(), res.getTelephone());
        assertEquals("The result should be correct.", entity.getEmail(), res.getEmail());
        assertEquals("The result should be correct.", entity.getTitle(), res.getTitle());
        assertEquals("The result should be correct.", entity.getDepartmentCode(), res.getDepartmentCode());
        assertEquals("The result should be correct.", entity.getGeoCode(), res.getGeoCode());
        assertEquals("The result should be correct.", entity.getCityOfEmployment(), res.getCityOfEmployment());
        assertEquals("The result should be correct.",
            entity.getStateOfEmployment().getId(), res.getStateOfEmployment().getId());

        Address address = entity.getAddress();
        Address retrievedAddress = res.getAddress();
        assertTrue("The result should be correct.", retrievedAddress.getId() > 0);
        assertEquals("The result should be correct.", address.getStreet1(), retrievedAddress.getStreet1());
        assertEquals("The result should be correct.", address.getStreet2(), retrievedAddress.getStreet2());
        assertEquals("The result should be correct.", address.getStreet3(), retrievedAddress.getStreet3());
        assertEquals("The result should be correct.", address.getStreet4(), retrievedAddress.getStreet4());
        assertEquals("The result should be correct.", address.getStreet5(), retrievedAddress.getStreet5());
        assertEquals("The result should be correct.", address.getCity(), retrievedAddress.getCity());
        assertEquals("The result should be correct.",
            address.getState().getId(), retrievedAddress.getState().getId());
        assertEquals("The result should be correct.", address.getZipCode(), retrievedAddress.getZipCode());
        assertEquals("The result should be correct.",
            address.getCountry().getId(), retrievedAddress.getCountry().getId());

        entity.setLastName("new");

        // Update
        update(entity);

        res = (AccountHolder) entityManager.find(AccountHolder.class, id);

        assertEquals("The result should be correct.", entity.getLastName(), res.getLastName());

        checkHistory("account_holder_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (AccountHolder) entityManager.find(AccountHolder.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("account_holder_history", "id", id, ACTION_D);
        checkHistory("address_history", "id", entity.getAddress().getId(), ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>PaymentReverse</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_PaymentReverse() {
        Payment payment = getPayment();
        create(payment);

        PaymentReverse entity = getPaymentReverse();
        entity.setPaymentId(payment.getId());

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("payment_reverse_history", "id", id, ACTION_I);

        // Retrieve
        PaymentReverse res = (PaymentReverse) entityManager.find(PaymentReverse.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getPaymentId(), res.getPaymentId());
        assertEquals("The result should be correct.", entity.getReason().getId(), res.getReason().getId());
        assertEquals("The result should be correct.", entity.isApplyToGL(), res.isApplyToGL());
        assertEquals("The result should be correct.", entity.getReverser(), res.getReverser());

        entity.setReverser("new");

        // Update
        update(entity);

        res = (PaymentReverse) entityManager.find(PaymentReverse.class, id);

        assertEquals("The result should be correct.", entity.getReverser(), res.getReverser());

        checkHistory("payment_reverse_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (PaymentReverse) entityManager.find(PaymentReverse.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("payment_reverse_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>RefundTransaction</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_RefundTransaction() {
        RefundTransaction entity = getRefundTransaction();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("refund_transaction_history", "id", id, ACTION_I);

        // Retrieve
        RefundTransaction res = (RefundTransaction) entityManager.find(RefundTransaction.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getTransactionKey(), res.getTransactionKey());
        assertEquals("The result should be correct.", entity.getAmount().intValue(), res.getAmount().intValue());
        assertEquals("The result should be correct.", entity.getClaimNumber(), res.getClaimNumber());
        assertNotNull("The result should be correct.", res.getRefundDate());
        assertEquals("The result should be correct.", entity.getRefundUsername(), res.getRefundUsername());
        assertEquals("The result should be correct.", entity.getTransferType().getId(), res.getTransferType().getId());

        entity.setTransactionKey("new");

        // Update
        update(entity);

        res = (RefundTransaction) entityManager.find(RefundTransaction.class, id);

        assertEquals("The result should be correct.", entity.getTransactionKey(), res.getTransactionKey());

        checkHistory("refund_transaction_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (RefundTransaction) entityManager.find(RefundTransaction.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("refund_transaction_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>AuditRecord</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_AuditRecord() {
        AuditRecord entity = getAuditRecord();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        AuditRecord res = (AuditRecord) entityManager.find(AuditRecord.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getUsername(), res.getUsername());
        assertEquals("The result should be correct.", entity.getIpAddress(), res.getIpAddress());
        assertEquals("The result should be correct.", entity.getActionName(), res.getActionName());
        assertNotNull("The result should be correct.", res.getDate());
        assertEquals("The result should be correct.", entity.getParameters().size(), res.getParameters().size());

        AuditParameterRecord parameter = entity.getParameters().get(0);
        AuditParameterRecord retrievedParameter = res.getParameters().get(0);

        assertFalse("The result should be correct.", retrievedParameter.isDeleted());
        assertEquals("The result should be correct.", parameter.getItemId(), retrievedParameter.getItemId());
        assertEquals("The result should be correct.", parameter.getItemType(), retrievedParameter.getItemType());
        assertEquals("The result should be correct.",
            parameter.getPropertyName(), retrievedParameter.getPropertyName());
        assertEquals("The result should be correct.",
            parameter.getPreviousValue(), retrievedParameter.getPreviousValue());
        assertEquals("The result should be correct.", parameter.getNewValue(), retrievedParameter.getNewValue());

        entity.setUsername("new");

        // Update
        update(entity);

        res = (AuditRecord) entityManager.find(AuditRecord.class, id);

        assertEquals("The result should be correct.", entity.getUsername(), res.getUsername());

        // Delete
        delete(res);

        res = (AuditRecord) entityManager.find(AuditRecord.class, id);
        assertNull("The result should be correct.", res);

        assertNull("The result should be correct.",
            entityManager.find(AuditParameterRecord.class, parameter.getId()));
    }

    /**
     * <p>
     * Accuracy test for the class <code>HelpItem</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_HelpItem() {
        HelpItem entity = getHelpItem();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        HelpItem res = (HelpItem) entityManager.find(HelpItem.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getTitle(), res.getTitle());
        assertEquals("The result should be correct.", entity.getSummary(), res.getSummary());
        assertEquals("The result should be correct.", entity.getContent(), res.getContent());

        entity.setTitle("new");

        // Update
        update(entity);

        res = (HelpItem) entityManager.find(HelpItem.class, id);

        assertEquals("The result should be correct.", entity.getTitle(), res.getTitle());

        // Delete
        delete(res);

        res = (HelpItem) entityManager.find(HelpItem.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Printout</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Printout() {
        Printout entity = getPrintout();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        Printout res = (Printout) entityManager.find(Printout.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertNotNull("The result should be correct.", res.getPrintDate());

        entity.setName("new");

        // Update
        update(entity);

        res = (Printout) entityManager.find(Printout.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (Printout) entityManager.find(Printout.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>ServiceCreditPreference</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_ServiceCreditPreference() {
        ServiceCreditPreference entity = getServiceCreditPreference();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("service_credit_preference_history", "id", id, ACTION_I);

        // Retrieve
        ServiceCreditPreference res = (ServiceCreditPreference) entityManager.find(ServiceCreditPreference.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.isUseAgents(), res.isUseAgents());
        assertEquals("The result should be correct.", entity.isUseStatusBar(), res.isUseStatusBar());
        assertEquals("The result should be correct.", entity.isUseMessageBox(), res.isUseMessageBox());
        assertEquals("The result should be correct.", entity.getOtherSetting(), res.getOtherSetting());

        entity.setOtherSetting("new");

        // Update
        update(entity);

        res = (ServiceCreditPreference) entityManager.find(ServiceCreditPreference.class, id);

        assertEquals("The result should be correct.", entity.getOtherSetting(), res.getOtherSetting());

        checkHistory("service_credit_preference_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (ServiceCreditPreference) entityManager.find(ServiceCreditPreference.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("service_credit_preference_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Notification</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Notification() {
        Notification entity = getNotification();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("notification_history", "id", id, ACTION_I);
        checkHistory("notification_READBY_history", "notification_id", id, ACTION_I);

        // Retrieve
        Notification res = (Notification) entityManager.find(Notification.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertNotNull("The result should be correct.", res.getDate());
        assertEquals("The result should be correct.", entity.getDetails(), res.getDetails());
        assertEquals("The result should be correct.", entity.getSender(), res.getSender());
        assertEquals("The result should be correct.", entity.isRead(), res.isRead());
        assertEquals("The result should be correct.", entity.getRecipient(), res.getRecipient());
        assertEquals("The result should be correct.", entity.getRole().getId(), res.getRole().getId());
        assertEquals("The result should be correct.", 1, res.getReadBy().size());

        entity.setDetails("new");

        // Update
        update(entity);

        res = (Notification) entityManager.find(Notification.class, id);

        assertEquals("The result should be correct.", entity.getDetails(), res.getDetails());

        checkHistory("notification_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (Notification) entityManager.find(Notification.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("notification_history", "id", id, ACTION_D);
        checkHistory("notification_READBY_history", "notification_id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Info</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Info() {
        Info entity = getInfo();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("info_history", "id", id, ACTION_I);

        // Retrieve
        Info res = (Info) entityManager.find(Info.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertNotNull("The result should be correct.", res.getDate());
        assertEquals("The result should be correct.", entity.getDetails(), res.getDetails());

        entity.setDetails("new");

        // Update
        update(entity);

        res = (Info) entityManager.find(Info.class, id);

        assertEquals("The result should be correct.", entity.getDetails(), res.getDetails());

        checkHistory("info_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (Info) entityManager.find(Info.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("info_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Error</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Error() {
        Error entity = getError();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        checkHistory("error_history", "id", id, ACTION_I);

        // Retrieve
        Error res = (Error) entityManager.find(Error.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertNotNull("The result should be correct.", res.getDate());
        assertEquals("The result should be correct.", entity.getDetails(), res.getDetails());

        entity.setDetails("new");

        // Update
        update(entity);

        res = (Error) entityManager.find(Error.class, id);

        assertEquals("The result should be correct.", entity.getDetails(), res.getDetails());

        checkHistory("error_history", "id", id, ACTION_U);

        // Delete
        delete(res);

        res = (Error) entityManager.find(Error.class, id);
        assertNull("The result should be correct.", res);

        checkHistory("error_history", "id", id, ACTION_D);
    }

    /**
     * <p>
     * Accuracy test for the class <code>RolePermission</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_RolePermission() {
        RolePermission entity = getRolePermission();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        RolePermission res = (RolePermission) entityManager.find(RolePermission.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getRole(), res.getRole());
        assertEquals("The result should be correct.", entity.getAction(), res.getAction());

        entity.setRole("new");

        // Update
        update(entity);

        res = (RolePermission) entityManager.find(RolePermission.class, id);

        assertEquals("The result should be correct.", entity.getRole(), res.getRole());

        // Delete
        delete(res);

        res = (RolePermission) entityManager.find(RolePermission.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>UserPermission</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_UserPermission() {
        UserPermission entity = getUserPermission();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        UserPermission res = (UserPermission) entityManager.find(UserPermission.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getUsername(), res.getUsername());
        assertEquals("The result should be correct.", entity.getAction(), res.getAction());

        entity.setUsername("new");

        // Update
        update(entity);

        res = (UserPermission) entityManager.find(UserPermission.class, id);

        assertEquals("The result should be correct.", entity.getUsername(), res.getUsername());

        // Delete
        delete(res);

        res = (UserPermission) entityManager.find(UserPermission.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>User</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_User() {
        User entity = getUser();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        User res = (User) entityManager.find(User.class, id);

        assertFalse("The result should be correct.", res.isDeleted());
        assertEquals("The result should be correct.", entity.getUsername(), res.getUsername());
        assertEquals("The result should be correct.", entity.getDefaultTab(), res.getDefaultTab());
        assertEquals("The result should be correct.", entity.getNetworkId(), res.getNetworkId());
        assertEquals("The result should be correct.", entity.getRole().getId(), res.getRole().getId());
        assertEquals("The result should be correct.", entity.getFirstName(), res.getFirstName());
        assertEquals("The result should be correct.", entity.getLastName(), res.getLastName());
        assertEquals("The result should be correct.", entity.getEmail(), res.getEmail());
        assertEquals("The result should be correct.", entity.getTelephone(), res.getTelephone());
        assertEquals("The result should be correct.", entity.getStatus().getId(), res.getStatus().getId());

        entity.setUsername("new");

        // Update
        update(entity);

        res = (User) entityManager.find(User.class, id);

        assertEquals("The result should be correct.", entity.getUsername(), res.getUsername());

        // Delete
        delete(res);

        res = (User) entityManager.find(User.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>FormType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_FormType() {
        FormType entity = getFormType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        FormType res = (FormType) entityManager.find(FormType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (FormType) entityManager.find(FormType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (FormType) entityManager.find(FormType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Suffix</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Suffix() {
        Suffix entity = getSuffix();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        Suffix res = (Suffix) entityManager.find(Suffix.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (Suffix) entityManager.find(Suffix.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (Suffix) entityManager.find(Suffix.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>PeriodType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_PeriodType() {
        PeriodType entity = getPeriodType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        PeriodType res = (PeriodType) entityManager.find(PeriodType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (PeriodType) entityManager.find(PeriodType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (PeriodType) entityManager.find(PeriodType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>State</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_State() {
        State entity = getState();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        State res = (State) entityManager.find(State.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (State) entityManager.find(State.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (State) entityManager.find(State.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Country</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Country() {
        Country entity = getCountry();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        Country res = (Country) entityManager.find(Country.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (Country) entityManager.find(Country.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (Country) entityManager.find(Country.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>AccountStatus</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_AccountStatus() {
        AccountStatus entity = getAccountStatus();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        AccountStatus res = (AccountStatus) entityManager.find(AccountStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (AccountStatus) entityManager.find(AccountStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (AccountStatus) entityManager.find(AccountStatus.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>RetirementType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_RetirementType() {
        RetirementType entity = getRetirementType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        RetirementType res = (RetirementType) entityManager.find(RetirementType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (RetirementType) entityManager.find(RetirementType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (RetirementType) entityManager.find(RetirementType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>ServiceType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_ServiceType() {
        ServiceType entity = getServiceType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        ServiceType res = (ServiceType) entityManager.find(ServiceType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (ServiceType) entityManager.find(ServiceType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (ServiceType) entityManager.find(ServiceType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>Role</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_Role() {
        Role entity = getRole();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        Role res = (Role) entityManager.find(Role.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (Role) entityManager.find(Role.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (Role) entityManager.find(Role.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>AppointmentType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_AppointmentType() {
        AppointmentType entity = getAppointmentType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        AppointmentType res = (AppointmentType) entityManager.find(AppointmentType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (AppointmentType) entityManager.find(AppointmentType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (AppointmentType) entityManager.find(AppointmentType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>PayType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_PayType() {
        PayType entity = getPayType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        PayType res = (PayType) entityManager.find(PayType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (PayType) entityManager.find(PayType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (PayType) entityManager.find(PayType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>PaymentReversalReason</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_PaymentReversalReason() {
        PaymentReversalReason entity = getPaymentReversalReason();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        PaymentReversalReason res = (PaymentReversalReason) entityManager.find(PaymentReversalReason.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (PaymentReversalReason) entityManager.find(PaymentReversalReason.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (PaymentReversalReason) entityManager.find(PaymentReversalReason.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>ApplicationDesignation</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_ApplicationDesignation() {
        ApplicationDesignation entity = getApplicationDesignation();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        ApplicationDesignation res = (ApplicationDesignation) entityManager.find(ApplicationDesignation.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (ApplicationDesignation) entityManager.find(ApplicationDesignation.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (ApplicationDesignation) entityManager.find(ApplicationDesignation.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>PaymentStatus</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_PaymentStatus() {
        PaymentStatus entity = getPaymentStatus();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        PaymentStatus res = (PaymentStatus) entityManager.find(PaymentStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (PaymentStatus) entityManager.find(PaymentStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (PaymentStatus) entityManager.find(PaymentStatus.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>ClaimOfficer</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_ClaimOfficer() {
        ClaimOfficer entity = getClaimOfficer();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        ClaimOfficer res = (ClaimOfficer) entityManager.find(ClaimOfficer.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (ClaimOfficer) entityManager.find(ClaimOfficer.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (ClaimOfficer) entityManager.find(ClaimOfficer.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>UserStatus</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_UserStatus() {
        UserStatus entity = getUserStatus();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        UserStatus res = (UserStatus) entityManager.find(UserStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (UserStatus) entityManager.find(UserStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (UserStatus) entityManager.find(UserStatus.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>TransferType</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_TransferType() {
        TransferType entity = getTransferType();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        TransferType res = (TransferType) entityManager.find(TransferType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (TransferType) entityManager.find(TransferType.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (TransferType) entityManager.find(TransferType.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Accuracy test for the class <code>CalculationStatus</code>.<br>
     * The result should be correct.
     * </p>
     */
    @Test
    public void test_CalculationStatus() {
        CalculationStatus entity = getCalculationStatus();

        // Create
        long id = create(entity);
        entityManager.clear();

        assertTrue("The result should be correct.", id > 0);

        // Retrieve
        CalculationStatus res = (CalculationStatus) entityManager.find(CalculationStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());
        assertFalse("The result should be correct.", res.isDeleted());

        entity.setName("new");

        // Update
        update(entity);

        res = (CalculationStatus) entityManager.find(CalculationStatus.class, id);

        assertEquals("The result should be correct.", entity.getName(), res.getName());

        // Delete
        delete(res);

        res = (CalculationStatus) entityManager.find(CalculationStatus.class, id);
        assertNull("The result should be correct.", res);
    }

    /**
     * <p>
     * Checks if the record exists in history table.
     * </p>
     *
     * @param table
     *            the table.
     * @param name
     *            the name.
     * @param value
     *            the value.
     * @param action
     *            the action.
     */
    private static void checkHistory(String table, String name, long value, String action) {
        entityManager.getTransaction().begin();

        Query query = entityManager.createNativeQuery("SELECT COUNT(*) FROM " + SCHEMA + table + " WHERE " + name
            + "=? AND action=?");
        int count = ((Number) query.setParameter(1, value).setParameter(2, action).getSingleResult()).intValue();

        entityManager.getTransaction().commit();

        assertTrue("The result should be correct.", count > 0);
    }
}