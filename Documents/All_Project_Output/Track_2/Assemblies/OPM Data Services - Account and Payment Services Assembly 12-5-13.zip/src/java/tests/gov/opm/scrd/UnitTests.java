/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import gov.opm.scrd.entities.application.AccountConfirmationValidationEntryUnitTests;
import gov.opm.scrd.entities.application.AccountConfirmationValidationUnitTests;
import gov.opm.scrd.entities.application.AccountHolderUnitTests;
import gov.opm.scrd.entities.application.AccountNoteUnitTests;
import gov.opm.scrd.entities.application.AccountSearchFilterUnitTests;
import gov.opm.scrd.entities.application.AccountUnitTests;
import gov.opm.scrd.entities.application.AddressUnitTests;
import gov.opm.scrd.entities.application.ApprovalItemSummaryUnitTests;
import gov.opm.scrd.entities.application.AuditParameterRecordUnitTests;
import gov.opm.scrd.entities.application.AuditRecordUnitTests;
import gov.opm.scrd.entities.application.BillingSummaryUnitTests;
import gov.opm.scrd.entities.application.BillingUnitTests;
import gov.opm.scrd.entities.application.CalculationResultItemUnitTests;
import gov.opm.scrd.entities.application.CalculationResultUnitTests;
import gov.opm.scrd.entities.application.CalculationUnitTests;
import gov.opm.scrd.entities.application.CalculationVersionUnitTests;
import gov.opm.scrd.entities.application.DedepositUnitTests;
import gov.opm.scrd.entities.application.ErrorUnitTests;
import gov.opm.scrd.entities.application.HelpItemUnitTests;
import gov.opm.scrd.entities.application.InfoUnitTests;
import gov.opm.scrd.entities.application.InterestAdjustmentUnitTests;
import gov.opm.scrd.entities.application.NotificationSearchFilterUnitTests;
import gov.opm.scrd.entities.application.NotificationUnitTests;
import gov.opm.scrd.entities.application.PaymentMoveUnitTests;
import gov.opm.scrd.entities.application.PaymentReverseUnitTests;
import gov.opm.scrd.entities.application.PaymentSearchFilterUnitTests;
import gov.opm.scrd.entities.application.PaymentUnitTests;
import gov.opm.scrd.entities.application.PendingPaymentUnitTests;
import gov.opm.scrd.entities.application.PrintoutUnitTests;
import gov.opm.scrd.entities.application.RedepositUnitTests;
import gov.opm.scrd.entities.application.RefundTransactionUnitTests;
import gov.opm.scrd.entities.application.RolePermissionUnitTests;
import gov.opm.scrd.entities.application.ServiceAnnouncementUnitTests;
import gov.opm.scrd.entities.application.ServiceCreditPreferenceUnitTests;
import gov.opm.scrd.entities.application.SummaryDataUnitTests;
import gov.opm.scrd.entities.application.SuspendedPaymentUnitTests;
import gov.opm.scrd.entities.application.UserPermissionUnitTests;
import gov.opm.scrd.entities.application.UserUnitTests;
import gov.opm.scrd.entities.common.BasePagedSearchParametersUnitTests;
import gov.opm.scrd.entities.common.BaseSearchParametersUnitTests;
import gov.opm.scrd.entities.common.BasicPagedSearchFilterUnitTests;
import gov.opm.scrd.entities.common.BasicSearchFilterUnitTests;
import gov.opm.scrd.entities.common.IdentifiableEntityUnitTests;
import gov.opm.scrd.entities.common.NamedEntityUnitTests;
import gov.opm.scrd.entities.common.SearchResultUnitTests;
import gov.opm.scrd.entities.lookup.AccountStatusUnitTests;
import gov.opm.scrd.entities.lookup.ApplicationDesignationUnitTests;
import gov.opm.scrd.entities.lookup.AppointmentTypeUnitTests;
import gov.opm.scrd.entities.lookup.CalculationStatusUnitTests;
import gov.opm.scrd.entities.lookup.ClaimOfficerUnitTests;
import gov.opm.scrd.entities.lookup.CountryUnitTests;
import gov.opm.scrd.entities.lookup.FormTypeUnitTests;
import gov.opm.scrd.entities.lookup.PayTypeUnitTests;
import gov.opm.scrd.entities.lookup.PaymentReversalReasonUnitTests;
import gov.opm.scrd.entities.lookup.PaymentStatusUnitTests;
import gov.opm.scrd.entities.lookup.PeriodTypeUnitTests;
import gov.opm.scrd.entities.lookup.RetirementTypeUnitTests;
import gov.opm.scrd.entities.lookup.RoleUnitTests;
import gov.opm.scrd.entities.lookup.ServiceTypeUnitTests;
import gov.opm.scrd.entities.lookup.StateUnitTests;
import gov.opm.scrd.entities.lookup.SuffixUnitTests;
import gov.opm.scrd.entities.lookup.TransferTypeUnitTests;
import gov.opm.scrd.entities.lookup.UserStatusUnitTests;
import gov.opm.scrd.services.AuthorizationExceptionUnitTests;
import gov.opm.scrd.services.EntityNotFoundExceptionUnitTests;
import gov.opm.scrd.services.OPMConfigurationExceptionUnitTests;
import gov.opm.scrd.services.OPMExceptionUnitTests;
import gov.opm.scrd.services.impl.AccountServiceImplUnitTests;
import gov.opm.scrd.services.impl.ApprovalServiceImplUnitTests;
import gov.opm.scrd.services.impl.CalculationExecutionServiceImplUnitTests;
import gov.opm.scrd.services.impl.PaymentServiceImplUnitTests;
import gov.opm.scrd.services.impl.ServiceAnnouncementServiceImplUnitTests;
import gov.opm.scrd.services.impl.SuspensionServiceImplUnitTests;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * <p>
 * This test case aggregates all Unit test cases.
 * </p>
 *
 * <p>
 * <em>Changes in OPM - Data Services - Account and Payment Services Assembly 1.0:</em>
 * <ol>
 * <li>Added new tests.</li>
 * </ol>
 * </p>
 *
 * @author sparemax, TCSASSEMBLER
 * @version 1.0
 */
public class UnitTests extends TestCase {
    /**
     * <p>
     * All unit test cases.
     * </p>
     *
     * @return The test suite.
     */
    public static Test suite() {
        final TestSuite suite = new TestSuite();

        // Add service tests
        addServiceTests(suite);

        suite.addTest(PersistenceTests.suite());

        suite.addTest(IdentifiableEntityUnitTests.suite());
        suite.addTest(NamedEntityUnitTests.suite());
        suite.addTest(BaseSearchParametersUnitTests.suite());
        suite.addTest(BasicSearchFilterUnitTests.suite());
        suite.addTest(BasePagedSearchParametersUnitTests.suite());
        suite.addTest(BasicPagedSearchFilterUnitTests.suite());
        suite.addTest(SearchResultUnitTests.suite());

        // Add application tests
        addApplicationTests(suite);

        // Add lookup tests
        addLookupTests(suite);

        // Exceptions
        suite.addTest(OPMExceptionUnitTests.suite());
        suite.addTest(AuthorizationExceptionUnitTests.suite());
        suite.addTest(EntityNotFoundExceptionUnitTests.suite());
        suite.addTest(OPMConfigurationExceptionUnitTests.suite());

        return suite;
    }

    /**
     * Adds the service tests to test suite.
     *
     * @param suite
     *            the test suite.
     */
    private static void addServiceTests(TestSuite suite) {
        suite.addTest(PaymentServiceImplUnitTests.suite());
        suite.addTest(ServiceAnnouncementServiceImplUnitTests.suite());
        suite.addTest(SuspensionServiceImplUnitTests.suite());
        suite.addTest(ApprovalServiceImplUnitTests.suite());
        suite.addTest(AccountServiceImplUnitTests.suite());
        suite.addTest(CalculationExecutionServiceImplUnitTests.suite());
    }

    /**
     * Adds the application tests to test suite.
     *
     * @param suite
     *            the test suite.
     */
    private static void addApplicationTests(TestSuite suite) {
        suite.addTest(AccountConfirmationValidationEntryUnitTests.suite());
        suite.addTest(AccountConfirmationValidationUnitTests.suite());
        suite.addTest(AccountHolderUnitTests.suite());
        suite.addTest(AccountNoteUnitTests.suite());
        suite.addTest(AccountUnitTests.suite());
        suite.addTest(AddressUnitTests.suite());
        suite.addTest(AuditParameterRecordUnitTests.suite());
        suite.addTest(AuditRecordUnitTests.suite());
        suite.addTest(BillingSummaryUnitTests.suite());
        suite.addTest(BillingUnitTests.suite());
        suite.addTest(CalculationResultItemUnitTests.suite());
        suite.addTest(CalculationResultUnitTests.suite());
        suite.addTest(CalculationUnitTests.suite());
        suite.addTest(CalculationVersionUnitTests.suite());
        suite.addTest(DedepositUnitTests.suite());
        suite.addTest(ErrorUnitTests.suite());
        suite.addTest(HelpItemUnitTests.suite());
        suite.addTest(InfoUnitTests.suite());
        suite.addTest(NotificationUnitTests.suite());
        suite.addTest(PaymentReverseUnitTests.suite());
        suite.addTest(PaymentUnitTests.suite());
        suite.addTest(PrintoutUnitTests.suite());
        suite.addTest(RedepositUnitTests.suite());
        suite.addTest(RefundTransactionUnitTests.suite());
        suite.addTest(RolePermissionUnitTests.suite());
        suite.addTest(ServiceAnnouncementUnitTests.suite());
        suite.addTest(ServiceCreditPreferenceUnitTests.suite());
        suite.addTest(SummaryDataUnitTests.suite());
        suite.addTest(UserPermissionUnitTests.suite());
        suite.addTest(UserUnitTests.suite());

        suite.addTest(AccountSearchFilterUnitTests.suite());
        suite.addTest(PaymentSearchFilterUnitTests.suite());
        suite.addTest(NotificationSearchFilterUnitTests.suite());

        suite.addTest(ApprovalItemSummaryUnitTests.suite());

        suite.addTest(InterestAdjustmentUnitTests.suite());
        suite.addTest(PaymentMoveUnitTests.suite());
        suite.addTest(PendingPaymentUnitTests.suite());
        suite.addTest(SuspendedPaymentUnitTests.suite());
    }

    /**
     * Adds the lookup tests to test suite.
     *
     * @param suite
     *            the test suite.
     */
    private static void addLookupTests(TestSuite suite) {
        suite.addTest(AccountStatusUnitTests.suite());
        suite.addTest(ApplicationDesignationUnitTests.suite());
        suite.addTest(AppointmentTypeUnitTests.suite());
        suite.addTest(CalculationStatusUnitTests.suite());
        suite.addTest(ClaimOfficerUnitTests.suite());
        suite.addTest(CountryUnitTests.suite());
        suite.addTest(FormTypeUnitTests.suite());
        suite.addTest(PaymentReversalReasonUnitTests.suite());
        suite.addTest(PaymentStatusUnitTests.suite());
        suite.addTest(PayTypeUnitTests.suite());
        suite.addTest(PeriodTypeUnitTests.suite());
        suite.addTest(RetirementTypeUnitTests.suite());
        suite.addTest(RoleUnitTests.suite());
        suite.addTest(ServiceTypeUnitTests.suite());
        suite.addTest(StateUnitTests.suite());
        suite.addTest(SuffixUnitTests.suite());
        suite.addTest(TransferTypeUnitTests.suite());
        suite.addTest(UserStatusUnitTests.suite());
    }
}
