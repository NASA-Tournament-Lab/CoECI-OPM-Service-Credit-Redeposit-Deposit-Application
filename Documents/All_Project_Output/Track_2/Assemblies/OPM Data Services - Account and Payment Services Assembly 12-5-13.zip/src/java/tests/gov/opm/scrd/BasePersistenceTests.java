/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd;

import gov.opm.scrd.entities.application.Account;
import gov.opm.scrd.entities.application.AccountConfirmationValidation;
import gov.opm.scrd.entities.application.AccountConfirmationValidationEntry;
import gov.opm.scrd.entities.application.AccountHolder;
import gov.opm.scrd.entities.application.AccountNote;
import gov.opm.scrd.entities.application.Address;
import gov.opm.scrd.entities.application.AuditParameterRecord;
import gov.opm.scrd.entities.application.AuditRecord;
import gov.opm.scrd.entities.application.Billing;
import gov.opm.scrd.entities.application.BillingSummary;
import gov.opm.scrd.entities.application.Calculation;
import gov.opm.scrd.entities.application.CalculationResult;
import gov.opm.scrd.entities.application.CalculationResultItem;
import gov.opm.scrd.entities.application.CalculationVersion;
import gov.opm.scrd.entities.application.Dedeposit;
import gov.opm.scrd.entities.application.Error;
import gov.opm.scrd.entities.application.HelpItem;
import gov.opm.scrd.entities.application.Info;
import gov.opm.scrd.entities.application.Notification;
import gov.opm.scrd.entities.application.Payment;
import gov.opm.scrd.entities.application.PaymentReverse;
import gov.opm.scrd.entities.application.Printout;
import gov.opm.scrd.entities.application.Redeposit;
import gov.opm.scrd.entities.application.RefundTransaction;
import gov.opm.scrd.entities.application.RolePermission;
import gov.opm.scrd.entities.application.ServiceCreditPreference;
import gov.opm.scrd.entities.application.SummaryData;
import gov.opm.scrd.entities.application.User;
import gov.opm.scrd.entities.application.UserPermission;
import gov.opm.scrd.entities.common.IdentifiableEntity;
import gov.opm.scrd.entities.lookup.AccountStatus;
import gov.opm.scrd.entities.lookup.ActionTab;
import gov.opm.scrd.entities.lookup.ApplicationDesignation;
import gov.opm.scrd.entities.lookup.AppointmentType;
import gov.opm.scrd.entities.lookup.ApprovalStatus;
import gov.opm.scrd.entities.lookup.CalculationStatus;
import gov.opm.scrd.entities.lookup.ClaimOfficer;
import gov.opm.scrd.entities.lookup.Country;
import gov.opm.scrd.entities.lookup.DepositType;
import gov.opm.scrd.entities.lookup.FormType;
import gov.opm.scrd.entities.lookup.PayType;
import gov.opm.scrd.entities.lookup.PaymentReversalReason;
import gov.opm.scrd.entities.lookup.PaymentStatus;
import gov.opm.scrd.entities.lookup.PaymentType;
import gov.opm.scrd.entities.lookup.PeriodType;
import gov.opm.scrd.entities.lookup.RetirementType;
import gov.opm.scrd.entities.lookup.Role;
import gov.opm.scrd.entities.lookup.ServiceType;
import gov.opm.scrd.entities.lookup.State;
import gov.opm.scrd.entities.lookup.Suffix;
import gov.opm.scrd.entities.lookup.TransferType;
import gov.opm.scrd.entities.lookup.UserStatus;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import junit.framework.JUnit4TestAdapter;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

/**
 * <p>
 * Base persistence tests.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class BasePersistenceTests {
    /**
     * <p>
     * Represents the path of SQL files.
     * </p>
     */
    private static final String SQL_FILES = "src" + File.separator + "sql" + File.separator;

    /**
     * <p>
     * Represents the <code>EntityManagerFactory </code> for tests.
     * </p>
     */
    private static EntityManagerFactory factory;

    /**
     * <p>
     * Represents the entity manager used in tests.
     * </p>
     */
    private static EntityManager entityManager;

    /**
     * <p>
     * Adapter for earlier versions of JUnit.
     * </p>
     *
     * @return a test suite.
     */
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(BasePersistenceTests.class);
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @BeforeClass
    public static void setUpClass() throws Exception {
        factory = Persistence.createEntityManagerFactory("opmUnitName");
        entityManager = factory.createEntityManager();
        clearDB();
    }

    /**
     * <p>
     * Cleans up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @AfterClass
    public static void tearDownClass() throws Exception {
        clearDB();
        entityManager.close();
        entityManager = null;
        factory.close();
        factory = null;
    }

    /**
     * <p>
     * Sets up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @Before
    public void setUp() throws Exception {
        clearDB();
    }

    /**
     * <p>
     * Cleans up the unit tests.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    @After
    public void tearDown() throws Exception {
        clearDB();
    }

    /**
     * Gets the entity manager.
     *
     * @return the entity manager.
     */
    public static EntityManager getEntityManager() {
        return entityManager;
    }

    /**
     * <p>
     * Deletes the entity.
     * </p>
     *
     * @param entity
     *            the entity.
     */
    protected void delete(Object entity) {
        entityManager.getTransaction().begin();

        entityManager.remove(entity);

        entityManager.getTransaction().commit();
    }

    /**
     * <p>
     * Updates the entity.
     * </p>
     *
     * @param entity
     *            the entity.
     */
    protected void update(Object entity) {
        entityManager.getTransaction().begin();

        entityManager.merge(entity);

        entityManager.getTransaction().commit();
    }

    /**
     * <p>
     * Creates the entity.
     * </p>
     *
     * @param <T>
     *            the entity type.
     * @param entity
     *            the entity.
     *
     * @return the id
     */
    protected <T extends IdentifiableEntity> long create(T entity) {
        entityManager.getTransaction().begin();

        entityManager.persist(entity);

        entityManager.getTransaction().commit();
        entityManager.clear();

        return entity.getId();
    }

    /**
     * <p>
     * Clears the database.
     * </p>
     *
     * @throws Exception
     *             to JUnit.
     */
    protected static void clearDB() throws Exception {
        executeSQL(SQL_FILES + "clear-data.sql");
    }

    /**
     * Creates an instance of Account.
     *
     * @return the Account instance.
     */
    protected Account getAccount() {
        Account entity = new Account();

        entity.setClaimNumber("claimNumber1");
        entity.setPlanType("planType1");

        entity.setFormType(getFormType());
        create(entity.getFormType());

        entity.setHolder(getAccountHolder());
        create(entity.getHolder());

        entity.setStatus(getAccountStatus());
        create(entity.getStatus());

        entity.setGrace(true);
        entity.setFrozen(true);
        entity.setClaimOfficer("claimOfficer1");
        entity.setClaimOfficerAssignmentDate(new Date());
        entity.setClaimantBirthdate(new Date());
        entity.setBalance(BigDecimal.ONE);
        entity.setReturnedFromRecordsDate(new Date());
        entity.setBillingSummary(getBillingSummary());

        entity.setFersDepositCalculationVersions(new ArrayList<CalculationVersion>());
        entity.setFersRedepositCalculationVersions(new ArrayList<CalculationVersion>());

        return entity;
    }

    /**
     * Creates an instance of Payment.
     *
     * @return the Payment instance.
     */
    protected Payment getPayment() {
        Payment entity = new Payment();

        entity.setBatchNumber("batchNumber1");
        entity.setBlockNumber("blockNumber1");
        entity.setSequenceNumber("sequenceNumber1");

        entity.setPaymentStatus(getPaymentStatus());
        create(entity.getPaymentStatus());

        entity.setClaimNumber("claimNumber1");
        entity.setAccountHolderBirthdate(new Date());
        entity.setDepositDate(new Date());
        entity.setAmount(BigDecimal.ONE);
        entity.setSsn("ssn1");
        entity.setClaimant("claimant1");
        entity.setClaimantBirthdate(new Date());
        entity.setImportId("importId1");
        entity.setSequence(1);
        entity.setTransactionDate(new Date());
        entity.setStatusDate(new Date());

        entity.setApplyTo(getApplicationDesignation());
        create(entity.getApplyTo());

        entity.setApplyToGL(true);
        entity.setNote("note1");
        entity.setTransactionKey("transactionKey1");
        entity.setAch(true);
        entity.setAccountBalance(BigDecimal.ONE);

        entity.setAccountStatus(getAccountStatus());
        create(entity.getAccountStatus());

        entity.setMasterClaimNumber("masterClaimNumber1");
        entity.setMasterClaimantBirthdate(new Date());

        entity.setMasterAccountStatus(getAccountStatus());
        create(entity.getMasterAccountStatus());

        entity.setMasterAccountBalance(BigDecimal.ONE);
        entity.setMasterAccountId(1L);
        entity.setPreDepositAmount(BigDecimal.ONE);
        entity.setPreRedepositAmount(BigDecimal.ONE);
        entity.setPostDepositAmount(BigDecimal.ONE);
        entity.setPostRedepositAmount(BigDecimal.ONE);
        entity.setApprovalUser("approvalUser1");

        entity.setAccountStatus(getAccountStatus());
        create(entity.getAccountStatus());

        entity.setApprovalStatus(ApprovalStatus.PENDING);
        entity.setApprovalReason("approvalReason1");
        entity.setPaymentType(PaymentType.INTEREST_ADJUSTMENT);

        return entity;
    }

    /**
     * Creates an instance of AccountConfirmationValidation.
     *
     * @return the AccountConfirmationValidation instance.
     */
    protected static AccountConfirmationValidation getAccountConfirmationValidation() {
        AccountConfirmationValidation entity = new AccountConfirmationValidation();

        entity.setDataCheckStatus(ApprovalStatus.APPROVED);
        entity.setDataCheckStatusValidator("dataCheckStatusValidator1");
        entity.setDataCheckStatusReason("dataCheckStatusReason1");
        entity.setEntries(Arrays.asList(getAccountConfirmationValidationEntry()));

        return entity;
    }

    /**
     * Creates an instance of AccountConfirmationValidationEntry.
     *
     * @return the AccountConfirmationValidationEntry instance.
     */
    protected static AccountConfirmationValidationEntry getAccountConfirmationValidationEntry() {
        AccountConfirmationValidationEntry entity = new AccountConfirmationValidationEntry();

        entity.setFieldName("fieldName1");
        entity.setValid(true);

        return entity;
    }

    /**
     * Creates an instance of CalculationVersion.
     *
     * @return the CalculationVersion instance.
     */
    protected CalculationVersion getCalculationVersion() {
        CalculationVersion entity = new CalculationVersion();

        entity.setName("name1");
        entity.setCalculations(new ArrayList<Calculation>(Arrays.asList(getCalculation())));
        entity.setCalculationResult(getCalculationResult());
        entity.setCalculationDate(new Date());

        return entity;
    }

    /**
     * Creates an instance of CalculationResult.
     *
     * @return the CalculationResult instance.
     */
    protected CalculationResult getCalculationResult() {
        CalculationResult entity = new CalculationResult();

        entity.setItems(new ArrayList<CalculationResultItem>(Arrays.asList(getCalculationResultItem())));
        entity.setRedeposits(new ArrayList<Redeposit>(Arrays.asList(getRedeposit())));
        entity.setDedeposits(new ArrayList<Dedeposit>(Arrays.asList(getDedeposit())));
        entity.setSummary(getSummaryData());

        entity.setCalculationStatus(getCalculationStatus());
        create(entity.getCalculationStatus());

        entity.setOfficial(true);
        entity.setApplyToRealPayments(true);

        return entity;
    }

    /**
     * Creates an instance of CalculationResultItem.
     *
     * @return the CalculationResultItem instance.
     */
    protected CalculationResultItem getCalculationResultItem() {
        CalculationResultItem entity = new CalculationResultItem();

        entity.setStartDate(new Date());
        entity.setEndDate(new Date());
        entity.setMidDate(new Date());
        entity.setEffectiveDate(new Date());

        entity.setPeriodType(getPeriodType());
        create(entity.getPeriodType());

        entity.setDeductionAmount(BigDecimal.ONE);
        entity.setTotalInterest(BigDecimal.ONE);
        entity.setPaymentsApplied(BigDecimal.ONE);
        entity.setBalance(BigDecimal.ONE);

        return entity;
    }

    /**
     * Creates an instance of SummaryData.
     *
     * @return the SummaryData instance.
     */
    protected static SummaryData getSummaryData() {
        SummaryData entity = new SummaryData();

        entity.setTotalPaymentsRequired(BigDecimal.ONE);
        entity.setTotalInitialInterest(BigDecimal.ONE);
        entity.setTotalPaymentsApplied(BigDecimal.ONE);
        entity.setTotalBalance(BigDecimal.ONE);

        return entity;
    }

    /**
     * Creates an instance of Dedeposit.
     *
     * @return the Dedeposit instance.
     */
    protected static Dedeposit getDedeposit() {
        Dedeposit entity = new Dedeposit();

        entity.setDepositType(DepositType.POST_10_82);
        entity.setDeposit(BigDecimal.ONE);
        entity.setInterest(BigDecimal.ONE);
        entity.setTotal(BigDecimal.ONE);

        return entity;
    }

    /**
     * Creates an instance of Redeposit.
     *
     * @return the Redeposit instance.
     */
    protected static Redeposit getRedeposit() {
        Redeposit entity = new Redeposit();

        entity.setDepositType(DepositType.POST_10_82);
        entity.setDeposit(BigDecimal.ONE);
        entity.setInterest(BigDecimal.ONE);
        entity.setTotal(BigDecimal.ONE);

        return entity;
    }

    /**
     * Creates an instance of Calculation.
     *
     * @return the Calculation instance.
     */
    protected Calculation getCalculation() {
        Calculation entity = new Calculation();

        entity.setBeginDate(new Date());
        entity.setEndDate(new Date());

        entity.setRetirementType(getRetirementType());
        create(entity.getRetirementType());

        entity.setPeriodType(getPeriodType());
        create(entity.getPeriodType());

        entity.setAppointmentType(getAppointmentType());
        create(entity.getAppointmentType());

        entity.setServiceType(getServiceType());
        create(entity.getServiceType());

        entity.setAmount(BigDecimal.ONE);

        entity.setPayType(getPayType());
        create(entity.getPayType());

        return entity;
    }

    /**
     * Creates an instance of BillingSummary.
     *
     * @return the BillingSummary instance.
     */
    protected static BillingSummary getBillingSummary() {
        BillingSummary entity = new BillingSummary();

        entity.setComputedDate(new Date());
        entity.setLastDepositDate(new Date());
        entity.setFirstBillingDate(new Date());
        entity.setLastInterestCalculation(new Date());
        entity.setTransactionType("transactionType1");
        entity.setLastTransactionDate(new Date());
        entity.setBillings(Arrays.asList(getBilling()));
        entity.setStopACHPayments(true);

        return entity;
    }

    /**
     * Creates an instance of Billing.
     *
     * @return the Billing instance.
     */
    protected static Billing getBilling() {
        Billing entity = new Billing();

        entity.setName("name1");
        entity.setInitialBilling(BigDecimal.ONE);
        entity.setAdditionalInterest(BigDecimal.ONE);
        entity.setTotalPayments(BigDecimal.ONE);
        entity.setBalance(BigDecimal.ONE);
        entity.setPaymentOrder(1);

        return entity;
    }

    /**
     * Creates an instance of AccountHolder.
     *
     * @return the AccountHolder instance.
     */
    protected AccountHolder getAccountHolder() {
        AccountHolder entity = new AccountHolder();

        entity.setLastName("lastName1");
        entity.setFirstName("firstName1");
        entity.setMiddleInitial("middleInitial1");

        entity.setSuffix(getSuffix());
        create(entity.getSuffix());

        entity.setBirthDate(new Date());
        entity.setSsn("ssn1");
        entity.setTelephone("telephone1");
        entity.setEmail("email1");
        entity.setTitle("title1");
        entity.setDepartmentCode("departmentCode1");

        entity.setAddress(getAddress());

        entity.setGeoCode("geoCode1");
        entity.setCityOfEmployment("cityOfEmployment1");

        entity.setStateOfEmployment(getState());
        create(entity.getStateOfEmployment());

        return entity;
    }

    /**
     * Creates an instance of Address.
     *
     * @return the Address instance.
     */
    protected Address getAddress() {
        Address entity = new Address();

        entity.setStreet1("street11");
        entity.setStreet2("street21");
        entity.setStreet3("street31");
        entity.setStreet4("street41");
        entity.setStreet5("street51");
        entity.setCity("city1");

        entity.setState(getState());
        create(entity.getState());

        entity.setZipCode("zipCode1");

        entity.setCountry(getCountry());
        create(entity.getCountry());

        return entity;
    }

    /**
     * Creates an instance of AccountNote.
     *
     * @return the AccountNote instance.
     */
    protected static AccountNote getAccountNote() {
        AccountNote entity = new AccountNote();

        entity.setDate(new Date());
        entity.setText("text1");
        entity.setWriter("writer1");

        return entity;
    }

    /**
     * Creates an instance of RefundTransaction.
     *
     * @return the RefundTransaction instance.
     */
    protected RefundTransaction getRefundTransaction() {
        RefundTransaction entity = new RefundTransaction();

        entity.setTransactionKey("transactionKey1");
        entity.setAmount(BigDecimal.ONE);
        entity.setClaimNumber("claimNumber1");
        entity.setRefundDate(new Date());
        entity.setRefundUsername("refundUsername1");

        entity.setTransferType(getTransferType());
        create(entity.getTransferType());

        return entity;
    }

    /**
     * Creates an instance of PaymentReverse.
     *
     * @return the PaymentReverse instance.
     */
    protected PaymentReverse getPaymentReverse() {
        PaymentReverse entity = new PaymentReverse();

        entity.setPaymentId(1);

        entity.setReason(getPaymentReversalReason());
        create(entity.getReason());

        entity.setApplyToGL(true);
        entity.setReverser("reverser1");

        return entity;
    }

    /**
     * Creates an instance of AuditParameterRecord.
     *
     * @return the AuditParameterRecord instance.
     */
    protected static AuditParameterRecord getAuditParameterRecord() {
        AuditParameterRecord entity = new AuditParameterRecord();

        entity.setItemId(1L);
        entity.setItemType("itemType1");
        entity.setPropertyName("propertyName1");
        entity.setPreviousValue("previousValue1");
        entity.setNewValue("newValue1");

        return entity;
    }

    /**
     * Creates an instance of AuditRecord.
     *
     * @return the AuditRecord instance.
     */
    protected static AuditRecord getAuditRecord() {
        AuditRecord entity = new AuditRecord();

        entity.setUsername("username1");
        entity.setIpAddress("ipAddress1");
        entity.setActionName("actionName1");
        entity.setDate(new Date());

        entity.setParameters(Arrays.asList(getAuditParameterRecord()));

        return entity;
    }

    /**
     * Creates an instance of HelpItem.
     *
     * @return the HelpItem instance.
     */
    protected static HelpItem getHelpItem() {
        HelpItem entity = new HelpItem();

        entity.setTitle("title1");
        entity.setSummary("summary1");
        entity.setContent("content1");

        return entity;
    }

    /**
     * Creates an instance of Printout.
     *
     * @return the Printout instance.
     */
    protected static Printout getPrintout() {
        Printout entity = new Printout();

        entity.setName("name1");
        entity.setPrintDate(new Date());

        return entity;
    }

    /**
     * Creates an instance of ServiceCreditPreference.
     *
     * @return the ServiceCreditPreference instance.
     */
    protected static ServiceCreditPreference getServiceCreditPreference() {
        ServiceCreditPreference entity = new ServiceCreditPreference();

        entity.setUseAgents(true);
        entity.setUseStatusBar(true);
        entity.setUseMessageBox(true);
        entity.setOtherSetting("otherSetting1");

        return entity;
    }

    /**
     * Creates an instance of Notification.
     *
     * @return the Notification instance.
     */
    protected Notification getNotification() {
        Notification entity = new Notification();

        entity.setDate(new Date());
        entity.setDetails("details1");
        entity.setSender("sender1");
        entity.setRead(true);
        entity.setRecipient("recipient1");

        entity.setRole(getRole());
        create(entity.getRole());

        entity.setReadBy(new ArrayList<String>(Arrays.asList("readBy1")));

        return entity;
    }

    /**
     * Creates an instance of Info.
     *
     * @return the Info instance.
     */
    protected static Info getInfo() {
        Info entity = new Info();

        entity.setDate(new Date());
        entity.setDetails("details1");

        return entity;
    }

    /**
     * Creates an instance of Error.
     *
     * @return the Error instance.
     */
    protected static Error getError() {
        Error entity = new Error();

        entity.setDate(new Date());
        entity.setDetails("details1");

        return entity;
    }

    /**
     * Creates an instance of RolePermission.
     *
     * @return the RolePermission instance.
     */
    protected static RolePermission getRolePermission() {
        RolePermission entity = new RolePermission();

        entity.setRole("role1");
        entity.setAction("action1");

        return entity;
    }

    /**
     * Creates an instance of UserPermission.
     *
     * @return the UserPermission instance.
     */
    protected static UserPermission getUserPermission() {
        UserPermission entity = new UserPermission();

        entity.setUsername("username1");
        entity.setAction("action1");

        return entity;
    }

    /**
     * Creates an instance of User.
     *
     * @return the User instance.
     */
    protected User getUser() {
        User entity = new User();

        entity.setUsername("username1");
        entity.setDefaultTab(ActionTab.ADMIN);
        entity.setNetworkId("networkId1");

        entity.setRole(getRole());
        create(entity.getRole());

        entity.setFirstName("firstName1");
        entity.setLastName("lastName1");
        entity.setEmail("email1");
        entity.setTelephone("telephone1");


        entity.setStatus(getUserStatus());
        create(entity.getStatus());

        return entity;
    }

    /**
     * Creates an instance of FormType.
     *
     * @return the FormType instance.
     */
    protected static FormType getFormType() {
        FormType entity = new FormType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of Suffix.
     *
     * @return the Suffix instance.
     */
    protected static Suffix getSuffix() {
        Suffix entity = new Suffix();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of PeriodType.
     *
     * @return the PeriodType instance.
     */
    protected static PeriodType getPeriodType() {
        PeriodType entity = new PeriodType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of State.
     *
     * @return the State instance.
     */
    protected static State getState() {
        State entity = new State();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of Country.
     *
     * @return the Country instance.
     */
    protected static Country getCountry() {
        Country entity = new Country();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of AccountStatus.
     *
     * @return the AccountStatus instance.
     */
    protected static AccountStatus getAccountStatus() {
        AccountStatus entity = new AccountStatus();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of RetirementType.
     *
     * @return the RetirementType instance.
     */
    protected static RetirementType getRetirementType() {
        RetirementType entity = new RetirementType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of ServiceType.
     *
     * @return the ServiceType instance.
     */
    protected static ServiceType getServiceType() {
        ServiceType entity = new ServiceType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of Role.
     *
     * @return the Role instance.
     */
    protected static Role getRole() {
        Role entity = new Role();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of PayType.
     *
     * @return the PayType instance.
     */
    protected static PayType getPayType() {
        PayType entity = new PayType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of AppointmentType.
     *
     * @return the AppointmentType instance.
     */
    protected static AppointmentType getAppointmentType() {
        AppointmentType entity = new AppointmentType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of PaymentReversalReason.
     *
     * @return the PaymentReversalReason instance.
     */
    protected static PaymentReversalReason getPaymentReversalReason() {
        PaymentReversalReason entity = new PaymentReversalReason();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of ApplicationDesignation.
     *
     * @return the ApplicationDesignation instance.
     */
    protected static ApplicationDesignation getApplicationDesignation() {
        ApplicationDesignation entity = new ApplicationDesignation();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of PaymentStatus.
     *
     * @return the PaymentStatus instance.
     */
    protected static PaymentStatus getPaymentStatus() {
        PaymentStatus entity = new PaymentStatus();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of ClaimOfficer.
     *
     * @return the ClaimOfficer instance.
     */
    protected static ClaimOfficer getClaimOfficer() {
        ClaimOfficer entity = new ClaimOfficer();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of UserStatus.
     *
     * @return the UserStatus instance.
     */
    protected static UserStatus getUserStatus() {
        UserStatus entity = new UserStatus();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of TransferType.
     *
     * @return the TransferType instance.
     */
    protected static TransferType getTransferType() {
        TransferType entity = new TransferType();

        entity.setName("name1");

        return entity;
    }

    /**
     * Creates an instance of CalculationStatus.
     *
     * @return the CalculationStatus instance.
     */
    protected static CalculationStatus getCalculationStatus() {
        CalculationStatus entity = new CalculationStatus();

        entity.setName("name1");

        return entity;
    }

    /**
     * <p>
     * Executes the SQL statements in the file. Lines that are empty or starts with '#' will be ignore.
     * </p>
     *
     * @param file
     *            the file.
     *
     * @throws Exception
     *             to JUnit.
     */
    private static void executeSQL(String file) throws Exception {
        entityManager.getTransaction().begin();

        String[] values = readFile(file).split(";");

        for (int i = 0; i < values.length; i++) {
            String sql = values[i].trim();
            if ((sql.length() != 0) && (!sql.startsWith("#"))) {
                entityManager.createNativeQuery(sql).executeUpdate();
            }
        }

        entityManager.getTransaction().commit();
    }

    /**
     * <p>
     * Reads the content of a given file.
     * </p>
     *
     * @param fileName
     *            the name of the file to read.
     *
     * @return a string represents the content.
     *
     * @throws IOException
     *             if any error occurs during reading.
     */
    private static String readFile(String fileName) throws IOException {
        Reader reader = new FileReader(fileName);

        try {
            // Create a StringBuilder instance
            StringBuilder sb = new StringBuilder();

            // Buffer for reading
            char[] buffer = new char[1024];

            // Number of read chars
            int k = 0;

            // Read characters and append to string builder
            while ((k = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, k);
            }

            // Return read content
            return sb.toString();
        } finally {
            try {
                reader.close();
            } catch (IOException ioe) {
                // Ignore
            }
        }
    }
}