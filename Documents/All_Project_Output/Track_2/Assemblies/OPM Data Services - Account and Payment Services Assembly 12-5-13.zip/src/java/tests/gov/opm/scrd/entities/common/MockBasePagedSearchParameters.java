/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * A mockup class of BasePagedSearchParameters. Used for testing.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class MockBasePagedSearchParameters extends BasePagedSearchParameters {
    /**
     * Creates an instance of MockBasePagedSearchParameters.
     */
    public MockBasePagedSearchParameters() {
        // Empty
    }
}
