/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * A mockup class of DescriptiveNamedEntity. Used for testing.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class MockDescriptiveNamedEntity extends DescriptiveNamedEntity {
    /**
     * Creates an instance of MockDescriptiveNamedEntity.
     */
    public MockDescriptiveNamedEntity() {
        // Empty
    }
}
