/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * A mockup class of NamedEntity. Used for testing.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 */
public class MockNamedEntity extends NamedEntity {
    /**
     * Creates an instance of MockNamedEntity.
     */
    public MockNamedEntity() {
        // Empty
    }
}
