/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.common;

/**
 * <p>
 * A mockup class of OrderedNamedEntity. Used for testing.
 * </p>
 *
 * @author sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class MockOrderedNamedEntity extends OrderedNamedEntity {
    /**
     * Creates an instance of MockOrderedNamedEntity.
     */
    public MockOrderedNamedEntity() {
        // Empty
    }
}
