/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.batchprocessing.jobs.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import gov.opm.scrd.BasePersistenceTests;
import gov.opm.scrd.TestsHelper;
import gov.opm.scrd.entities.application.Account;
import gov.opm.scrd.entities.application.AccountNote;
import gov.opm.scrd.entities.application.AuditBatch;
import gov.opm.scrd.entities.application.CalculationVersion;
import gov.opm.scrd.entities.batchprocessing.InvoiceData;
import gov.opm.scrd.mock.MockReversePaymentRuleService;
import gov.opm.scrd.mock.MockWaltRuleService;
import gov.opm.scrd.services.impl.AccountServiceImpl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import junit.framework.JUnit4TestAdapter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * <p>Unit tests for {@link BillProcessorImpl} class.</p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class BillProcessorImplTests extends BasePersistenceTests {

    /** Represents the date format. */
    private static final DateFormat DF = new SimpleDateFormat("MM/dd/yyyy");

    /**
     * <p>Represents the entity manager used in tests.</p>
     */
    private static EntityManager entityManager;

    /**
     * <p>Represents the BillProcessorImpl instance for tests.</p>
     */
    private long auditBatchId;

    /**
     * <p>Represents the BillProcessorImpl instance for tests.</p>
     */
    private long accountId;

    /**
     * <p>Represents the BillProcessorImpl instance for tests.</p>
     */
    private BillProcessorImpl service;

    /**
     * <p>Represents the Spring context.</p>
     */
    private ConfigurableApplicationContext context;

    /**
     * <p>Adapter for earlier versions of JUnit.</p>
     *
     * @return a test suite.
     */
    public static junit.framework.Test suite() {
        return new JUnit4TestAdapter(BillProcessorImplTests.class);
    }

    /**
     * <p>Sets up the unit tests.</p>
     *
     * @throws Exception to JUnit.
     */
    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
        auditBatchId = create(getAuditBatch());

        Account account = getAccount();
        account.setClaimNumber("9000010");
        account.setFersDepositCalculationVersions(Arrays.asList(
                new CalculationVersion[] {getCalculationVersion()}));
        account.setFersRedepositCalculationVersions(Arrays.asList(
                new CalculationVersion[] {getCalculationVersion()}));
        accountId = create(account);
        entityManager = getEntityManager();
        context = new ClassPathXmlApplicationContext("billProcessors.xml");
        service = (BillProcessorImpl) context.getBean("billProcessor");
        service.setEntityManager(entityManager);

        AccountServiceImpl accountService = (AccountServiceImpl) context.getBean("accountService");
        TestsHelper.setField(accountService, "entityManager", entityManager);
        service.setAccountService(accountService);
        service.setAccountTotal(new BigDecimal(1000));
    }

    /**
     * <p>Cleans up the unit tests.</p>
     *
     * @throws Exception to JUnit.
     */
    @After
    public void tearDown() throws Exception {
        super.tearDown();

        if (context != null) {
            context.close();
        }
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 90: Verify calculation logic is correct for ProcessBills when PayTransStatusCode is
     * PostedPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case90() throws Exception {
        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", (new BigDecimal(986)).compareTo(service.getAccountTotal()) == 0);
        assertEquals("bill should be processed", 1, service.getBillCounter().intValue());
        assertTrue("bill should be processed", BigDecimal.ZERO.compareTo(service.getClaimantOverPaymentAmount()) == 0);
        assertEquals("bill should be processed", 0, service.getErrorCount().intValue());
        assertFalse("bill should be processed", service.getErrorFound());
        assertEquals("bill should be processed", "9000010", service.getLastPaymentsCSD());
        assertEquals("bill should be processed", 1, service.getMultiRecordAccountStatus().intValue());

        AuditBatch audit = entityManager.find(AuditBatch.class, auditBatchId);
        assertTrue("bill should be processed", processed.getAccountBalance().compareTo(new BigDecimal("800")) == 0);
        assertTrue("bill should be processed", processed.getAccountBalanceNew().compareTo(new BigDecimal("586")) == 0);
        assertTrue("bill should be processed",
                processed.getAccountPaymentTotal().compareTo(new BigDecimal("1006")) == 0);
        assertTrue("bill should be processed", processed.getFersTotalPayment().compareTo(new BigDecimal("200")) == 0);
        assertTrue("bill should be processed", processed.getTodaysPaymentTotal().compareTo(new BigDecimal("400")) == 0);
        assertTrue("audit batch should be updated", audit.getAmountImported().compareTo(new BigDecimal("1")) == 0);
        assertEquals("audit batch should be updated", 0, audit.getErrorCountProcessing().intValue());
        assertFalse("audit batch should be updated", audit.getErrorProcessing());
        assertEquals("audit batch should be updated", 3, audit.getPaymentsProcessed().intValue());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 91: Verify ProcessBills method  will not allow to process the bill if the  bill has
     * been already processed today.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case91() throws Exception {
        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        InvoiceData data1 = getInvoiceData();
        data1.setPayTransStatusCode(11);
        data1.setNumberPaymentsToday(2);
        create(data1);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);
        assertFalse("bill should not be processed", service.getProcessThisPayment());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 92: Verify ProcessBills method  will not calculate bill if the account is not active
     * and not owes money.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case92() throws Exception {
        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        data.setAccountStatus(2);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);
        assertFalse("bill should not be processed", service.getProcessThisPayment());

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill calculation should be triggered", processed.getRefundRequired());
        assertTrue("bill calculation should be triggered",
            processed.getOverThePaymentAmount().compareTo(BigDecimal.ZERO) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 93: Verify the process when Processes ReturnCode is  PaymentSuccess.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case93() throws Exception {
        service.setAccountTotal(new BigDecimal(800));

        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        TypedQuery<AccountNote> query =
                entityManager.createQuery("select e from AccountNote e where e.accountId = :accountId",
                AccountNote.class);
        query.setParameter("accountId", accountId);

        List<AccountNote> result = query.getResultList();
        assertFalse("account note must be created", result.isEmpty());
        assertEquals("account note is wrong", "stop ach letter", result.get(0).getText());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 94: Verify the process when Processes ReturnCode is PaymentRequiresRefund.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case94() throws Exception {
        // mock setting the response code to 1.
        service.setWaltRuleService(new MockWaltRuleService(1));
        service.setAccountTotal(new BigDecimal(800));

        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        TypedQuery<AccountNote> query =
                entityManager.createQuery("select e from AccountNote e where e.accountId = :accountId",
                AccountNote.class);
        query.setParameter("accountId", accountId);

        List<AccountNote> result = query.getResultList();
        assertFalse("account note must be created", result.isEmpty());
        assertEquals("account note is wrong", "credit balance", result.get(0).getText());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 95: Verify the process when Processes ReturnCode is PaymentFailure.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case95() throws Exception {
        // mock setting the response code to 3.
        service.setWaltRuleService(new MockWaltRuleService(3));
        service.setAccountTotal(new BigDecimal(800));

        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        assertTrue("Failure occurs, error should be found", service.getErrorFound());
        assertEquals("Failure occurs, error should be found", 1, service.getErrorCount().intValue());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 96: Verify the process when Processes ReturnCode is PaymentBeforeInitialBill.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case96() throws Exception {
        // mock setting the response code to 4.
        service.setWaltRuleService(new MockWaltRuleService(4));
        service.setAccountTotal(new BigDecimal(800));

        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        assertTrue("Failure occurs, error should be found", service.getErrorFound());
        assertEquals("Failure occurs, error should be found", 1, service.getErrorCount().intValue());

        TypedQuery<AccountNote> query =
                entityManager.createQuery("select e from AccountNote e where e.accountId = :accountId",
                AccountNote.class);
        query.setParameter("accountId", accountId);

        List<AccountNote> result = query.getResultList();
        assertFalse("account note must be created", result.isEmpty());
        assertEquals("account note is wrong", "payment before initial bill", result.get(0).getText());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 97: Verify ProcessBills method can set information about completed multi records to
     * the current payment record when PayTransStatusCode is PostedPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case97() throws Exception {
        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(11);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getPrintInvoice());
        assertEquals("bill should be processed", 1, processed.getAccountStatus().intValue());
        assertFalse("bill should be processed", processed.getRefundRequired());
        assertFalse("bill should be processed", processed.getAchStopLetter());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(BigDecimal.ZERO) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 98: Verify ProcessBills method can process when reverse the payment is successes (
     * PayTransStatusCode is ReversedPending).</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case98() throws Exception {
        service.setReversePaymentRuleService(new MockReversePaymentRuleService(true));

        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(13);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("reversal bill should be processed", processed.getReversedPayment());
        assertTrue("reversal bill should be processed", processed.getUpdateToCompleted());
        assertTrue("reversal bill should be processed", service.getReversalTotal().compareTo(new BigDecimal(100)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 99: Verify ProcessBills method can process when reverse the payment is failed (
     * PayTransStatusCode is ReversedPending).</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case99() throws Exception {
        service.setReversePaymentRuleService(new MockReversePaymentRuleService(false));

        InvoiceData data = getInvoiceData();
        data.setPayTransStatusCode(13);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("reversal bill should be failed", processed.getPrintInvoice());
        assertFalse("reversal bill should be failed", processed.getRefundRequired());
        assertTrue("reversal bill should be failed", service.getErrorFound());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 100: Verify ProcessBills method can process when PayTransStatusCode is
     * SuspenseRefundPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case100() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to SuspenseRefundPending
        data.setPayTransStatusCode(24);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getRefundRequired());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(100)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: CreditBalanceRefundPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101a() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to CreditBalanceRefundPending
        data.setPayTransStatusCode(60);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInvoice());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(0)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: WriteOffPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101b() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to WriteOffPending
        data.setPayTransStatusCode(53);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInvoice());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(0)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: AdjustmentPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101c() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to AdjustmentPending
        data.setPayTransStatusCode(67);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInvoice());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(0)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: BatchAutoRefundPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101d() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to BatchAutoRefundPending
        data.setPayTransStatusCode(69);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInitialBill());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(100)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: ManualAdjustmentCancelledPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101e() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to ManualAdjustmentCancelledPending
        data.setPayTransStatusCode(65);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInitialBill());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(100)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: BatchAutoRefundCanceledPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101f() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to BatchAutoRefundCanceledPending
        data.setPayTransStatusCode(64);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInitialBill());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(100)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 101: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: SuspenseDebitVoucherPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case101g() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to SuspenseDebitVoucherPending
        data.setPayTransStatusCode(72);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertFalse("bill should be processed", processed.getPrintInitialBill());
        assertTrue("bill should be processed", processed.getOverPaymentAmount().compareTo(new BigDecimal(100)) == 0);
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 102: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: AnnuityPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case102a() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to AnnuityPending
        data.setPayTransStatusCode(18);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 102: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: HealthBenefitsPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case102b() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to HealthBenefitsPending
        data.setPayTransStatusCode(40);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 102: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: VoluntaryContributionsPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case102c() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to VoluntaryContributionsPending
        data.setPayTransStatusCode(20);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 102: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: DirectPayLifePending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case102d() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to DirectPayLifePending
        data.setPayTransStatusCode(22);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
    }

    /**
     * <p>Accuracy test for the method <code>processBills()</code>.<br>
     * Corresponding to scenario 102: Verify ProcessBills method can process when PayTransStatusCode is following
     * status: DebitVoucherPending.</p>
     *
     * @throws Exception to JUnit.
     */
    @Test
    public void test_processBills_case102e() throws Exception {
        InvoiceData data = getInvoiceData();
        // set transaction status code to DebitVoucherPending
        data.setPayTransStatusCode(26);
        create(data);

        StringBuilder procMessage = new StringBuilder("test message");
        service.processBills(auditBatchId, procMessage, 2, 3, 3, 2, 2);

        InvoiceData processed = entityManager.find(InvoiceData.class, data.getId());
        assertTrue("bill should be processed", processed.getUpdateToCompleted());
    }

    /**
     * Get a sample Invoice data for testing purpose.
     *
     * @return the invoice data.
     *
     * @throws Exception if any error
     */
    private InvoiceData getInvoiceData() throws Exception {
        InvoiceData entity = new InvoiceData();
        entity.setAccountBalance(new BigDecimal(800));
        entity.setAccountBalanceNew(new BigDecimal(300));
        entity.setAccountPaymentTotal(new BigDecimal(1000));
        entity.setAccountStatus(1);
        entity.setAchPayment(true);
        entity.setAchStopLetter(false);
        entity.setDeleted(false);
        entity.setFersTotalPayment(new BigDecimal(200));
        entity.setNote("a note");
        entity.setNumberPaymentsToday(3);
        entity.setOverPaymentAmount(new BigDecimal(100));
        entity.setOverThePaymentAmount(new BigDecimal(100));
        entity.setPayTransactionKey(1);
        entity.setPayTransStatusCode(1);
        entity.setPayTransPaymentAmount(new BigDecimal(100));
        entity.setPayTransTransactionDate(DF.parse("05/10/2013"));
        entity.setPost1082DepositTotalPayment(new BigDecimal(200));
        entity.setPost1082RedepositTotalPayment(new BigDecimal(100));
        entity.setPre1082DepositTotalPayment(new BigDecimal(300));
        entity.setPre1082RedepositTotalPayment(new BigDecimal(100));
        entity.setPrintInitialBill(false);
        entity.setRefundRequired(true);
        entity.setReversedPayment(true);
        entity.setScmClaimNumber("9000010");
        entity.setScmDateOfBirth(DF.parse("05/10/1983"));
        entity.setScmName("scm name");
        entity.setTodaysPaymentTotal(new BigDecimal(400));
        entity.setUpdateCompleted(false);
        entity.setUpdateToCompleted(true);

        return entity;
    }
}
