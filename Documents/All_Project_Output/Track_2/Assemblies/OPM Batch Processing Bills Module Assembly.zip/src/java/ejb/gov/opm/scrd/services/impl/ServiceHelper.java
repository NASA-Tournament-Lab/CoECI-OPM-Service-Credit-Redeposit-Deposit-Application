/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services.impl;

/**
 * <p>
 * This class provide helper methods in this package: gov.opm.scrd.services.impl
 * </p>
 * <p>
 * <b>Thread Safety:</b> This class is immutable and thread safe.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 *
 * @since OPM - Implement Business Rules Engine Deduction Calculation Assembly
 *        v1.0
 *
 */
final class ServiceHelper {

    /**
     * <p>
     * Creates the instance of ServiceHelper.
     * </p>
     * <p>
     * This constructor is set to private to avoid creating instances.
     * </p>
     */
    private ServiceHelper() {
        // does noting
    }
    /**
     * <p>
     * Checks if the parameter is null, if yes, IllegalArgumentException will be
     * thrown.
     * </p>
     *
     * @param param
     *            the parameter to check if it is null.
     * @param name
     *            the name of the parameter.
     *
     * @throws IllegalArgumentException
     *             if the parameter is null.
     */
    static void checkNull(Object param, String name) {
        if (param == null) {
            throw new IllegalArgumentException("The parameter: " + name + " cannot be null.");
        }
    }
}
