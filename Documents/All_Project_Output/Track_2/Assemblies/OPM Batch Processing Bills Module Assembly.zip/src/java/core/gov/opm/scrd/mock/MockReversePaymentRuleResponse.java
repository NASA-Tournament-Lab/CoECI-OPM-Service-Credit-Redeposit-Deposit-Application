/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.mock;

import gov.opm.scrd.entities.application.RuleResponse;


/**
 * Mock implementation.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class MockReversePaymentRuleResponse implements RuleResponse {
    /**
     * Represents the allowed. It is accessible by getter and modified by setter. It can be any value. The
     * default value is null.
     */
    private boolean allowed;

    /**
     * Represents the description. It is accessible by getter and modified by setter. It can be any value. The
     * default value is null.
     */
    private String description;

    /**
     * Represents the return code. It is accessible by getter and modified by setter. It can be any value. The
     * default value is null.
     */
    private int returnCode;

/**
         * Instantiates a new mock reverse payment rule response.
         */
    public MockReversePaymentRuleResponse() {
    }

/**
         * Instantiates a new mock reverse payment rule response.
         *
         * @param allowed the allowed
         */
    public MockReversePaymentRuleResponse(boolean allowed) {
        this.allowed = allowed;
    }

    /**
     * Checks if is allowed.
     *
     * @return true, if is allowed
     */
    public boolean isAllowed() {
        return this.allowed;
    }

    /**
     * Sets the allowed.
     *
     * @param allowed the new allowed
     */
    public void setAllowed(boolean allowed) {
        this.allowed = allowed;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the return code.
     *
     * @return the return code
     */
    public int getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the return code.
     *
     * @param returnCode the new return code
     */
    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }
}
