/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import gov.opm.scrd.entities.common.DescriptiveNamedEntity;

/**
 * <p>
 * Represents the named entity specifying the role of the user.
 * </p>
 *
 * <p>
 * <em>Changes in 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0):</em>
 * <ul>
 * <li>Changed to extend DescriptiveNamedEntity.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.1
 */
public class Role extends DescriptiveNamedEntity {

    /**
     * Creates an instance of Role.
     */
    public Role() {
        // Empty
    }
}