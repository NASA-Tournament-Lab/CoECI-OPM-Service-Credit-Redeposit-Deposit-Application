/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.mock;

import gov.opm.scrd.entities.application.RuleRequest;


/**
 * Mock implementation.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class MockWaltRuleRequest implements RuleRequest {
}
