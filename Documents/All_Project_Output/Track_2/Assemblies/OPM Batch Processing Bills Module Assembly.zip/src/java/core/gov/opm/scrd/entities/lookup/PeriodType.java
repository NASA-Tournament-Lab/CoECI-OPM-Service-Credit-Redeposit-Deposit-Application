/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import gov.opm.scrd.entities.common.OrderedNamedEntity;

/**
 * <p>
 * Represents the named entity specifying the period type of the calculation data of the account.
 * </p>
 *
 * <p>
 * <em>Changes in 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0):</em>
 * <ul>
 * <li>Changed to extend OrderedNamedEntity.</li>
 * <li>Added fields: description</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.1
 */
public class PeriodType extends OrderedNamedEntity {
    /**
     * <p>
     * Represents the entity description. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     *
     * @since 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0)
     */
    private String description;

    /**
     * Creates an instance of PeriodType.
     */
    public PeriodType() {
        // Empty
    }

    /**
     * Gets the entity description.
     *
     * @return the entity description.
     *
     * @since 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0)
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the entity description.
     *
     * @param description
     *            the entity description.
     *
     * @since 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0)
     */
    public void setDescription(String description) {
        this.description = description;
    }
}