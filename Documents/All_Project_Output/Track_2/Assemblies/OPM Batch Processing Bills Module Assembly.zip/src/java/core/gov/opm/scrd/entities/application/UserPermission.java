/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

/**
 * <p>
 * This is the class representing the permissions table for the specific user.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class UserPermission extends IdentifiableEntity {
    /**
     * <p>
     * Represents the name of the user. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String username;
    /**
     * <p>
     * Represents the action performed by the user. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private String action;

    /**
     * Creates an instance of UserPermission.
     */
    public UserPermission() {
        // Empty
    }

    /**
     * Gets the name of the user.
     *
     * @return the name of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the name of the user.
     *
     * @param username
     *            the name of the user.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the action performed by the user.
     *
     * @return the action performed by the user.
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the action performed by the user.
     *
     * @param action
     *            the action performed by the user.
     */
    public void setAction(String action) {
        this.action = action;
    }
}