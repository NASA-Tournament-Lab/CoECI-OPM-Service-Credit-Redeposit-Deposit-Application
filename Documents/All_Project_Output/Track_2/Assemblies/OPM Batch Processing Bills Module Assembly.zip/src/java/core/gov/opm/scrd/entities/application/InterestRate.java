/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

import java.math.BigDecimal;

/**
 * <p>
 * Represents the entity specifying interest rate.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class InterestRate extends IdentifiableEntity {
    /**
     * <p>
     * Represents the interest year. It is managed with a getter and setter. It may have any value. It is fully mutable.
     * </p>
     */
    private Integer interestYear;
    /**
     * <p>
     * Represents the interest rate. It is managed with a getter and setter. It may have any value. It is fully mutable.
     * </p>
     */
    private BigDecimal interestRate;

    /**
     * Creates an instance of InterestRate.
     */
    public InterestRate() {
        // Empty
    }

    /**
     * Gets the interest year.
     *
     * @return the interest year.
     */
    public Integer getInterestYear() {
        return interestYear;
    }

    /**
     * Sets the interest year.
     *
     * @param interestYear
     *            the interest year.
     */
    public void setInterestYear(Integer interestYear) {
        this.interestYear = interestYear;
    }

    /**
     * Gets the interest rate.
     *
     * @return the interest rate.
     */
    public BigDecimal getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the interest rate.
     *
     * @param interestRate
     *            the interest rate.
     */
    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }
}