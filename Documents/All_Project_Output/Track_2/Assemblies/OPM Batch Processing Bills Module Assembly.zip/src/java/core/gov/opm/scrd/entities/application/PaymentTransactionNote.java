/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

/**
 * <p>
 * Represents the entity specifying notes for payment transactions.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class PaymentTransactionNote extends IdentifiableEntity {
    /**
     * <p>
     * Represents the transaction key of note. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     */
    private Long payTransactionKey;
    /**
     * <p>
     * Represents the note text. It is managed with a getter and setter. It may have any value. It is fully mutable.
     * </p>
     */
    private String note;

    /**
     * Creates an instance of PaymentTransactionNote.
     */
    public PaymentTransactionNote() {
        // Empty
    }

    /**
     * Gets the transaction key of note.
     *
     * @return the transaction key of note.
     */
    public Long getPayTransactionKey() {
        return payTransactionKey;
    }

    /**
     * Sets the transaction key of note.
     *
     * @param payTransactionKey
     *            the transaction key of note.
     */
    public void setPayTransactionKey(Long payTransactionKey) {
        this.payTransactionKey = payTransactionKey;
    }

    /**
     * Gets the note text.
     *
     * @return the note text.
     */
    public String getNote() {
        return note;
    }

    /**
     * Sets the note text.
     *
     * @param note
     *            the note text.
     */
    public void setNote(String note) {
        this.note = note;
    }
}