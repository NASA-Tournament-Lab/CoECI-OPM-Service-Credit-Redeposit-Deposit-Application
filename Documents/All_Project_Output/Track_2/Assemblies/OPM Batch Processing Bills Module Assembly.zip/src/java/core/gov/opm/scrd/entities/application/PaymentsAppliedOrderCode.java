/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

/**
 * <p>
 * Represents the entity specifying payments applied order code.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class PaymentsAppliedOrderCode extends IdentifiableEntity {
    /**
     * <p>
     * Represents the payment account. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String paymentAccount;
    /**
     * <p>
     * Represents the display order. It is managed with a getter and setter. It may have any value. It is fully mutable.
     * </p>
     */
    private Integer displayOrder;

    /**
     * Creates an instance of PaymentsAppliedOrderCode.
     */
    public PaymentsAppliedOrderCode() {
        // Empty
    }

    /**
     * Gets the payment account.
     *
     * @return the payment account.
     */
    public String getPaymentAccount() {
        return paymentAccount;
    }

    /**
     * Sets the payment account.
     *
     * @param paymentAccount
     *            the payment account.
     */
    public void setPaymentAccount(String paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    /**
     * Gets the display order.
     *
     * @return the display order.
     */
    public Integer getDisplayOrder() {
        return displayOrder;
    }

    /**
     * Sets the display order.
     *
     * @param displayOrder
     *            the display order.
     */
    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }
}