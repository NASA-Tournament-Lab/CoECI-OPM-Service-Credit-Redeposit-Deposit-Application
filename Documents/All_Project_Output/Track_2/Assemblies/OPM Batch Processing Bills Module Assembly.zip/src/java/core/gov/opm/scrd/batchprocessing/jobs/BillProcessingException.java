/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.batchprocessing.jobs;

/**
 * <p>This exception is thrown when there is any problem when processing bills.</p>
 *  <p>Thread - safety. The class is not thread - safe.</p>
 *
 * @author faeton, TCSASSEMBLER
 * @version 1.0
 */
public class BillProcessingException extends Exception {
    /** The serial version id. */
    private static final long serialVersionUID = -5495038353380970808L;

	/**
     * Constructor with message parameter.
     *
     * @param message exception message.
     */
    public BillProcessingException(String message) {
        super(message);
    }

	/**
     * Constructor with message and cause parameter.
     *
     * @param message exception message.
     * @param cause exception cause.
     */
    public BillProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
