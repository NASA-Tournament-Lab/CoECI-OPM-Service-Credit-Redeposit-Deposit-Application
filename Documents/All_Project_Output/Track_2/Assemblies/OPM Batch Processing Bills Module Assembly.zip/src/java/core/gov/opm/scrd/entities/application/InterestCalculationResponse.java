/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import java.util.List;

/**
 * <p>
 * This class represents the response for interest calculation.
 * </p>
 * <p>
 * <b>Thread Safety:</b>
 * This class is not thread safe since it's mutable.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 * @since OPM Rules Engine Models Exceptions and Interest Calculation v1.0 Assembly
 *
 */
public class InterestCalculationResponse extends BaseCalculationResponse {
    /**
     * Represents the extended service periods that are output of the interest calculation process.
     */
    private List<ExtendedServicePeriod> extendedServicePeriods;

    /**
     * Creates the instance of InterestCalculationResponse.
     */
    public InterestCalculationResponse() {
        // does nothing
    }

    /**
     * Gets the extended service periods that are output of the interest calculation process.
     * @return the extended service periods that are output of the interest calculation process.
     */
    public List<ExtendedServicePeriod> getExtendedServicePeriods() {
        return extendedServicePeriods;
    }

    /**
     * Sets the extended service periods that are output of the interest calculation process.
     * @param extendedServicePeriods the extended service periods that are output of the interest calculation process.
     */
    public void setExtendedServicePeriods(List<ExtendedServicePeriod> extendedServicePeriods) {
        this.extendedServicePeriods = extendedServicePeriods;
    }
}

