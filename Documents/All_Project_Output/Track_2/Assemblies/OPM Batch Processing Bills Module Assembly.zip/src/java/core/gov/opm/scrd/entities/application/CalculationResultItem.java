/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;
import gov.opm.scrd.entities.lookup.PeriodType;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * This is the class representing the single item of the aggregated result of the calculation.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 */
public class CalculationResultItem extends IdentifiableEntity {
    /**
     * <p>
     * Represents the start date of calculation result item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private Date startDate;
    /**
     * <p>
     * Represents the end date of calculation result item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private Date endDate;
    /**
     * <p>
     * Represents the mid date of calculation result item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private Date midDate;
    /**
     * <p>
     * Represents the effective date of calculation result item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private Date effectiveDate;
    /**
     * <p>
     * Represents the period type of calculation result item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private PeriodType periodType;
    /**
     * <p>
     * Represents the deduction amount of calculation result item. It is managed with a getter and setter. It may have
     * any value. It is fully mutable.
     * </p>
     */
    private BigDecimal deductionAmount;
    /**
     * <p>
     * Represents the total interest of calculation result item. It is managed with a getter and setter. It may have any
     * value. It is fully mutable.
     * </p>
     */
    private BigDecimal totalInterest;
    /**
     * <p>
     * Represents the amount of applied payments of calculation result item. It is managed with a getter and setter. It
     * may have any value. It is fully mutable.
     * </p>
     */
    private BigDecimal paymentsApplied;
    /**
     * <p>
     * Represents the balance of calculation result item. It is managed with a getter and setter. It may have any value.
     * It is fully mutable.
     * </p>
     */
    private BigDecimal balance;

    /**
     * Creates an instance of CalculationResultItem.
     */
    public CalculationResultItem() {
        // Empty
    }

    /**
     * Gets the start date of calculation result item.
     *
     * @return the start date of calculation result item.
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Sets the start date of calculation result item.
     *
     * @param startDate
     *            the start date of calculation result item.
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * Gets the end date of calculation result item.
     *
     * @return the end date of calculation result item.
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the end date of calculation result item.
     *
     * @param endDate
     *            the end date of calculation result item.
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * Gets the mid date of calculation result item.
     *
     * @return the mid date of calculation result item.
     */
    public Date getMidDate() {
        return midDate;
    }

    /**
     * Sets the mid date of calculation result item.
     *
     * @param midDate
     *            the mid date of calculation result item.
     */
    public void setMidDate(Date midDate) {
        this.midDate = midDate;
    }

    /**
     * Gets the effective date of calculation result item.
     *
     * @return the effective date of calculation result item.
     */
    public Date getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the effective date of calculation result item.
     *
     * @param effectiveDate
     *            the effective date of calculation result item.
     */
    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Gets the period type of calculation result item.
     *
     * @return the period type of calculation result item.
     */
    public PeriodType getPeriodType() {
        return periodType;
    }

    /**
     * Sets the period type of calculation result item.
     *
     * @param periodType
     *            the period type of calculation result item.
     */
    public void setPeriodType(PeriodType periodType) {
        this.periodType = periodType;
    }

    /**
     * Gets the deduction amount of calculation result item.
     *
     * @return the deduction amount of calculation result item.
     */
    public BigDecimal getDeductionAmount() {
        return deductionAmount;
    }

    /**
     * Sets the deduction amount of calculation result item.
     *
     * @param deductionAmount
     *            the deduction amount of calculation result item.
     */
    public void setDeductionAmount(BigDecimal deductionAmount) {
        this.deductionAmount = deductionAmount;
    }

    /**
     * Gets the total interest of calculation result item.
     *
     * @return the total interest of calculation result item.
     */
    public BigDecimal getTotalInterest() {
        return totalInterest;
    }

    /**
     * Sets the total interest of calculation result item.
     *
     * @param totalInterest
     *            the total interest of calculation result item.
     */
    public void setTotalInterest(BigDecimal totalInterest) {
        this.totalInterest = totalInterest;
    }

    /**
     * Gets the amount of applied payments of calculation result item.
     *
     * @return the amount of applied payments of calculation result item.
     */
    public BigDecimal getPaymentsApplied() {
        return paymentsApplied;
    }

    /**
     * Sets the amount of applied payments of calculation result item.
     *
     * @param paymentsApplied
     *            the amount of applied payments of calculation result item.
     */
    public void setPaymentsApplied(BigDecimal paymentsApplied) {
        this.paymentsApplied = paymentsApplied;
    }

    /**
     * Gets the balance of calculation result item.
     *
     * @return the balance of calculation result item.
     */
    public BigDecimal getBalance() {
        return balance;
    }

    /**
     * Sets the balance of calculation result item.
     *
     * @param balance
     *            the balance of calculation result item.
     */
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}