/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.batchprocessing.jobs;

/**
 * <p>This interface defines the contract for processing bills.</p>
 *
 * <p>Thread - safety. The implementation should be effectively thread - safe.</p>
 *
 * @author faeton, TCSASSEMBLER
 * @version 1.0
 */
public interface BillProcessor {
    /**
     * Processes the bills data.
     *
     * @param auditBatchIDLog the id of audit batch log.
     * @param procMessage logging message used to collect information about process.
     * @param invoiceCount general information counter for invoices.
     * @param achStopCount general information counter for ACH stop markers.
     * @param refundMemoCount general information counter for refund memos.
     * @param reversalCount general information counter for reversal payments.
     * @param initialBillCount general information counter for initial biils.
     *
     * @throws BillProcessingException if there is any problem executing the method.
     */
    public void processBills(Long auditBatchIDLog, StringBuilder procMessage, Integer invoiceCount,
        Integer achStopCount, Integer refundMemoCount, Integer reversalCount, Integer initialBillCount)
        throws BillProcessingException;
}
