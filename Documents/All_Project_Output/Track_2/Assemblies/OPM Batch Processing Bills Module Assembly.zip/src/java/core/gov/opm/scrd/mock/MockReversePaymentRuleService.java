/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.mock;

import gov.opm.scrd.services.OPMException;
import gov.opm.scrd.services.RuleService;


/**
 * Mock implementation.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class MockReversePaymentRuleService implements RuleService<MockReversePaymentRuleRequest, MockReversePaymentRuleResponse> {
    /**
     * Represents the allowed. It is accessible by getter and modified by setter. It can be any value. The
     * default value is null.
     */
    private boolean allowed;

/**
         * Instantiates a new mock reverse payment rule service.
         */
    public MockReversePaymentRuleService() {
    }

/**
         * Instantiates a new mock reverse payment rule service.
         *
         * @param allowed the allowed
         */
    public MockReversePaymentRuleService(boolean allowed) {
        this.allowed = allowed;
    }

    /**
     * Mock execute method.
     *
     * @param request the mock request
     *
     * @return the rule response
     *
     * @throws OPMException if any error
     */
    public MockReversePaymentRuleResponse execute(MockReversePaymentRuleRequest request)
        throws OPMException {
        MockReversePaymentRuleResponse response = new MockReversePaymentRuleResponse(allowed);

        return response;
    }

    /**
     * Checks if is allowed.
     *
     * @return true, if is allowed
     */
    public boolean isAllowed() {
        return allowed;
    }

    /**
     * Sets the allowed.
     *
     * @param allowed the new allowed
     */
    public void setAllowed(boolean allowed) {
        this.allowed = allowed;
    }
}
