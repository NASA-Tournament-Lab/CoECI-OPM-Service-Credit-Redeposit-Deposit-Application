/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;


/**
 * <p>
 * This exception will be thrown by RuleService to indicate errors that occurred while executing the rules.
 * </p>
 *
 * <p>
 * <b>Thread Safety:</b> This exception is not thread-safe because its super class is mutable.
 * </p>
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 * @since OPM Rules Engine Models Exceptions and Interest Calculation v1.0 Assembly
 */
public class RuleServiceException extends OPMException {
    /**
     * Default serial ID.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new exception instance with no error message and no cause of error.
     */
    public RuleServiceException() {
    }

    /**
     * Creates a new exception instance with this error message.
     *
     * @param message - the error message
     */
    public RuleServiceException(String message) {
        super(message);
    }

    /**
     * Creates a new exception instance with no error message and the given cause of error.
     *
     * @param cause - the cause of error
     */
    public RuleServiceException(Throwable cause) {
        super(cause);
    }

    /**
     * Creates a new exception instance with an error message and the given cause of error.
     *
     * @param message - the error message
     * @param cause - the cause of error
     */
    public RuleServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}

