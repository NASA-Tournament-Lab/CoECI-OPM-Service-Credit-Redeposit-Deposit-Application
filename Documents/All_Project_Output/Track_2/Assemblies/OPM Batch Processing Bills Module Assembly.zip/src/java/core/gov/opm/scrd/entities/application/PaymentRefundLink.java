/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

/**
 * <p>
 * Represents the entity specifying payment refund link.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class PaymentRefundLink extends IdentifiableEntity {
    /**
     * <p>
     * Represents the id of payment of link. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private Long paymentNeedingRefund;
    /**
     * <p>
     * Represents the id of refund transaction of link. It is managed with a getter and setter. It may have any value.
     * It is fully mutable.
     * </p>
     */
    private Long refundForPayment;

    /**
     * Creates an instance of PaymentRefundLink.
     */
    public PaymentRefundLink() {
        // Empty
    }

    /**
     * Gets the id of payment of link.
     *
     * @return the id of payment of link.
     */
    public Long getPaymentNeedingRefund() {
        return paymentNeedingRefund;
    }

    /**
     * Sets the id of payment of link.
     *
     * @param paymentNeedingRefund
     *            the id of payment of link.
     */
    public void setPaymentNeedingRefund(Long paymentNeedingRefund) {
        this.paymentNeedingRefund = paymentNeedingRefund;
    }

    /**
     * Gets the id of refund transaction of link.
     *
     * @return the id of refund transaction of link.
     */
    public Long getRefundForPayment() {
        return refundForPayment;
    }

    /**
     * Sets the id of refund transaction of link.
     *
     * @param refundForPayment
     *            the id of refund transaction of link.
     */
    public void setRefundForPayment(Long refundForPayment) {
        this.refundForPayment = refundForPayment;
    }
}