/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.services;

import gov.opm.scrd.entities.application.DeductionCalculationRequest;
import gov.opm.scrd.entities.application.DeductionCalculationResponse;

/**
 * <p>
 * DeductionCalculationRuleService provides methods to execute rules to calculate
 * Deduction.
 * </p>
 *
 * <p>
 * <b> Thread Safety: </b> Implementations must be effectively thread safe.
 * Refer to ADS 1.3.4 for general assumptions and notes on thread safety.
 * </p>
 *
 * @author albertwang, TCSASSEMBLER
 * @version 1.0
 * @since  OPM - Implement Business Rules Engine Deduction Calculation Assembly v1.0
 */
public interface DeductionCalculationRuleService
    extends RuleService<DeductionCalculationRequest, DeductionCalculationResponse> {

}

