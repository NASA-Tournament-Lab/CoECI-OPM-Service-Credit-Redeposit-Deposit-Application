/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.lookup;

import gov.opm.scrd.entities.common.OrderedNamedEntity;

/**
 * <p>
 * Represents the named entity specifying the status of the account.
 * </p>
 *
 * <p>
 * <em>Changes in 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0):</em>
 * <ul>
 * <li>Changed to extend OrderedNamedEntity.</li>
 * <li>Added fields: category</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.1
 */
public class AccountStatus extends OrderedNamedEntity {
    /**
     * <p>
     * Represents the account status category. It is managed with a getter and setter. It may have any value. It is
     * fully mutable.
     * </p>
     *
     * @since 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0)
     */
    private String category;

    /**
     * Creates an instance of AccountStatus.
     */
    public AccountStatus() {
        // Empty
    }

    /**
     * Gets the account status category.
     *
     * @return the account status category.
     *
     * @since 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0)
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the account status category.
     *
     * @param category
     *            the account status category.
     *
     * @since 1.1 (OPM - Data Migration - Entities Update Module Assembly 1.0)
     */
    public void setCategory(String category) {
        this.category = category;
    }
}