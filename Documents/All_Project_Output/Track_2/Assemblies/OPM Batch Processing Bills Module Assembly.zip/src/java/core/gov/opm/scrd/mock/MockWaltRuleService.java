/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.mock;

import gov.opm.scrd.services.OPMException;
import gov.opm.scrd.services.RuleService;


/**
 * Mock Implementation.
 *
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class MockWaltRuleService implements RuleService<MockWaltRuleRequest, MockWaltRuleResponse> {
    /**
     * Represents the return code. It is accessible by getter and modified by setter. It can be any value. The
     * default value is null.
     */
    private int returnCode;

    /**
     * Instantiates a new mock walt rule service.
     */
    public MockWaltRuleService() {
    }

    /**
     * Instantiates a new mock walt rule service.
     *
     * @param returnCode the return code
     */
    public MockWaltRuleService(int returnCode) {
        this.returnCode = returnCode;
    }

    /**
     * Mock the execute method.
     *
     * @param request the rule request
     *
     * @return the response of execution
     *
     * @throws OPMException if any error
     */
    @Override
    public MockWaltRuleResponse execute(MockWaltRuleRequest request)
        throws OPMException {
        MockWaltRuleResponse response = new MockWaltRuleResponse();
        response.setReturnCode(returnCode);

        return response;
    }

    /**
     * Gets the return code.
     *
     * @return the return code
     */
    public int getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the return code.
     *
     * @param returnCode the new return code
     */
    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }
}
