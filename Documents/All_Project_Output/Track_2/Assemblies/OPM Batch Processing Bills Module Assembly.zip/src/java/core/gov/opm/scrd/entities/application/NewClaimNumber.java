/*
 * Copyright (C) 2013 TopCoder Inc., All Rights Reserved.
 */
package gov.opm.scrd.entities.application;

import gov.opm.scrd.entities.common.IdentifiableEntity;

/**
 * <p>
 * Represents the entity specifying new claim number for account.
 * </p>
 *
 * <p>
 * <strong>Thread Safety: </strong> This class is mutable and not thread safe.
 * </p>
 *
 * @author faeton, sparemax
 * @version 1.0
 * @since OPM - Data Migration - Entities Update Module Assembly 1.0
 */
public class NewClaimNumber extends IdentifiableEntity {
    /**
     * <p>
     * Represents the claim number of entity. It is managed with a getter and setter. It may have any value. It is fully
     * mutable.
     * </p>
     */
    private String claimNumber;

    /**
     * Creates an instance of NewClaimNumber.
     */
    public NewClaimNumber() {
        // Empty
    }

    /**
     * Gets the claim number of entity.
     *
     * @return the claim number of entity.
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the claim number of entity.
     *
     * @param claimNumber
     *            the claim number of entity.
     */
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }
}