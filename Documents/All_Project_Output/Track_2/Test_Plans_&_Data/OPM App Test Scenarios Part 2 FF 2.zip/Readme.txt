Hi Reviewer,
  1. 2.32 Get Help on ARS is quite different with prototype, so following the prototype in this case.

  2. 2.33.1.3�� 2.33.1.4 and 2.33.1.5 are not included because it's not included on the prototype, so we need to follow the latest prototype.

Thanks