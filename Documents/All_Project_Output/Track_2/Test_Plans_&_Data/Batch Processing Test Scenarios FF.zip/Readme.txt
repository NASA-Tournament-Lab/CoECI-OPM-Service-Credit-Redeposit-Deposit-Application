Hi Reviewer,

  1. As this is only windows service, so not many performance requirement, and most of operation is done from database backend, so there have not much performance requirement for this project.

  2. http://apps.topcoder.com/forums/?module=Thread&threadID=805727&start=0, we should follow the FF_OPM_Track1_Architecture_ServiceCreditBatchService_Module_Arch and source code.

  3. Resource folder contain table structure and the Input Batch File (R-file) format.
Thanks!