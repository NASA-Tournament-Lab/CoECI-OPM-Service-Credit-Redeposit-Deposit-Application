$(document).ready(function () {

	//mockup userroles
	//set userrole in cookie
	$(".userRoleList li a").click(function() {
		var roleId = $(this).attr("id");
		var roleName = $(this).text();
		setCookie("opm_userroleid", roleId);
		setCookie("opm_userrolename", roleName);
		if ( (roleId == "userRole1") || (roleId == "userRole3") || (roleId == "userRole5") || (roleId == "userRole7") || (roleId == "userRole8") || (roleId == "userRole9") || (roleId == "userRole11") || (roleId == "userRole12") || (roleId == "userRole13") ){
			window.location = "index2.html";
		}else{
			window.location = "index.html";
		}
	});
	
	//Load user role from cookie
	var currentUserRole = getCookie("opm_userroleid");
	var currentUserRoleName = getCookie("opm_userrolename");
	if ( (typeof currentUserRole ===  'undefined') || (currentUserRole == "" ) || (currentUserRole == null )){
		var currentUserRole = "userRole10";
		var currentUserRoleName = "System Administrator";
	}
	$(".roleName").text(currentUserRoleName).after("<a href='splash.html' style='position: absolute; top: 46px;right: -60px; font-weight: normal; color: #dddddd'>Change</a>");
	if ( currentUserRole == "userRole1"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		
	}else if ( currentUserRole == "userRole2"){
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		
	}else if ( currentUserRole == "userRole3"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		
	}else if ( currentUserRole == "userRole4"){
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		
	}else if ( currentUserRole == "userRole5"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		
	}else if ( currentUserRole == "userRole6"){
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Adjust Account
		$(".jsEditBillingInfo").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Change AccountStatus
		$("select[name='status']").attr("disabled", true);
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable Generate Statement
		$(".jsPrintFinalStatement, .jsReprintStatement").hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		//disable View Audit Trail
		$(".jsPHAuditHistory, .jsPendingPaymentsViewAuditTrail, .jsInterestAdjustmentViewAuditTrail, .jsPaymentMovesViewAuditTrail, .jsShowAuditTrail").hide();
		
	}else if ( currentUserRole == "userRole7"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Change AccountStatus
		$("select[name='status']").attr("disabled", true);
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Generate Statement
		$(".jsPrintFinalStatement, .jsReprintStatement").hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		
	}else if ( currentUserRole == "userRole8"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Change AccountStatus
		$("select[name='status']").attr("disabled", true);
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		
	}else if ( currentUserRole == "userRole9"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Account
		$(".jsEditBillingInfo").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Change Account
		$(".jsEditBasicInfo").hide();
		//disable Change AccountStatus
		$("select[name='status']").attr("disabled", true);
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Generate Statement
		$(".jsPrintFinalStatement, .jsReprintStatement").hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		
	}else if ( currentUserRole == "userRole10"){
		
	}else if ( currentUserRole == "userRole11"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Account
		$(".jsEditBillingInfo").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Change Account
		$(".jsEditBasicInfo").hide();
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Generate Statement
		$(".jsPrintFinalStatement, .jsReprintStatement").hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		//disable View Audit Trail
		$(".jsPHAuditHistory, .jsPendingPaymentsViewAuditTrail, .jsInterestAdjustmentViewAuditTrail, .jsPaymentMovesViewAuditTrail, .jsShowAuditTrail").hide();
	}else if ( currentUserRole == "userRole12"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Change AccountStatus
		$("select[name='status']").attr("disabled", true);
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		//disable View Audit Trail
		$(".jsPHAuditHistory, .jsPendingPaymentsViewAuditTrail, .jsInterestAdjustmentViewAuditTrail, .jsPaymentMovesViewAuditTrail, .jsShowAuditTrail").hide();
	}else if ( currentUserRole == "userRole13"){
		//disable Add Account
		$(".topNav li").eq(1).hide();
		//disable Add Over The Counter Payments
		$(".addPaymentPopup input[name='addPaymentType']").eq(2).hide().next("label").hide();
		//disable Add Payment Transactions
		$(".jsAddPayment").hide();
		//disable Add Service History
		$(".serviceHistoryPanel .jsNewVersionBtn").hide();
		$(".serviceHistoryPanel #copyCurrent, .serviceHistoryPanel #recopyCurrent").hide().next("label").hide();
		//disable Adjust Account
		$(".jsEditBillingInfo").hide();
		//disable Adjust Interest
		$(".jsUpdateInterest").hide();
		//disable Approve Payment Transactions
		$(".topNav li").eq(5).hide();
		//disable Assign User Roles
		$(".adminTab .tabsBar li").eq(1).hide();
		//disable Calculate Service History
		$(".jsRunCalculation, .jsSaveCalculation ").hide();
		//disable Change Account
		$(".jsEditBasicInfo").hide();
		//disable Delete Notes
		$(".jsDelNote, .jsDelNotePopup").hide();
		//disable Delete Service History
		$(".jsDelVersionBtn").hide();
		//disable edit Notes
		$(".jsEditNote, .jsEditNotePopup").hide();
		//disable Edit Service History
		$(".entriesTbl").addClass("entriesTblUnedit");
		//disable Generate Statement
		$(".jsPrintFinalStatement, .jsReprintStatement").hide();
		//disable Post Payment Transaction
		$(".jsPostCheckedPaymentsSuspense").hide();
		//disable Recalculate Initial Billing
		$(".accountDetailsTabsArea .jsRunCalculation ").hide();
		//disable Reverse Payment Transaction
		$(".jsPHReversePayment").hide();
		//disable View Audit Trail
		$(".jsPHAuditHistory, .jsPendingPaymentsViewAuditTrail, .jsInterestAdjustmentViewAuditTrail, .jsPaymentMovesViewAuditTrail, .jsShowAuditTrail").hide();
	}

	//mockup pagination
	$('.jsGoPrev').click(function() {
		var wrapper = $(this).parent();
		if ((!$(this).hasClass("paginationBtnDisabled")) && ($('.jsGoPage', wrapper).length > 1)){
			var prevItem = $('.currentPage', wrapper).prev(".jsGoPage");
			if (prevItem.length < 1){
				var prevItem = $('.currentPage', wrapper).prev().prev(".jsGoPage");
			}
			$('.jsGoPage', wrapper).removeClass("currentPage");
			prevItem.addClass("currentPage");
			$('.jsGoNext', wrapper).removeClass("paginationBtnDisabled");
			var currentIdx = parseInt(prevItem.text(), 10);
			if (currentIdx == 1){
				$('.jsGoPrev', wrapper).addClass("paginationBtnDisabled");
			}
			var totalCount =  parseInt($(".totalNum").text(), 10);
			var startNum = (currentIdx - 1)* 10 + 1;
			var endNum = currentIdx * 10;
			endNum =Math.min(totalCount, endNum);
		}
		$(".startNum").text(startNum);
		$(".endNum").text(endNum);
		showPaginationDot(wrapper);
	});
	$('.jsGoNext').click(function() {
		var wrapper = $(this).parent();
		if ((!$(this).hasClass("paginationBtnDisabled")) && ($('.jsGoPage', wrapper).length > 1)){
			var nextItem = $('.currentPage', wrapper).next(".jsGoPage");
			if (nextItem.length < 1){
				var nextItem = $('.currentPage', wrapper).next().next(".jsGoPage");
			}
			$('.jsGoPage', wrapper).removeClass("currentPage");
			nextItem.addClass("currentPage");
			$('.jsGoPrev', wrapper).removeClass("paginationBtnDisabled");
			var currentIdx = parseInt(nextItem.text(), 10);
			var totalIdx =  parseInt($('.jsGoPage:last', wrapper).text(), 10);
			
			if (currentIdx == totalIdx ){
				$('.jsGoNext', wrapper).addClass("paginationBtnDisabled");
			}
			
			var totalCount =  parseInt($(".totalNum").text(), 10);
			var startNum = (currentIdx - 1)* 10 + 1;
			var endNum = currentIdx * 10;
			endNum =Math.min(totalCount, endNum);
		}
		$(".startNum").text(startNum);
		$(".endNum").text(endNum);
		showPaginationDot(wrapper);
	});
	$('.jsGoPage').click(function() {
		var wrapper = $(this).parent();
		if ((!$(this).hasClass("currentPage")) && ($('.jsGoPage', wrapper).length > 1)){
			$('.jsGoPage', wrapper).removeClass("currentPage");
			$(this).addClass("currentPage");
			$('.jsGoNext', wrapper).removeClass("paginationBtnDisabled");
			$('.jsGoPrev', wrapper).removeClass("paginationBtnDisabled");
			var currentIdx = parseInt($(this).text(), 10);
			var totalIdx =  parseInt($('.jsGoPage:last', wrapper).text(), 10);
			if (currentIdx == 1){
				$('.jsGoPrev', wrapper).addClass("paginationBtnDisabled");
			}
			if (currentIdx == totalIdx ){
				$('.jsGoNext', wrapper).addClass("paginationBtnDisabled");
			}
			
			var totalCount =  parseInt($(".totalNum").text(), 10);
			var startNum = (currentIdx - 1)* 10 + 1;
			var endNum = currentIdx * 10;
			endNum =Math.min(totalCount, endNum);
		}
		$(".startNum").text(startNum);
		$(".endNum").text(endNum);
		showPaginationDot(wrapper);
	});

	
	/**
	 * enable textbox with placeholder functionality
	 * selector - the jQuery selector of the textbox
	 * text - the placeholder text
	 */
	var initPlaceHolder = function(selector) {

		$(selector).each(function(index, element) {
			var placeholderTxt = $(this).next(".placeholderTxt");
			if (placeholderTxt.length < 1){
				//no need placeholder
			}else{
				var placeholderTxt = placeholderTxt.text();
				if ($(this).val() === "" || $(this).val() === placeholderTxt){
					$(this).addClass("showPlaceholder").val(placeholderTxt);
				}else{
					$(this).removeClass("showPlaceholder");	
				}
				$(this).on('focus', function() {
					$(this).on('blur', function() {
						$(this).unbind('blur', arguments.callee);
						if ($(this).val() === '') {
							$(this).val(placeholderTxt).addClass("showPlaceholder");
						}
					});
					if ($(this).val() === placeholderTxt) {
						$(this).val('').removeClass("showPlaceholder");
					}
				});
			}
        });
	};
	initPlaceHolder("textarea.paymentNotes");
	initPlaceHolder("input.helpSearchInput");
	initPlaceHolder("input.birthDateInput");

	//top navigation hover
	$('.topNav li').mouseenter(function(){
		$(this).next("li").addClass("noSep");
	}).mouseleave(function(){
		$(this).next("li").removeClass("noSep");
		$('.topNav li.current').next("li").addClass("noSep");
	});
	$('.topNav li.current').next("li").addClass("noSep");
	
	//btn active style
	$("body").delegate(".priBtn", "mousedown", function(){
		if ( ! $(this).hasClass("priBtnDisabled")){
			$(this).addClass("priBtnActive");
		}
	}).delegate(".priBtn", "mouseup mouseleave", function(){
		$(this).removeClass("priBtnActive");
	});
	
	$("body").delegate(".priHighBtn", "mousedown", function(){
		if ( ! $(this).hasClass("priHighBtnDisabled")){
			$(this).addClass("priHighBtnActive");
		}
	}).delegate(".priHighBtn", "mouseup mouseleave", function(){
		$(this).removeClass("priHighBtnActive");
	});
	$("body").delegate(".paginationBtn", "mousedown", function(){
		if ( ! $(this).hasClass("paginationBtnDisabled")){
			$(this).addClass("paginationBtnActive");
		}
	}).delegate(".paginationBtn", "mouseup mouseleave", function(){
		$(this).removeClass("paginationBtnActive");
	});
	
	//Input focus style
	$("body").delegate("input.text, textarea, select", "focus", function(){
		if (! $(this).is('[readonly]')){
			$(this).addClass("focus").removeClass("error").parent(".selectWrapper").removeClass("selectWrapperError");
			var fieldRow = $(this).parents(".halfRowField");
			if ($(".error", fieldRow).length < 1){
				$(".errorIcon", fieldRow).remove();
			}
		}

	}).delegate("input.text, textarea", "blur", function(){
		$(this).removeClass("focus");
	});
	
	
	//Work Queue Paage Filter click
	$('.caseOptions input:radio').eq(0).prop('checked', true);
	$('.caseOptions input:radio').change(function(){
        var currentVal = $('.caseOptions input[name=caseFilter]:checked').val();
		var panel = $(this).parents(".casesPanel").eq(0);
		$(".panelBody > div", panel).hide();
		$("." + currentVal + "Block", panel).show();
		$(".jsUnassignCase", panel).hide();
		if (currentVal === "showAssigned"){
			$(".jsUnassignCase", panel).show();
		}
		$(".casesPanel tbody tr").removeClass("selectedRow");
    }); 
	
	//Select Case
	$('.casesPanel tbody tr').click(function(){
        $(this).toggleClass("selectedRow");
    });

	//Unassign Case 
	$('.jsUnassignCase').click(function(){
		var currentVal = $('.caseOptions input[name=caseFilter]:checked').val();
		var currentTbl = $("." + currentVal + "Block table");
		if ( $(".selectedRow", currentTbl).length < 1 ){
			showPopup(".wqUnassignmentPopup");
		}else{
			$(".selectedRow", currentTbl).find(".assignee").parent().remove();
			var rows = $(".selectedRow", currentTbl);
			var pendingTbl = $("#allPendingCasesTbl tbody");
			rows.each(function(index, element) {
                var row = rows.eq(index);
				row.find(".assignee").parent("td").remove();
				//var ssnCell = row.find(".ssn");
				//ssnTxt = ssnCell.text().replace(/-/g, "").replace(/(\w{3})(\w{2})(\w+)/, "$1-$2-$3");
				//ssnCell.text(ssnTxt);
				pendingTbl.append(row);
            });
		}
    });
	
	//Reassign Case
	$('.jsReassignCase').click(function(){
		var currentVal = $('.caseOptions input[name=caseFilter]:checked').val();
		var currentTbl = $("." + currentVal + "Block table");
		if ( $(".selectedRow", currentTbl).length < 1 ){
			showPopup(".wqAssignmentPopup");
		}else{
			showPopup(".accountAssignmentPopup");
			$(".accountAssignmentPopup .accountList li").removeClass("selected").eq(0).addClass("selected");
		}
    });
	$(".accountAssignmentPopup .accountList li").click(function(){
		$(".accountAssignmentPopup .accountList li").removeClass("selected");
		$(this).addClass("selected");
	});
	
	//Do Reassign Case
	$(".jsDoReassignCase").click(function(){
		var currentVal = $('.caseOptions input[name=caseFilter]:checked').val();
		var assignedTbl = $("#assignedCasesTbl tbody");
		var currentTbl = $("." + currentVal + "Block table");
		var selectedAccount = $(this).parents(".popup").eq(0).find(".accountList li.selected");
		if (selectedAccount.length > 0){
			accountName = selectedAccount.eq(0).text();
			if (currentVal === "showAssigned"){
				$(".selectedRow", assignedTbl).removeClass("selectedRow").find(".assignee").text(accountName);
			}else{
				var rows = $(".selectedRow", currentTbl);
				rows.each(function(index, element) {
					var row = rows.eq(index);
					row.append("<td><span class='assignee'>" + accountName + "</span></td>").removeClass("selectedRow");
					//var ssnCell = row.find(".ssn");
					//ssnTxt = ssnCell.text().replace(/(\w{3})(\w{2})(\w+)/, "$1-$2-$3");
					//ssnCell.text(ssnTxt);
					assignedTbl.append(row);
				});
			}
			closePopup(); 
		}
    });
	
	//Cancel Reassign Case
	$(".jsCancelReassignCase").click(function(){
		closePopup(); 
    });

	//Assign to me
	$('.jsAssignToMe').click(function(){
		var currentVal = $('.caseOptions input[name=caseFilter]:checked').val();
		var currentTbl = $("." + currentVal + "Block table");
		if ( $(".selectedRow", currentTbl).length < 1 ){
			showPopup(".wqAssignmentPopup");
		}else{
			var assignedTbl = $("#assignedCasesTbl tbody");
			if (currentVal === "showAssigned"){
				$(".selectedRow", assignedTbl).removeClass("selectedRow").find(".assignee").text("John Doe");
			}else{
				var rows = $(".selectedRow", currentTbl);
				rows.each(function(index, element) {
					var row = rows.eq(index);
					row.append("<td><span class='assignee'>John Doe</span></td>").removeClass("selectedRow");
					//var ssnCell = row.find(".ssn");
					//ssnTxt = ssnCell.text().replace(/(\w{3})(\w{2})(\w+)/, "$1-$2-$3");
					//ssnCell.text(ssnTxt);
					assignedTbl.append(row);
				});
			}
		}
    });
	
	//double click to open case
	$("#assignedCasesTbl tbody").delegate("tr", "dblclick", function(){
		window.location = "AccountDetails.html";
    });
	
	//double click to assign to me
	$("#allPendingCasesTbl tbody, #allProcessedCasesTbl tbody").delegate("tr", "dblclick", function(){
		var assignedTbl = $("#assignedCasesTbl tbody");
		$(this).append("<td><span class='assignee'>John Doe</span></td>").removeClass("selectedRow");
		//var ssnCell = $(this).find(".ssn");
		//ssnTxt = ssnCell.text().replace(/(\w{3})(\w{2})(\w+)/, "$1-$2-$3");
		//ssnCell.text(ssnTxt);
		assignedTbl.append($(this));
    });
	
	//Close Popup
	$('.jsClosePopup').click(function() {
		closePopup();  
	});

	//datepicker
	$("input.datePicker").datepicker({
		showOn: "button",
		buttonImage: "i/calendar.png",
		buttonImageOnly: true,
		changeMonth: true,
		changeYear: true,yearRange: "-100:+1",
		onSelect: function(){
			$(this).removeClass("error");	
		}
	});
	
	//Date Input Validation after enter
	$("body").delegate("input.datePicker", "blur keypress", function(e) {
		if(e.type === 'keypress' && e.keyCode !== 13) return;
		$(this).removeClass("error");
		var currVal = $(this).val();
		if(currVal == ''){
			//no value
			$(this).addClass("error");
			return false;
		}
		//Declare Regex 
		var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
		var rxDatePattern2 = /^(\d{2})(\d{2})(\d{4})$/;
		var dtArray = currVal.match(rxDatePattern); // is format OK?
		
		if (dtArray == null ){
			dtArray = currVal.match(rxDatePattern2); // is format2 OK?
			if (dtArray == null ){
				$(this).addClass("error");
				return false;	
			}else{
				dtMonth = dtArray[1];
				dtDay= dtArray[2];
				dtYear = dtArray[3];
			}
		}else{
			dtMonth = dtArray[1];
			dtDay= dtArray[3];
			dtYear = dtArray[5];
		}
		
		if (dtMonth < 1 || dtMonth > 12){
			//month not correct
			$(this).addClass("error");
		}else if (dtDay < 1 || dtDay> 31){
			//day not correct
			$(this).addClass("error");
		}else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31){
			//no day#31 of this month
			$(this).addClass("error");
		}else if (dtMonth == 2)	{
			var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
			if (dtDay> 29 || (dtDay ==29 && !isleap)){
				//Check leap year, no day#29 of this Jan
				$(this).addClass("error");
			}
		}
		if ( $(this).hasClass("error") ){
			return false;
		}else{
			var retValue = '';
			retValue = padding(dtMonth, 2) + "/" + padding(dtDay, 2) + "/" + dtYear;
			$(this).val(retValue);
		}
	});
	
	//set up required fields based on country selected
	if ( $("select[name='country']").length > 0){
		checkRequiredFields($("select[name='country']")[0]);
	}
	
	if ($(".chartCalAreaBoxEq").length > 0){
		var h = 100;
		$(".chartCalAreaBoxEq").height("");
		$(".chartCalAreaBoxEq").each(function(index, element) {
            var newH = parseInt($(this).height(), 10);
			h = Math.max(h, newH);
        });
		$(".chartCalAreaBoxEq").height(h);
	}
	
	
	//Step 1 Next button click
	$('.jsStep1Next').click(function() {
		var contentArea = $(this).parents("#content").eq(0);
		var reqMarks = $(".reqMark", contentArea);
		reqMarks.each(function(index, element) {
			if (!$(this).hasClass("isHidden")){
				var reqFiled = reqMarks.eq(index).parents(".halfRowField").eq(0);
				$(".errorIcon", reqFiled).remove();
				if (($("input.text", reqFiled).length > 0) && (($("input.text", reqFiled).val() == "") || ($("input.text", reqFiled).hasClass("showPlaceholder")))){
					$("input.text", reqFiled).addClass("error");
					reqFiled.append("<span class='errorIcon'></span>");
				}else if(($("select", reqFiled).length > 0) && ($("select", reqFiled)[0].selectedIndex == 0 )){
					$("select", reqFiled).addClass("error");
					$("select", reqFiled).parent(".selectWrapper").addClass("selectWrapperError");
					reqFiled.append("<span class='errorIcon'></span>");
				}
			}
        });
		if ($(".errorIcon", contentArea).length < 1){
			window.location = "CreateNewAccount_ServiceHistory.html";
		}
	});
	
	//Date Calculator
	$('.jsCalBtn').click(function() {
		var block = $(this).parents(".dateCalculator");
		var sDate = $("input[name=sDate]", block).val();
		var eDate = $("input[name=eDate]", block).val();
		if (sDate == ""){
			$(".errorMsg", block).text("Start Date is invalid");
			$(".errorMask", block).show();
		}else if (eDate == ""){
			$(".errorMsg", block).text("End Date is invalid");
			$(".errorMask", block).show();	
		}else{
			var cells = $("#calResultsTbl tbody td");
			cells.eq(0).text("01");
			cells.eq(1).text("03");
			cells.eq(2).text("12");
			cells.eq(3).text("1.4");
			cells.eq(4).text("400");
			cells.eq(5).text("200");
		}
	});
	
	//Date Calculator Error Close
	$('.jsRetryCalc').click(function() {
		$(this).parent(".errorMask").hide();
	});
	
	//Show Status Info popup
	$('.jsShowStatusInfoPopup').click(function() {
		$(this).parent().hide();
		$('.infoNotiPopup .filerTab li a').eq(0).trigger("click");
		showPopup(".infoNotiPopup");
	});
	
	//Info popup filer click
	$('.infoNotiPopup .filerTab li a').click(function() {
		var popup = $(this).parents(".popup").eq(0);
		var filter = $(this).attr("id");
		if ( filter == "rowAll"){
			$(".infoNotiPopup #infoTbl tr").show();
			$(".infoNotiPopup #infoTbl tr td").show();
		}else{
			$(".infoNotiPopup #infoTbl tr").hide();
			$(".infoNotiPopup #infoTbl tr td").hide();
			var rows = $("td > ." + filter, popup).parent().parent();
			rows.show().find("td").show();
		}
		$('.infoNotiPopup .filerTab li a').removeClass("current");
		$(this).addClass("current");
	});
	
	$('.infoNotiPopup .jsClosePopup').click(function() {
		$(".statusInfoBar").show();
	});
	//Show Notification
	$('.jsShowNotifications').click(function() {
		showNoti(".notificationPopup");
	});

	$(window).resize(function() {
		if ($(".notificationPopup:visible").length > 0){
			positionNoti();
		}
		if ($(".noValidMask:visible").length > 0){
			positionNoValidMask();
		}
		if ($(".printScrollArea:visible").length > 0){
			var winHeight = parseInt($(window).height(),10);
			$(".printScrollArea:visible").css({
				maxHeight: (winHeight - 100)
			});
			var popup = $(".printScrollArea:visible").parents(".popup").eq(0);
			popup.css('display', 'block').css('margin', -popup.height() / 2 + 'px 0 0 ' + (-popup.width() / 2) + 'px');
		}
	});
	
	//Show tooltips
	$(".jsShowTips").hover(function(){
		showTooltips("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ac euismod augue. Maecenas tristique sit amet leo ut ullamcorper. Donec aliquam elementum erat sit amet fringilla.", $(this));
	},function(){
		hideTooltips();
	});
	
	//Seperate date input fields
	$(".datePickerInput").datepicker({
		showOn: "button",
		buttonImage: "i/calendar.png",
		buttonImageOnly: true,
		changeMonth: true,
		changeYear: true,yearRange: "-100:+1",		
		beforeShow: function (input, inst) {
			setTimeout(function () {
				inst.dpDiv.css({
					marginTop: 22
				});
			}, 0);
		},
		onSelect: function(dateText, inst) {
			//dateText comes in as MM/DD/YY
			var datePieces = dateText.split('/');
			var month = datePieces[0];
			var day = datePieces[1];
			var year = datePieces[2];
			var wrapper = inst.input.parent().parent();
			//define select option values for corresponding element
			$('.dpMonth', wrapper).val(month).removeClass("showPlaceholder");
			$('.dpDay', wrapper).val(day).removeClass("showPlaceholder");
			$('.dpYear', wrapper).val(year).removeClass("showPlaceholder");
		}
	});
	
	//Init datepicker setDate
	$(".datePickerInput").each(function(index, element) {
        var wrapper = $(this).parents("fieldRow").eq(0);
		var nYear = parseInt($('.dpYear', wrapper).val(), 10);
		var nMonth = parseInt($('.dpMonth', wrapper).val(), 10);
		var nDay = parseInt($('.dpDay', wrapper).val(), 10); 
		var nDate = new Date(nYear , (nMonth-1), nDay)
		
		if (isDate(nMonth+'/'+nDay+'/'+nYear)){
			$('.datePickerInput', wrapper).datepicker('setDate', nDate);
		}
    });
	
	//Manually updated date
    $('.dpYear, .dpMonth, .dpDay').change(function() {
		if (isNaN( $(this).val() )){
			$(this).val("");
		}
		var wrapper = $(this).parent();
		var nYear = parseInt($('.dpYear', wrapper).val(), 10);
		var nMonth = parseInt($('.dpMonth', wrapper).val(), 10);
		var nDay = parseInt($('.dpDay', wrapper).val(), 10); 
		var nDate = new Date(nYear , (nMonth-1), nDay)
		
		if (isDate(nMonth+'/'+nDay+'/'+nYear)){
			$('.datePickerInput', wrapper).datepicker('setDate', nDate);
		}
    });
	
	//Click top nav view account button
	$('.jsShowSearchAccountPanel').click(function() {
		$(".viewAccountSearchFormWrapper").show();
		$(".topNav").addClass("showingSearchAccountPanel");
		$(".topNav li.current").addClass("tCurrent").removeClass("current");
		$(".topNav li").removeClass("noSep");
		//$(this).parent().next("li").addClass("noSep2");
	});
	
	
	//index page
	if ($(".jsShowViewAccountOverlay").length > 0){
		$(".jsShowSearchAccountPanel").trigger("click");
	}
	
	//Hide Search Account Panel
	$('.jsCloseViewAccount, .jsCancelSearchAccount').click(function() {
		$(".viewAccountSearchFormWrapper").hide();
		$(".topNav").removeClass("showingSearchAccountPanel");
		$(".topNav li.tCurrent").addClass("current").removeClass("tCurrent");
		$(".topNav li.current").next("li").addClass("noSep");
		//$('.jsShowSearchAccountPanel').parent().next("li").removeClass("noSep2");
	});
	
	//Search Account Btn click
	$('.jsSearchAccount').click(function() {
		var searchPanel = $(this).parents(".viewAccountSearchForm").eq(0);
		//if ($(".noRecordMsg:visible", searchPanel).length > 0){
			window.location = "Account_SearchResults.html";
		//}else{
		//	$(".noRecordMsg", searchPanel).show();
		//}
	});

	$(".viewAccountSearchForm input[type=text]").val("");
	$(".viewAccountSearchForm input[type=checkbox]").prop("checked", false);
	//Search Account Btn click
	$('.jsClearSearchAccount').click(function() {
		var searchPanel = $(this).parents(".viewAccountSearchForm").eq(0);
		$(".noRecordMsg", searchPanel).hide();
		$("input[type=text]", searchPanel).val("");
		$("input[type=checkbox]", searchPanel).prop("checked", false);
	});
	
	//mockup pagination
	$(".paginationLabel").each(function(index, element) {
        var wrapper = $(this).parents(".pagination").eq(0);
		$(this).find(".totalCount").text($(".toPage", wrapper).length * 10);
		$(this).find(".startCount").text("1");
		$(this).find(".endCount").text("10");
    });
	$('.toPrev').click(function() {
		var wrapper = $(this).parent().parent();
		if ((!$(this).hasClass("toPrevDisabled")) && ($('.toPage', wrapper).length > 1)){
			var prevItem = $('.current', wrapper).prev(".toPage");
			prevItem.trigger("click");
		}
	});
	$('.toNext').click(function() {
		var wrapper = $(this).parent().parent();
		if ((!$(this).hasClass("toNextDisabled")) && ($('.toPage', wrapper).length > 1)){
			var nextItem = $('.current', wrapper).next(".toPage");
			nextItem.trigger("click");
		}
	});
	$('.toPage').click(function() {
		var wrapper = $(this).parent().parent();
		if ((!$(this).hasClass("current")) && ($('.toPage', wrapper).length > 1)){
			$('.toPage', wrapper).removeClass("current");
			$(this).addClass("current");
			$('.toNext', wrapper).removeClass("toNextDisabled");
			$('.toPrev', wrapper).removeClass("toPrevDisabled");
			var currentIdx = parseInt($(this).text(), 10);
			var totalIdx =  parseInt($('.toPage', wrapper).length, 10);
			if (currentIdx == 1){
				$('.toPrev', wrapper).addClass("toPrevDisabled");
			}
			if (currentIdx == totalIdx ){
				$('.toNext', wrapper).addClass("toNextDisabled");
			}
		}
		wrapper.find(".startCount").text( (parseInt($(".current", wrapper).text(),10)-1)*10 + 1 );
		wrapper.find(".endCount").text(parseInt($(".current", wrapper).text(), 10)* 10  );
		hidePagination($(this));
	});
	$(".pagination .current").each(function() {
		hidePagination($(this));
	});
	
	//Step 2 Next button click
	$('.jsStep2Next').click(function() {
		window.location = "CreateNewAccount_Notes.html";
	});
	//Step 2 Validate Entries
	$(".jsValidateEntries").click(function() {
		
		var tab = $(this).parents(".tabsBlock").eq(0);
		var status = $(".validationStatusBar .statusVal", tab);
		var entriesTblRows = $(".entriesTbl tbody tr:not(.entriesEditRow)", tab);
		entriesTblRows.removeClass("valErrorRow").removeClass("valErrorRowBefore").removeClass("valErrorRowAfter");
		if (status.hasClass("successLabel")){
			status.html("Failure").removeClass("successLabel").addClass("failLabel");
			entriesTblRows.eq(1).addClass("valErrorRow");
			entriesTblRows.eq(1).find("td").eq(7).addClass("valErrorRowCell");
			entriesTblRows.eq(2).find("td").eq(0).addClass("starMark");
			$(".valErrorRow").prev("tr").addClass("valErrorRowBefore");
			$(".valErrorRow").next("tr").addClass("valErrorRowAfter");
		}else{
			status.html("Success").addClass("successLabel").removeClass("failLabel");
			$(".valErrorRowCell", tab).removeClass("valErrorRowCell");
			$(".valErrorRowBefore", tab).removeClass("valErrorRowBefore");
			$(".valErrorRowAfter", tab).removeClass("valErrorRowAfter");
		}

	});
	var vEmpty = $(".validateResultTbl tbody").eq(0).html();
	var vSuccess = $(".validateResultTbl tfoot").eq(0).html();
	$(".jsRunCalculation").click(function() {
		var tab = $(this).parents(".tabsBlock").eq(0);
		$(".jsValidateEntries", tab).trigger("click");
		$(".jsCancelFunction", tab).show();
		$(".jsTriggerBill", tab).hide();
		$(".jsShowCalculation", tab).show();
		$(".jsShowSample", tab).removeClass("priBtnDisabled");
		$(".jsExpandCalculation", tab).removeClass("priBtnDisabled");
		if ($(".noValidMask:visible", tab).length > 0){
			$(".noValidMask", tab).hide();
			var validTbl = $(".validateResultTbl", tab);
			$("tbody", validTbl).html(vSuccess);
		}
		 
		var result = $(".validationStatusBar .resultsVal", tab);
		result.html("Success").addClass("successLabel");
	});
	$(".jsSaveCalculation ").click(function() {
		var tab = $(this).parents(".tabsBlock").eq(0);
		$(".jsRunCalculation", tab).trigger("click");
		$(".jsCancelFunction", tab).hide();
		$(".jsTriggerBill", tab).show();
		var result = $(".validationStatusBar .resultsVal", tab);
		result.html("Status Calculation Saved").addClass("successLabel");
		
		//save editing Cell
		$(".scrollTblArea #depValTbl .editingCell").each(function() {
            var  newVal = $("input.text", $(this)).val();
			if ( newVal == ""){
				newVal = "0";
			}
			newVal = "$" + newVal;		
			$(this).html(newVal);
			$(this).removeClass("editingCell");
        });
		
		
	});
	$("body").delegate("td.editableCel", "click", function(){
		if ( ! $(this).hasClass("editingCell") ){
			$(this).addClass("editingCell");
			var val = $(this).text().replace("$", "");
			$(this).html('<input type="text" value="' + val + '" class="text amount" name="amount">');
			
		}
	})
	
	
	$(".jsTriggerBill").click(function() {
		var tab = $(this).parents(".tabsBlock").eq(0);
		var result = $(".validationStatusBar .resultsVal", tab);
		result.html("Status Calculation Triggered Pending").addClass("successLabel");
		$(this).hide();
	});
	
	$(".jsCancelFunction").click(function() {
		var tab = $(this).parents(".tabsBlock").eq(0);
		var result = $(".validationStatusBar .resultsVal", tab);
		var status = $(".validationStatusBar .statusVal", tab);
		status.html("Unknown").removeClass("successLabel");
		result.html("Unknown").removeClass("successLabel");
		$(".jsShowSample", tab).addClass("priBtnDisabled");
		$(".jsExpandCalculation", tab).addClass("priBtnDisabled");
		$(".noValidMask", tab).show();
		$(".jsCancelFunction", tab).hide();
		$(".jsShowCalculation", tab).hide();
		var validTbl = $(".validateResultTbl", tab);
		$("tbody", validTbl).html(vEmpty);
		$(".valErrorRowCell", tab).removeClass("valErrorRowCell");
		$(".valErrorRowBefore", tab).removeClass("valErrorRowBefore");
		$(".valErrorRowAfter", tab).removeClass("valErrorRowAfter");
	});
	
	$(".jsNewVersionBtn").click(function() {
		var tab = $(this).parents(".tabsBlock").eq(0);
		$(".jsCancelFunction", tab).trigger("click");
		$(".jsTriggerBill", tab).hide("");
		var verSelector = $(".versionBar select", tab);
		verSelector.append($('<option>', {
			value: '',
			text: 'New Version'
		}));
		var idx = $("option", verSelector).length - 1;
		$(".versionBar select", tab)[0].selectedIndex = idx;
		var tbl = $(".entriesTbl tbody", tab).eq(0);
		tbl.html('<tr><td class="blankCell firstCol">&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class="lastCol">&nbsp;</td></tr>');
	});
	 
	var editRowHTML = $(".entriesTbl tfoot").html();
	var viewRowHTML = '<tr class="even"><td class="blankCell firstCol">&nbsp;</td><td>01/01/2001</td><td>01/11/2012</td><td>01/11/2012</td><td>FERS Deposit</td><td>CSRS</td><td>Deposit</td><td>Career</td><td>Wage Grade</td><td>$ 20,000.00</td><td class="lastCol">Refund/Lump Sum</td></tr>';
	$("body").delegate(".entriesTbl tbody td", "click", function() {
		if(! $(this).parents("table").eq(0).hasClass("entriesTblUnedit")){
			var tr = $(this).parent("tr");
			if (($(this).hasClass("blankCell")) && (tr.hasClass("entriesEditRow"))){
				tr.after(viewRowHTML);
			}else if (tr.hasClass("entriesEditRow")){
				return;
			}else {
				tr.after(editRowHTML);
				var newRow = tr.next();
				if ( tr.hasClass("emptyRow")){
					tr.removeClass("emptyRow");	
					$("input", newRow).val("");
					$("select", newRow).each(function(index, element) {
					   $(this)[0].selectedIndex = 0;
					});
				}
				$(".bDate, .eDate, .rDate", newRow).addClass("datePicker");
				$("input.datePicker", newRow).datepicker({
					showOn: "button",
					buttonImage: "i/calendar.png",
					buttonImageOnly: true,
					changeMonth: true,
					changeYear: true,yearRange: "-100:+1",
					onSelect: function(){
						$(this).removeClass("error");	
					}
				});
			}
			var editRow = tr.next("tr");
			if (tr.hasClass("valErrorRow")){
				editRow.addClass("valErrorRow");
			}
			if (tr.hasClass("valErrorRowBefore")){
				editRow.addClass("valErrorRowBefore");
			}
			if (tr.hasClass("valErrorRowAfter")){
				editRow.addClass("valErrorRowAfter");
			}
			tr.remove();
		}
	});
	
	$("body").delegate(".entriesEditRow input, .entriesEditRow select, tr.editing input, tr.editing select", "focus", function(){
		$(this).parents("td").eq(0).addClass("editingCell");
	}).delegate(".entriesEditRow input, .entriesEditRow select, tr.editing input, tr.editing select", "blur", function(){
		$(this).parents("td").eq(0).removeClass("editingCell");
	});

	$("body").delegate(".editingCell", "keydown", function(e){
		var keyCode = e.keyCode || e.which; 
		if (keyCode == 9) {
			var tBody = $(this).parents("tbody").eq(0); 
			var count = $("td", tBody).length - 1;
			var currentIdx = $("td", tBody).index($(this));
			if (currentIdx == count){
				e.preventDefault();
				tBody.append(editRowHTML);
				var newRow = $("tr:last-child", tBody);
				$("input", newRow).val("");
				$(".bDate, .eDate", newRow).addClass("datePicker");
				$("input.datePicker", newRow).datepicker({
					showOn: "button",
					buttonImage: "i/calendar.png",
					buttonImageOnly: true,
					changeMonth: true,
					changeYear: true,yearRange: "-100:+1",
					onSelect: function(){
						$(this).removeClass("error");	
					}
				});
				$("select", newRow).each(function(index, element) {
				   $(this)[0].selectedIndex = 0;
				});
				newRow.addClass("newAddeeRow");
				$("td", newRow).addClass("newRowCellHidden").removeClass("editingCell").eq(1).removeClass("newRowCellHidden");
				// call custom function here
				$("input", newRow)[0].focus();
			}
			var nextCell = $(this).next("td");
			if (nextCell.hasClass("newRowCellHidden")){
				nextCell.trigger("click");
			}
			if ($(".noValidMask:visible").length > 0){
				positionNoValidMask();
			}
		}
	});
	$("body").delegate(".newRowCellHidden input", "focus", function(){
		$(this).parent().removeClass("newRowCellHidden");
	});
	$("body").delegate(".newRowCellHidden", "click", function(e){
		$(this).removeClass("newRowCellHidden");
		//$("input", $(this)).show().focus();
		//$("select",  $(this)).show().focus();
		if(e.hasOwnProperty('originalEvent')){
			$("input", $(this)).show().focus();
			$("select",  $(this)).show().focus();
		}else{
			if ($("input", $(this)).length > 0){
				$("input", $(this)).show().get(0).click();
			}else if ($("select", $(this)).length > 0){
				$("select", $(this)).show().get(0).click();
			}
		}
	});
	//Tabs click
	$(".tabsBar a").click(function() {
		targetBlock = $(this).attr("id");
		//If tab has ID, switch tab display within same page
		if ( !((typeof(targetBlock) == "undefined" ) || (targetBlock == ""))){
			var bar = $(this).parents(".tabsBar").eq(0);
			$("a", bar).removeClass("current");
			$(this).addClass("current");
			var wrapper = bar.parent();
			$("> .tabsBlock", wrapper).hide();
			$("div." + targetBlock, wrapper).show();
			positionNoValidMask();
			$(".pageTitleArea .accountBtns .jsPrintStatement").hide();
			if ( targetBlock === "employeeTab" ){
				$(".pageTitleArea .accountBtns .jsPrintStatement").show();
			}
			if ( targetBlock === "serviceHistoryTab" ){
				var h = 100;
				$(".chartCalAreaBoxEq").height("");
				$(".chartCalAreaBoxEq").each(function(index, element) {
					var newH = parseInt($(this).height(), 10);
					h = Math.max(h, newH);
				});
				$(".chartCalAreaBoxEq").height(h);
			}
		}
	});
	
	//Expand/collapse Panel
	$(".jsTogglePanel").click(function() {
		$(this).toggleClass("panelExpanded");
		if ($(this).hasClass("panelExpanded")){
			$(this).parent().find(".panelBody").show();
		}else{
			$(this).parent().find(".panelBody").hide();
		}
	});
	
	if ($(".noValidMask:visible").length > 0){
		positionNoValidMask();
	}
	

	$("#accountSearchResultTbl tbody td, .accountNotesPanel tbody td").mouseenter(function(){
		$(this).parent("tr").addClass("rowHover");
	}).mouseleave(function(){
		$(this).parent("tr").removeClass("rowHover");
	})
	
	$("#accountSearchResultTbl tbody td").click(function() {
		window.location = "AccountDetails.html";
	});
	//Delete Account version
	$(".jsDelVersionBtn").click(function() {
		showPopup(".confirmDeletionPopup");
	});
	$(".jsConfirmDeletion").click(function() {
		closePopup();
	});
	
	//Account Notes
	$(".accountNotesPanel tbody td:not(.checkCell)").click(function() {
		showPopup(".accountNotesPopup");
	});	
	$(".jsEditNotePopup").click(function() {
		closePopup();
		showPopup(".accountNotesEditPopup");
		
	});
	$(".jsEditNote").click(function() {	
		var checked = $("#accountNoteTbl tbody input:checked");
		if (checked.length < 1){
			closePopup();
			showPopup(".noAccountNoteSelectedEditPopup ");
		}else {
			closePopup();
			showPopup(".accountNotesEditPopup ");
		}
	});	
	$(".jsDelNote").click(function() {	
		var checked = $("#accountNoteTbl tbody input:checked");
		if (checked.length < 1){
			closePopup();
			showPopup(".noAccountNoteSelectedPopup ");
		}else {
			closePopup();
			showPopup(".delAccountNotePopup ");
		}
	});	
	$(".jsDelNotePopup").click(function() {
		closePopup();
		showPopup(".delAccountNotePopup ");
	});	
	
	
	
	$(".jsDoDelAccountNote").click(function() {
		var checked = $("#accountNoteTbl tbody input:checked");
		checked.parents("tr").remove();
		closePopup();
	});	

	
	//Checkbox check all 
	$(".checkGroup input[type=checkbox]").click(function(e){
		e.stopPropagation();
		var checkGroup = $(this).parents(".checkGroup").eq(0);
		if ($(this).hasClass("checkAllRow")){
			if($(this).prop("checked")){ 
				$(".checkRow", checkGroup).prop("checked", true);
			} else {
				$(".checkRow", checkGroup).prop("checked", false); 
			} 	
		}
		if ($(this).hasClass("checkRow")){
			var allCount = $(".checkRow", checkGroup).length;
			var checkedCount = $(".checkRow:checked", checkGroup).length;
			if (checkedCount == allCount){
				$(".checkAllRow", checkGroup).prop("checked", true);
			}else{
				$(".checkAllRow", checkGroup).prop("checked", false);
			}
		}
	});
	
	
	//Payment notes
	$(".jsShowPHNote").click(function(e){	
		showPopup(".paymentNotePopup ");
	});
	$(".jsAddPayment").click(function(){	
		showPopup(".addPaymentPopup ");
	});

	//Print Popups
	$(".jsPHReceipt").click(function(e){	
		showPopup(".printPaymentReceiptPopup");
	});
	$(".jsPrintAccountSummary").click(function(e){	
		showPopup(".printSummaryPopup");
	});
	$(".jsPrintFinalStatement").click(function(e){	
		showPopup(".printFinalStatementPopup");
	});
	
	$(".jsPrintStatement, .jsReprintStatement").click(function(e){	
		showPopup(".printStatementPopup");
	});

	//Do Print
	$(".jsDoPrintPaymentReceipt").click(function(e){	
		window.open('AccountDetails_PaymentHistory_PaymentReceipt_printview.html','PaymentReceipt','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
		return false;
	});
	$(".jsDoPrintAccountSummary").click(function(e){	
		window.open('AccountDetails_PrintSummary_printview.html','Summary','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
		return false;
	});
	$(".jsDoPrintFinalStatement").click(function(e){	
		window.open('AccountDetails_BillingSummary_PrintStatement_printview.html','FinalStatement','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
		return false;
	});
	$(".jsDoPrintStaement").click(function(e){	
		window.open('AccountDetails_PrintStatement_printview.html','Statement','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
		return false;
	});
	
	
	$("#paymentHistoryTbl .jsShowRowAction").click(function(e){	
		$("#paymentHistoryTbl .jsShowRowAction").removeClass("jsShowRowActionCellFocus");
		$(this).addClass("jsShowRowActionCellFocus");
		var position = $(this).offset();
		var w = parseInt($(this).width(), 10) ;
		$(".rowActions").show().css({
			top: position.top - 3,
			left: position.left + w - 5
		});
		var idx = $(this).parent().index();
		if ($(".rowActions .currentRowNum").length < 1){
			$(".rowActions .rowActionBodyInner").append("<span class='isHidden currentRowNum'></span");
		}
		$(".rowActions .currentRowNum").text(idx);
	}).mouseenter(function(){
		$(this).addClass("jsShowRowActionCellHover");
	}).mouseleave(function(){
		$(this).removeClass("jsShowRowActionCellHover");
	});
	
	$(".rowActions .jsEditPayment").click(function(e){	
		var idx = parseInt($(".rowActions .currentRowNum").text(), 10);
		var row = $("#paymentHistoryTbl tbody tr").eq(idx);
		
		//load row value to popup window
		var val1 = $("td", row).eq(1).text();
		var val2 = $("td", row).eq(2).text();
		var val3 = $("td", row).eq(3).text();
		var val4 = $("td", row).eq(4).text();
		var val5 = $("td", row).eq(5).text().replace('$', '');
		var val6 = $("td", row).eq(6).text();
		var val7 = $("td", row).eq(7).text();
		var val8 = $("td", row).eq(8).text();
		
		$(".editPaymentPopup input[name='batchNum']").val(val1);
		$(".editPaymentPopup input[name='blockNum']").val(val2);
		$(".editPaymentPopup input[name='seqNum']").val(val3);
		$(".editPaymentPopup input[name='depositDate']").val(val4);
		$(".editPaymentPopup input[name='paymentAmount']").val(val5);
		showPopup(".editPaymentPopup");
	});
	
	
	
	$("#paymentHistoryTbl tbody td").dblclick(function(){	
		$(".jsPHReceipt").trigger("click");
		clearSelection();
	});
	
	//hide menu
	$("body").click(function(e){	
		if (e.target.className.indexOf("jsShowRowAction") < 0){
			$(".jsShowRowAction").removeClass("jsShowRowActionCellFocus");
			$(".rowActions").hide();	
		}
	});
	
	//Edit Employee Basic tab
	$(".jsEditBasicInfo").click(function(e){	
		$(".accountBasicInfoPanel").hide();
		$(".accountBasicInfoPanelEdit").show();
		$(".employeeTab .rowCheckStatus").removeClass("rowCheckShow");
		$(".employeeTab .accountBasicInfoPanelEdit .checkValidateInputBox").hide();
		$(".employeeTab .accountBasicInfoPanelEdit .tabBtnsWrapper .priBtn").hide();
		$(".employeeTab .accountBasicInfoPanelEdit .tabBtnsWrapper .editEmployeeBtn").show();
	});
	$(".jsCancelEditBasicInfo").click(function(e){
		$(".employeeTab .rowCheckStatus").removeClass("rowCheckShow");
		$(".accountBasicInfoPanel").show();
		$(".accountBasicInfoPanelEdit").hide();
	});
	$(".jsSaveEditBasicInfo").click(function(e){
		$(".employeeTab .rowCheckStatus").removeClass("rowCheckShow");
		var statusTxt = $("select[name='status']").find("option:selected").text();
		$(".employeeTab .accountBasicInfoPanel .halfRowField").eq(0).find(".fieldVal").text(statusTxt);
		$(".accountBasicInfoPanel").show();
		$(".accountBasicInfoPanelEdit").hide();
		showPopup(".confirmSaveEmployeePopup");
	});
	$(".jsConfirmNewAccountValidity").click(function(e){
		$(".employeeTab .rowCheckStatus").removeClass("rowCheckShow");
		$(".accountBasicInfoPanel").hide();
		$(".accountBasicInfoPanelEdit").show();
		$(".employeeTab .accountBasicInfoPanelEdit .checkValidateInputBox").show();
		$(".employeeTab .accountBasicInfoPanelEdit .tabBtnsWrapper .priBtn").hide();
		$(".employeeTab .accountBasicInfoPanelEdit .tabBtnsWrapper .validEmployeeBtn").show();
	});
	$(".jsCancelConfirmNewAccountValidity").click(function(e){
		$(".employeeTab .rowCheckStatus").removeClass("rowCheckShow");
		$(".accountBasicInfoPanel").show();
		$(".accountBasicInfoPanelEdit").hide();
	});
	$(".jsRejectConfirmNewAccountValidity").click(function(e){
		showPopup(".rejectAccountPopup");
	});
	
	$(".jsDoRejectAccount").click(function(e){
		$(".employeeTab .rowCheckStatus").addClass("rowCheckShow");
		$(".employeeTab .jsCheckStatus").text("Rejected").removeClass("checkApproved").addClass("checkRejected");
		$(".employeeTab .checker").text("John Smith");
		$(".accountBasicInfoPanel").show();
		$(".accountBasicInfoPanelEdit").hide();
		closePopup();
	});
	$(".jsApproveConfirmNewAccountValidity").click(function(e){	
		$(".employeeTab .rowCheckStatus").removeClass("rowCheckShow");
		$(".employeeTab .jsCheckStatus").text("Approved").removeClass("checkRejected").addClass("checkApproved");
		$(".employeeTab .checker").text("John Smith");
		$(".accountBasicInfoPanel").show();
		$(".accountBasicInfoPanelEdit").hide();
	});

	
	//Edit Billing Info
	$(".jsEditBillingInfo").click(function(e){	
		$(".billingSummaryPanel").hide();
		$(".billingSummaryPanelEdit").show();
	});
	$(".jsCancelBillingSummaryEdit, .jsSaveAccountInterestNotePopup ").click(function(e){
		closePopup();
		$(".billingSummaryPanel").show();
		$(".billingSummaryPanelEdit").hide();
	});
	$(".jsSavelBillingSummaryEdit ").click(function(e){	
		showPopup(".changeAccountInterestNotesPopup");	
	});
	

	//Adjust Payment Order
	$("body").delegate(".billingSummaryTab select.pOrder", "change", function(){
		/*
		var tr = $(this).parents("tr").eq(0);
		var tbl = $(this).parents("tbody").eq(0);
		var idx = $(this)[0].selectedIndex;
		var currentIdx = $("tr", tbl).index(tr);
		if (idx >  currentIdx ){
			$("tr", tbl).eq(idx).after(tr);	
		}else if ( idx < currentIdx ){
			$("tr", tbl).eq(idx).before(tr);
		}
		$(".pOrder", tbl).each(function(index, element) {
            var tr = $(this).parents("tr").eq(0);
			var currentIdx = $("tr", tbl).index(tr);
			$(this)[0].selectedIndex = currentIdx;
        });
		$("td:not(.titleCol)", tr).css({
			backgroundColor: "#E09C06"
		}).animate({ backgroundColor: "#ffffff" }, 800);
		*/
	});
	
	//Popups
	$(".jsShowSample").click(function(e){
		if ( ! $(this).hasClass("priBtnDisabled") ){
			showPopup(".sampleInitialPopup");	
		}
	});	
	$(".jsShowCalculation").click(function(e){
		showPopup(".confirmDatePopup");
	});
	$(".jsShowPeriodErrorPopup").click(function(e){
		closePopup();
		showPopup(".periodErrorPopup");
	});	
	$(".jsAddNote").click(function(e){
		closePopup();
		showPopup(".accountNotesAddPopup");
	});	
	$(".jsExpandCalculation ").click(function(e){
		if (!$(this).hasClass("priBtnDisabled")){
			window.open('ExpandCal.html','Calculation','width=1000,height=300,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		}
	});
	$(".jsUpdateInterest").click(function(e){
		closePopup();
		showPopup(".updateInterestPopup");
	});
	$(".jsPHReversePayment").click(function(e){
		closePopup();
		showPopup(".reversePayementPopup");
	});
	$(".jsShowLastUpdateBtn").click(function(e){
		closePopup();
		$(".jsLastUpdate").show();
		$(".jsUpdateInterest").hide();
		showPopup(".updateInterestReportPopup");
	});
	
	$(".jsLastUpdate").click(function(e){;
		closePopup();
		showPopup(".lastUpdatePopup");
	});
	$(".jsShowLastUpdateReport").click(function(e){
		closePopup();
		showPopup(".updateInterestReportPopup");
	});
	
	$(".jsDoAddPHTransaction").click(function(e){
		closePopup();
	});	
	
	$(".notesToFirst").click(function(e){
		if ( ! $(this).hasClass("priBtnDisabled")){
			var popup = $(this).parents(".popup").eq(0);
			$(".notesToFirst", popup).addClass("priBtnDisabled").addClass("notesToFirstDisabled");
			$(".notesToPrev", popup).addClass("priBtnDisabled").addClass("notesToPrevDisabled");
			$(".notesToNext", popup).removeClass("priBtnDisabled").removeClass("notesToNextDisabled");
			$(".notesToLast", popup).removeClass("priBtnDisabled").removeClass("notesToLastDisabled");
		}
	});
	$(".notesToPrev").click(function(e){
		if ( ! $(this).hasClass("priBtnDisabled")){
			var popup = $(this).parents(".popup").eq(0);
			$(".notesToFirst", popup).addClass("priBtnDisabled").addClass("notesToFirstDisabled");
			$(".notesToPrev", popup).addClass("priBtnDisabled").addClass("notesToPrevDisabled");
			$(".notesToNext", popup).removeClass("priBtnDisabled").removeClass("notesToNextDisabled");
			$(".notesToLast", popup).removeClass("priBtnDisabled").removeClass("notesToLastDisabled");
		}
	});
	$(".notesToNext").click(function(e){
		if ( ! $(this).hasClass("priBtnDisabled")){
			var popup = $(this).parents(".popup").eq(0);
			$(".notesToFirst", popup).removeClass("priBtnDisabled").removeClass("notesToFirstDisabled");
			$(".notesToPrev", popup).removeClass("priBtnDisabled").removeClass("notesToPrevDisabled");
			$(".notesToNext", popup).addClass("priBtnDisabled").addClass("notesToNextDisabled");
			$(".notesToLast", popup).addClass("priBtnDisabled").addClass("notesToLastDisabled");
		}
	});
	$(".notesToLast").click(function(e){
		if ( ! $(this).hasClass("priBtnDisabled")){
			var popup = $(this).parents(".popup").eq(0);
			$(".notesToFirst", popup).removeClass("priBtnDisabled").removeClass("notesToFirstDisabled");
			$(".notesToPrev", popup).removeClass("priBtnDisabled").removeClass("notesToPrevDisabled");
			$(".notesToNext", popup).addClass("priBtnDisabled").addClass("notesToNextDisabled");
			$(".notesToLast", popup).addClass("priBtnDisabled").addClass("notesToLastDisabled");
		}
	});
	
	var mockNotes1 = $(".accountNotesPopup .viewNotesArea").html();
	var mockNotes2 = '<p>Interest Change Rejected.<br/>Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum</p>';
	$(".accountNotesPopup .notesToFirst, .accountNotesPopup .notesToPrev").click(function(e){
		$(".accountNotesPopup .viewNotesArea").html(mockNotes1);
	});
	$(".accountNotesPopup .notesToNext, .accountNotesPopup .notesToLast").click(function(e){
		$(".accountNotesPopup .viewNotesArea").html(mockNotes2);
	});
	var mockEditNotes1 = $(".accountNotesEditPopup textarea").html();
	var mockEditNotes2 = 'Interest Change Rejected. Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum';
	
	$(".accountNotesEditPopup .notesToFirst, .accountNotesEditPopup .notesToPrev").click(function(e){
		$(".accountNotesEditPopup textarea").html(mockEditNotes1);
	});
	$(".accountNotesEditPopup .notesToNext, .accountNotesEditPopup .notesToLast").click(function(e){
		$(".accountNotesEditPopup textarea").html(mockEditNotes2);
	});
	
	$(".jsClipboardCopy").click(function(e){
		$(".alpha2").show();
		showPopup(".accountNoteCopyPopup");
	});
	$(".jsClosePopup2").click(function(e){
		$(".alpha2, .popup2").hide();
	});
	$(".jsSaveNotePopup").click(function(e){
		closePopup();
	});
	$("input[name=addPaymentType]").click(function(e){
		var popup = $(this).parents(".popup").eq(0);
		$(".addPaymentNote", popup).hide();
		$(".addPaymentNote_" + $(this).attr("id"), popup).show();
	});
	$(".jsPHDelPayment").click(function(e){
		showPopup(".confirmPaymentDeletionPopup");
	});
	
	$(".jsDoSavePHNote").click(function(e){
		var popupHint = $(this).parents(".popup").eq(0).find(".paymentNoteHint");
		if (  popupHint.text() === "New Note Saved."  ){
			popupHint.text("Existing Note Updated.")
		}else if (  popupHint.text() === "Existing Note Updated."  ){
			popupHint.text("Existing Note Updated.")
		}else{
			popupHint.text("New Note Saved.")		
		}
	});	
	$(".jsPHAuditHistory").click(function(e){
		showPopup(".updateInterestReportPopup");
	});
	
	$("body").delegate(".alphaTrans", "click", function(){
		closePopup();
	});

	//Notes popup textarea resize
	$(".popup .notesRecord textarea" ).resizable({ 
		minWidth: 476, 
		maxWidth: 476,
		minHeight: 172,
		resize: function() {
			var popup = $(this).parents(".popup").eq(0);
			popup.css('display', 'block').css('margin', -popup.height() / 2 + 'px 0 0 ' + (-popup.width() / 2) + 'px');
		}
	}).parent().css({
		"padding": "0 0 1px 0",
		height: 172
	});
		
	//Start Reports Page
	if ( $("#reportsPage").length > 0 ){
		//report page left tree
		if ( $("#leftTree").length > 0 ){
			$("#leftTree").treeview();
			var firstLevelNode = $("#leftTree > li");
			if (firstLevelNode.length === 1){
				firstLevelNode.addClass("onlyNode");
			}
			equalizeReportHeight();
			
			//MOCKUP TREE NODE CLICKING, please remove
			$("#leftTree a").click(function(){
				var href = $(this).attr("href");
				if (href.indexOf(".html") < 0){
					var title = $(".rightReportWrapper h3.reportTitle")
					var text = $(" > .file > .nodeText", $(this)).text();
					title.text(text);
					$("#leftTree a").removeClass("selected");
					$(this).addClass("selected");
				}
			});
		}
		
		//reports page edit button
		$(".jsEditReport").click(function(){
			$(".jsEditReport, .viewReportWrapper").hide();
			$(".jsCancelSaveReport, .jsSaveReport, .editReportWrapper ").show();
			equalizeReportHeight();
		});
		
		//reports page cancel edit button
		$(".jsEditReportSaved ,.jsCancelSaveReport").click(function(e){
			$(".jsCancelSaveReport, .jsSaveReport, .editReportWrapper ").hide();
			$(".jsEditReport, .viewReportWrapper").show();
			equalizeReportHeight();
			closePopup();
		});
		
		//reports page save button
		$(".jsSaveReport").click(function(){
			showPopup(".saveReportSuccessPopup");
		});
		
		//reports page print button
		$(".jsPrintReport").click(function(){
			showPopup(".sampleReportPlaceholderPopup");
		});
		
		//reports page delete button
		$(".jsDelReport").click(function(){
			showPopup(".deleteReportConfirmationPopup");
		});	
		
	}
	//End Reports Page

	//Start Suspense Page
	if ( $("#suspensePage").length > 0 ){
		//init checkbox
		$("tbody input[name='postChkbx']").prop("checked", false);
		$("tbody input[name='postChkbx']").eq(0).prop("disabled", false);
		$("tbody input[name='postChkbx']").eq(1).prop("disabled", false);
		$("tbody input[name='postChkbx']").eq(2).prop("disabled", false);
		$("tbody input[name='postChkbx']").eq(3).prop("disabled", false);
		
		//Suspense Tbl
		$("#suspenseTbl").delegate("td", "mouseenter", function(){
			$(this).parent().addClass("hovered");
		}).delegate("td", "mouseleave", function(){
			$(this).parent().removeClass("hovered");
		});
		
		$("#suspenseTbl tfoot td").click(function(){
			var newRow = $(this).parent().clone();
			newRow.addClass("newRow");
			var tbl = $(this).parents("table").eq(0);
			$("tbody", tbl).append(newRow);
			loadPaymentTransactionDetails(newRow);
			$(".jsMakeThisEmpCur").addClass("priHighBtnDisabled");
			editSuspenseRow(newRow);
			$(".jsLinkPaymentToCurrent, .jsTransferSuspense, .jsLinkPaymentToCurrent").addClass("priHighBtnDisabled");
		});
		
		$("#suspenseTbl").delegate("tbody td", "click", function(){
			var row = $(this).parent();
			if (!($(this).parent().hasClass("editing"))){
				
				var tbl = $(this).parents("table").eq(0);
				if (! row.hasClass("editing")){
					saveSuspenseRow($(".editing", tbl));
				}
				if (row.hasClass("highlighted") && (!$(this).hasClass("checkBoxCell")) ){
					editSuspenseRow(row);
				}else{
					$("#suspenseTbl tr").removeClass("highlighted");
					row.addClass("highlighted");
					loadPaymentTransactionDetails(row);
				}
			}
			if ($("input[name='postChkbx']:disabled", row).is(':disabled')){
				$(".jsResetSelectedPaymentSuspense").removeClass("priBtnDisabled");
			}else{
				$(".jsResetSelectedPaymentSuspense").addClass("priBtnDisabled");
			}
		});

		$("#suspenseTbl").delegate("input[name='postChkbx']", "click", function(){
			var checkBox = $("#suspenseTbl input[name='postChkbx']:checked:enabled");
			if (checkBox.length > 0){
				$(".jsPostCheckedPaymentsSuspense").removeClass("priBtnDisabled");
			}else{
				$(".jsPostCheckedPaymentsSuspense").addClass("priBtnDisabled");
			}
		});
		
		$(".jsTransferSuspense").click(function(){
			if (!($(this).hasClass("priHighBtnDisabled"))){
				showPopup(".transferSuspensePopup");
			}
		});	
		
		$(".jsPrintSuspense").click(function(){
			showPopup(".currentSuspensePrintPopup");
		});	
		
		$(".jsDoPrintCurrentSuspense").click(function(){
			window.open('Suspense_CurrentSuspense_printview.html','SuspenseCurrentSuspense','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});	
	
		$(".jsHistorySuspense").click(function(){
			showPopup(".suspenseHistoryPrintPopup");
		});	
		
		$(".jsDoPrintSuspenseHistory").click(function(){
			window.open('Suspense_History_printview.html','SuspenseHistory','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});	
		
		$(".jsPostCheckedPaymentsSuspense").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				$(this).addClass("priBtnDisabled");
				var checkedBoxs = $("#suspenseTbl tbody input[name='postChkbx']:checked");
				checkedBoxs.each(function(){
					var row = $(this).parents("tr").eq(0);
					$("input[name='postChkbx']", row).prop('checked', false).attr("disabled", true);
					
					var txt= row.find("td").eq(2).text();
					if ( txt.indexOf('Ready for ') > -1 ){
						newTxt = txt.replace('Ready for ', '') + " - Pending Approval";
					}else{
						newTxt = "Posted - Pending Approval";
					}
					row.find("td").eq(2).html(newTxt);
					
				});
				var selectedRow = $("#suspenseTbl tr.highlighted");
				loadPaymentTransactionDetails(selectedRow);
				$(".jsResetSelectedPaymentSuspense").removeClass("priBtnDisabled");
			}
		});
		
		$(".jsResetSelectedPaymentSuspense").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				$(this).addClass("priBtnDisabled");
				var row = $("#suspenseTbl tbody tr.highlighted");
				$("input[name='postChkbx']", row).prop('checked', false).attr("disabled", false);
				row.find("td").eq(2).html("Suspended");
			}
		});
		
		$(".jsLinkPaymentToCurrent").click(function(){
			if (!($(this).hasClass("priHighBtnDisabled"))){
				var selectedRow = $("#suspenseTbl tr.highlighted");
				var cells = selectedRow.find("td");
				cells.eq(2).html("Ready to Link to 1234574");
				cells.eq(5).html("1234574");
				cells.eq(9).html("Robert Taylor");
				cells.eq(10).html("$326.98");
				cells.eq(11).html("Active");
				$("input[name='postChkbx']", selectedRow).prop('checked', true);
				$(".jsPostCheckedPaymentsSuspense").removeClass("priBtnDisabled");
				loadPaymentTransactionDetails(selectedRow);
			}
		});	
		
		$(".jsMakeThisEmpCur").click(function(){
			if (!($(this).hasClass("priHighBtnDisabled"))){
				if ($(".accountPanymentsWrapper input[name='csdNum']").hasClass("error")){
					showPopup(".invalidCSDPopup");
				}else{
					var scmName = $(".accountPanymentsWrapper input[name='scmName']").val();
					
					if (scmName ==="Patricia Maupin"){
						var currName = "Patricia Maupin";
						var currCSD = "1234572";
						var currDOB = "3/9/1970";
						var currSSN = "499-44-6423";
						var currLastAction = "Changes";
						var currLastActionDate = "2/6/2013";
						var currPayNum = "2";
						var currPayAmout = "$200.00";
						var currBalance = "$2,393.14";
					}else{
						var currName = "Robert Taylor";
						var currCSD = "1234574";
						var currDOB = "12/18/1956";
						var currSSN = "383-72-0234";
						var currLastAction = "New receipt through St. Louis (6)";
						var currLastActionDate = "1/6/2013";
						var currPayNum = "5";
						var currPayAmout = "$2,500.00";
						var currBalance = "$326.98";
					}
					$(".suspensePanel .accountSummaryPanel .column1 h4").text(currName);
					$(".suspensePanel .accountSummaryPanel .column1 .fieldRow").eq(0).find(".fieldVal").text(currCSD);
					$(".suspensePanel .accountSummaryPanel .column1 .fieldRow").eq(1).find(".fieldVal").text(currDOB);
					$(".suspensePanel .accountSummaryPanel .column1 .fieldRow").eq(2).find(".fieldVal").text(currSSN);
					$(".suspensePanel .accountSummaryPanel .column2 .fieldRow").eq(1).find(".fieldVal").text(currLastAction);
					$(".suspensePanel .accountSummaryPanel .column2 .fieldRow").eq(2).find(".fieldVal").text(currLastActionDate);
					$(".suspensePanel .accountSummaryPanel .column3 h4 span").text(currPayNum);
					$(".suspensePanel .accountSummaryPanel .column3 .fieldRow").eq(0).find(".fieldVal").text(currPayAmout);
					$(".suspensePanel .accountSummaryPanel .column3 .fieldRow").eq(1).find(".fieldVal").text(currBalance);
				}
			}
		});	
		
		$(".jsDoTransferSuspense").click(function(){
			var tpType = $("input[name='tpType']:checked").val();
			if ( tpType === "tpType1"){
				closePopup();
				showPopup(".refundCreditBalancePopup");
			}else{
				closePopup();
				var tpTypeTxt = $(".transferSuspensePopup input[name='tpType']:checked").next("label").text();
				$("#suspenseTbl tbody tr.highlighted td").eq(2).text("Ready for " + tpTypeTxt);
				$("#suspenseTbl tbody tr.highlighted input[name='postChkbx']").prop("checked", true);
				$(".jsPostCheckedPaymentsSuspense").removeClass("priBtnDisabled");
				if ( tpType !== "tpType4"){
					alert("This action will normally open Microsoft Word, and display a document. For purposes of the wireframes, this is just a placeholder.");
				}
			}
		});
		
		$(".jsAlertOpenDoc").click(function(e){
			closePopup();
			var tpType = $(".transferSuspensePopup input[name='tpType']:checked").next("label").text();
			$("#suspenseTbl tbody tr.highlighted td").eq(2).text("Ready for " + tpType);
			$("#suspenseTbl tbody tr.highlighted input[name='postChkbx']").prop("checked", true);
			$(".jsPostCheckedPaymentsSuspense").removeClass("priBtnDisabled");
			alert("This action will normally open Microsoft Word, and display a document. For purposes of the wireframes, this is just a placeholder.");
		});
		
		$( ".paymentNotes" ).resizable({ 
			minWidth: 239, 
			maxWidth: 239,
			minHeight: 237,
			resize: function() {
				var rHeight = $(".rightBox .boxInner").height();
				$(".leftBox .boxInner").height(rHeight);
			}
		}).parent().css("padding", "1");
	
		$(".jsSaveNoteSuspense").click(function(e){
			showPopup(".savePaymentNotesSuccessPopup");
		});
		
		$(".jsDiscardNoteChangesSuspense").click(function(){
			var form = $(this).parents("form").eq(0);
			var resetBtn = $("input[type='reset']", form);
			resetBtn.click();
			$("textarea", form).focus().blur();
		});	
	
	}
	//End Suspense Page

	//Start Approval Page
	if ( $("#approvalPage").length > 0){
		
		//Pending Payments
		$(".jsPendingPaymentsViewAuditTrail").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".apViewAuditTrailPopup");
			}
		});	
		
		$(".jsDoPrintAPAuditTrail").click(function(){
			window.open('ApprovalPendingPayments_ViewAuditTrail_printview.html','ViewAuditTrail','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});	
		
		$(".jsPendingPaymentsApproveSelected").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".approveSeletedSuccessPopup");
			}
		});	
		
		$(".jsPendingPaymentsDisapproveSelected").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".pendingPaymentDisapprovePopup");
			}
		});
		
		$(".jsDoDisapprovePendingPayment").click(function(){
			closePopup();
			showPopup(".disapproveSeletedSuccessPopup");
		});

		//Interest Adjustments
		$(".jsInterestAdjustmentViewAuditTrail").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".iaViewAuditTrailPopup");
			}
		});	
		
		$(".jsDoPrintIAAuditTrail").click(function(){
			window.open('ApprovalInterestAdjustments_ViewAuditTrail_printview.html','ViewAuditTrail','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});
		
		$(".jsInterestAdjustmentDisapproveSelected").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".interestAdjustmentsDisapprovePopup");
			}
		});	

		//Payment Moves
		$(".jsPaymentMovesViewAuditTrail").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".pmViewAuditTrailPopup");
			}
		});	
		
		$(".jsDoPrintPMAuditTrail").click(function(){
			window.open('ApprovalPaymentMoves_ViewAuditTrail_printview.html','ViewAuditTrail','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});	
		
		$(".jsPaymentMovesDisapproveSelected").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".paymentMovesDisapprovePopup");
			}
		});	
	
		$( ".csdNoteArea textarea" ).resizable({ 
			minWidth: 913, 
			maxWidth: 913,
			minHeight: 107
		}).parent().css({
			"padding": "0 0 1px 0",
			height: 107
		});
		
		$(".jsCSDNoteSave").click(function(e){
			showPopup(".savePaymentNotesSuccessPopup");
		});
		
		$(".jsDiscardCSDNoteChanges").click(function(){
			var form = $(this).parents("form").eq(0);
			var resetBtn = $("input[type='reset']", form);
			resetBtn.click();
			$("textarea", form).focus().blur();
		});	
		
		//Approval Tbl
		$(".approvalTab .sortable").delegate("td", "mouseenter", function(){
			$(this).parent().addClass("hovered");
		}).delegate("td", "mouseleave", function(){
			$(this).parent().removeClass("hovered");
		}).delegate("tbody td", "click", function(){
				var row = $(this).parent();
				var tbl = $(this).parents("table").eq(0);
				$(".approvalTab .sortable tr").removeClass("highlighted");
				row.addClass("highlighted");
				var csdNum = $("td.csdNum", row).text();
				$(".approvalPageBtnWrapper .pendingVATBtn").removeClass("priBtnDisabled");
				$(".csdNoteArea").removeClass("csdNoteAareaNoSelection");
				$(".csdNoteArea .noteAreaTitle strong").text("CSD " + csdNum);
				
		});
		
		$(".approvalTab .sortable").delegate("input[name='pendingTblCheckbox']", "click", function(){
			var tbl = $(this).parents("table").eq(0);
			var checkBox = $("input[name='pendingTblCheckbox']:checked:enabled", tbl);
			if (checkBox.length > 0){
				$(".approvalPageBtnWrapper .pendingApproveBtn").removeClass("priBtnDisabled");
				$(".approvalPageBtnWrapper .pendingDisapproveBtn").removeClass("priBtnDisabled");
			}else{
				$(".approvalPageBtnWrapper .pendingApproveBtn").addClass("priBtnDisabled");
				$(".approvalPageBtnWrapper .pendingDisapproveBtn").addClass("priBtnDisabled");
			}
		});
		
		//Init Approval table filter
		if ( $("#interestAdjustementTbl, #paymentMovesTbl").length > 0){
			filterApprovalRecords();
		}

		$(".jsInterestAdjustmentApproveSelected, .jsPaymentMovesApproveSelected").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				var checkBox = $("input[name='pendingTblCheckbox']:checked");
				checkBox.each(function() {
                    var row = $(this).parents("tr").eq(0);
					row.removeClass("UnapprovedRow").addClass("ApprovedRow").hide();
					$(this).remove();
                });
				if ($(".approvalTab .sortable tbody tr:visible").length < 1){
					$(".approvalTab .tblWrapper").addClass("noApprovalRecords"); 
				}else{
					$(".approvalTab .tblWrapper").removeClass("noApprovalRecords"); 
				}
				if ($(".approvalTab .sortable tbody tr.highlighted:visible").length < 1){
					$(".csdNoteArea").addClass("csdNoteAareaNoSelection");
					$(".approvalPageBtnWrapper .priBtn").addClass("priBtnDisabled");
				}
				
				var leftCount = $(".approvalTab .sortable tbody tr.UnapprovedRow").length;
				var tabNotiNum = $(".approvalTab .tabsBar .current .notificationNum span span");
				tabNotiNum.text(leftCount);
				if (leftCount === 0){
					$(".approvalTab .tabsBar .current .notificationNum").hide();
				}
				
			}
		});	
		
		$(".jsDoDisapproveInterestAdjustment, .jsDoDisapprovePaymentMove").click(function(){
			var checkBox = $("input[name='pendingTblCheckbox']:checked");
			checkBox.each(function() {
				var row = $(this).parents("tr").eq(0);
				row.removeClass("UnapprovedRow").addClass("DisapprovedRow").hide();
				$(this).remove();
			});
			if ($(".approvalTab .sortable tbody tr:visible").length < 1){
				$(".approvalTab .tblWrapper").addClass("noApprovalRecords"); 
			}else{
				$(".approvalTab .tblWrapper").removeClass("noApprovalRecords"); 
			}
			if ($(".approvalTab .sortable tbody tr.highlighted:visible").length < 1){
				$(".csdNoteArea").addClass("csdNoteAareaNoSelection");
				$(".approvalPageBtnWrapper .priBtn").addClass("priBtnDisabled");
			}
			var leftCount = $(".approvalTab .sortable tbody tr.UnapprovedRow").length;
			var tabNotiNum = $(".approvalTab .tabsBar .current .notificationNum span span");
			tabNotiNum.text(leftCount);
			if (leftCount === 0){
				$(".approvalTab .tabsBar .current .notificationNum").hide();
			}
			closePopup();
		});	
		

	}
	//End Approval Page

	//Start Payments Page
	if ( $("#paymentsPage").length > 0){
		$("#paymentSearchResultsTbl tbody td").click(function(){
			var row = $(this).parent();
			$("#paymentSearchResultsTbl tbody tr").removeClass("highlighted");
			row.addClass("highlighted");
			$(".paymentSearchResultsBtnWrapper .priBtn").removeClass("priBtnDisabled");
			
		});
		
		$("#paymentSearchResultsTbl").delegate("td", "mouseenter", function(){
			$(this).parent().addClass("hovered");
		}).delegate("td", "mouseleave", function(){
			$(this).parent().removeClass("hovered");
		});
		
		$(".paymentSearchBox  select").each(function(index, element) {
			$(this)[0].selectedIndex = 0;
		});
		$(".jsSearchPayment").click(function(){
			$(".paymentSearchResultsWrapper > div").show();
		});
		$(".jsShowAuditTrail").click(function(){
			if (!($(this).hasClass("priBtnDisabled"))){
				showPopup(".sampleReportPlaceholderPopup");
			}
		});
		$(".paymentSearchBox input#startDate").datepicker({
			showOn: "button",
			buttonImage: "i/calendar.png",
			buttonImageOnly: true,
			changeMonth: true,
			changeYear: true,yearRange: "-100:+1",
			onClose: function( selectedDate ) {
				$(".paymentSearchBox input#endDate").datepicker( "option", "minDate", selectedDate );
			},
			onSelect: function(){
				$(this).removeClass("error");	
			}
		});
		$(".paymentSearchBox input#endDate").datepicker({
			showOn: "button",
			buttonImage: "i/calendar.png",
			buttonImageOnly: true,
			changeMonth: true,
			changeYear: true,yearRange: "-100:+1",
			onClose: function( selectedDate ) {
				$(".paymentSearchBox input#startDate").datepicker( "option", "maxDate", selectedDate );
			},
			onSelect: function(){
				$(this).removeClass("error");	
			}
		});
	}
	//End Payments Page



	//Start Tools Page
	if ( $("#toolsPage").length > 0){
		$(".jsSavePreference").click(function(){
			showPopup(".savePreferenceSuccessPopup");
		});
		
		$(".jsResetPreference").click(function(){
			var form = $(this).parents("form").eq(0);
			var resetBtn = $("input[type='reset']", form);
			resetBtn.click();
		});	

		$(".jsCancelPreference").click(function(){
			showPopup(".cancelPreferenceChangesPopup");
		});
		
		$(".jsShowInitStatement").click(function(){
			showPopup(".initStatementPopup");
		});
		$(".jsDoPrintSampleInitialStatement").click(function(){
			window.open('Tools_PrintingTools_ShowSampleInitialStatement_printview.html','SampleInitialStatement','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});

		$(".jsPrintChargeCard").click(function(){
			showPopup(".chargeCardPopup");
		});
		$(".jsDoPrintChargeCard").click(function(){
			window.open('Tools_PrintingTools_ChargeCard_printview.html','ChargeCard','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});

		$("#batchPrintoutArchiveTbl").delegate("tbody td", "mouseenter", function(){
			$(this).parent().addClass("hovered");
		}).delegate("tbody td", "mouseleave", function(){
			$(this).parent().removeClass("hovered");
		}).delegate("tbody td", "click", function(){
			alert("This action will normally open PDF Reader, and display a document. For purposes of the prototype, this is just a placeholder.");
		});
	}
	//End Tools Page

	//Start Admin Page
	if ( $("#adminPage").length > 0){
		
		
		$(".jsRegeneratePaymentInvoices").click(function(){
			showPopup(".paymentInvoicesPopup");
		});
		$(".jsDoPrintPaymentInvoices").click(function(){
			window.open('Admin_RegenerateLatestReports_PaymentInvoices_printview.html','PaymentInvoices','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});
		
		$(".jsRegenerateInitialBillInvoices").click(function(){
			showPopup(".initialBillInvoicesPopup");
		});
		$(".jsDoPrintInitialBillInvoices").click(function(){
			window.open('Admin_RegenerateLatestReports_InitialBillInvoices_printview.html','InitialBillInvoices','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});

		$(".jsRegenerateReversalInvoices").click(function(){
			showPopup(".reversalInvoicesPopup");
		});
		$(".jsDoPrintReversalInvoices").click(function(){
			window.open('Admin_RegenerateLatestReports_ReversalInvoices_printview.html','ReversalInvoices','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});
		
		$(".jsRegenerateStopACHLetters").click(function(){
			showPopup(".stopACHPopup");
		});
		$(".jsDoPrintStopACHLetters").click(function(){
			window.open('Admin_RegenerateLatestReports_StopACHLetters_printview.html','StopACHLetters','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});

		$(".jsRegenerateRefundMemos").click(function(){
			showPopup(".refundMemosPopup");
		});
		$(".jsDoPrintRefundMemos").click(function(){
			window.open('Admin_RegenerateLatestReports_RefundMemo_printview.html','RefundMemo','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});

		$("#userPermissionsTbl").delegate("tbody td", "mouseenter", function(){
			$(this).parent().addClass("hovered");
		}).delegate("tbody td", "mouseleave", function(){
			$(this).parent().removeClass("hovered");
		}).delegate("tbody td", "click", function(){
			if (($(this).parent().hasClass("highlighted"))){
				return false;
			}else{
				$("#userPermissionsTbl tr").removeClass("highlighted");
				var row = $(this).parent();
				row.addClass("highlighted");
			}
			return false;
		}).delegate("tbody td", "dblclick", function(){
			$("#userPermissionsTbl tr").removeClass("highlighted");
			var row = $(this).parent();
			row.addClass("highlighted");
			showPopup(".editUserPermissionsPopup");
			return false;
		});
		
		$(".jsSaveUserPermission").click(function(){
			closePopup();
		});
		
		$(".jsPrintHoliday").click(function(){
			showPopup(".adminHolidayPrintPopup");
		});
		$(".jsDoPrintAdminHolidays").click(function(){
			window.open('Admin_Holidays_printview.html','HOLIDAYS','width=940,height=500,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=0,top=0');
			return false;
		});
		
		

	}
	//End Admin Page

	//Start Notification Log Page
	if ( $("#notiLogPage").length > 0){
		$(".jsPrintNoti").click(function(){
			showPopup(".reportPlaceHolderPopup");
		});
	}
	//End Notification Log Page

});
//Filter recoreds for Approval pages.
function filterApprovalRecords(){
	var currFilter = $(".approvalTab select.viewFilter").val();
	$(".approvalTab .sortable tbody tr, .approvalTab .sortable tbody tr td").hide()
	$(".approvalTab .sortable tbody tr." + currFilter + "Row, .approvalTab .sortable tbody tr." + currFilter + "Row td").show()
	$(".approvalTab .sortable tbody tr").removeClass("highlighted");
	$(".approvalTab .sortable tbody input").prop("checked", false);
	$(".approvalTab .tblWrapper").removeClass("noApprovalRecords"); 
	$(".csdNoteArea").addClass("csdNoteAareaNoSelection");
	if (currFilter === "Unapproved"){
		$(".jsInterestAdjustmentDisapproveSelected, .jsInterestAdjustmentApproveSelected, .jsPaymentMovesApproveSelected, .jsPaymentMovesDisapproveSelected").show();
		$(".approvalTab .sortable thead .checkBoxCol, .approvalTab .sortable tbody tr:visible .checkBoxCell").css("display", "table-cell");
		if ($(".approvalTab .sortable colgroup col.col1").length < 1){
			$(".approvalTab .sortable colgroup col.blankCol").after("<col class='col1'>");
		}
		
	}else{
		$(".jsInterestAdjustmentDisapproveSelected, .jsInterestAdjustmentApproveSelected, .jsPaymentMovesApproveSelected, .jsPaymentMovesDisapproveSelected").hide();
		$(".approvalTab .sortable thead .checkBoxCol, .approvalTab .sortable tbody .checkBoxCell").css("display", "none");
		$(".approvalTab .sortable colgroup col.col1").remove();
	}
	$(".approvalPageBtnWrapper .priBtn").addClass("priBtnDisabled");
	if ($(".approvalTab .sortable tbody tr:visible").length < 1){
		$(".approvalTab .tblWrapper").addClass("noApprovalRecords"); 
	}else{
		$(".approvalTab .tblWrapper").removeClass("noApprovalRecords"); 
	}
	
	
}

//Change amount type of deposite field on payment search
function changeAmountType(obj){
	checkValue=$(obj).val();
	var searchBox = $(obj).parents(".paymentSearchBox").eq(0);
	if (checkValue === "any"){
		$(".amountInput ", searchBox).addClass("fieldDisabled");
	}else{
		$(".amountInput ", searchBox).removeClass("fieldDisabled");
	}
}

//Change deposited date type of deposite field on payment search
function changeDepositedDate(obj){
	checkValue=$(obj).val();
	var filedRow = $(obj).parents(".fieldRow").eq(0);
	if (checkValue === "between"){
		$(".singleDate", filedRow).addClass("isHidden");
		$(".betweenDate", filedRow).removeClass("isHidden");
	}else{
		$(".singleDate", filedRow).removeClass("fieldDisabled")
		$(".singleDate", filedRow).removeClass("isHidden");
		$(".betweenDate", filedRow).addClass("isHidden");
		if(checkValue === "any"){
			$(".singleDate", filedRow).addClass("fieldDisabled")
		}
	}
	if ((obj.selectedIndex === 1)||(obj.selectedIndex === 2)||(obj.selectedIndex === 3)||(obj.selectedIndex === 4)||(obj.selectedIndex === 5)){
		filedRow.addClass("longSelect");
	}else{
		filedRow.removeClass("longSelect");
	}
}

function loadPaymentTransactionDetails(row){
	var cells = $(row).find("td");
	var pStatus = cells.eq(2).text();
	var tDate = cells.eq(3).text();
	var batBlkSeq = cells.eq(4).text();
	var tmp = batBlkSeq.split("-");
	var bat = tmp[0];
	var blk = tmp[1];
	var seq = tmp[2];
	var csd = cells.eq(5).text();
	var pAmount = cells.eq(7).text();
	var bDate = cells.eq(8).text();
	var scmName = cells.eq(9).text();
	var bAmount = cells.eq(10).text();
	var aStatus = cells.eq(11).text();
	if (scmName === ""){
		var scmbDate = "";
		var scmcsdNum = "";
	}else{
		var scmcsdNum = "1234572";
		var scmbDate = "3/9/1970";
	}
	$(".accountPanymentsWrapper input[name='batchNum']").val(bat);
	$(".accountPanymentsWrapper input[name='blockNum']").val(blk);
	$(".accountPanymentsWrapper input[name='seqNum']").val(seq);
	$(".accountPanymentsWrapper input[name='csdNum']").val(csd);
	$(".accountPanymentsWrapper input[name='bDate']").val(bDate);
	$(".accountPanymentsWrapper input[name='pStatus']").val(pStatus);
	$(".accountPanymentsWrapper input[name='pAmount']").val(pAmount);
	$(".accountPanymentsWrapper input[name='tDate']").val(tDate);
	$(".accountPanymentsWrapper input[name='scmName']").val(scmName);
	$(".accountPanymentsWrapper input[name='scmcsdNum']").val(scmcsdNum);
	$(".accountPanymentsWrapper input[name='scmbDate']").val(scmbDate);
	$(".accountPanymentsWrapper input[name='scmStatus']").val(aStatus);
	$(".accountPanymentsWrapper input[name='maBalance']").val(bAmount);
	
	$(".accountPanymentsWrapper input[name='csdNum']").removeClass("error");
	$(".accountPanymentsWrapper input[name='bDate']").removeClass("error");	
	$(".accountPanymentsWrapper .errorIcon").remove();	
	if ( cells.eq(5).hasClass("hasError")){
		$(".accountPanymentsWrapper input[name='csdNum']").addClass("error").after('<span class="errorIcon"></span>');
	}
	if ( cells.eq(8).hasClass("hasError")){
		$(".accountPanymentsWrapper input[name='bDate']").addClass("error").after('<span class="errorIcon"></span>');
	}
	
	$(".accountPanymentsWrapper .boxBtnWrapper .priHighBtn").removeClass("priHighBtnDisabled");
	if ( pStatus.indexOf('Pending Approval') > -1 ){
		$(".jsTransferSuspense, .jsLinkPaymentToCurrent").addClass("priHighBtnDisabled");
	}
	if  ( pStatus === "" ){
		$(".jsLinkPaymentToCurrent, .jsMakeThisEmpCur, .jsTransferSuspense").addClass("priHighBtnDisabled");
	}
	
}

//Save Suspense Row
function saveSuspenseRow(row){
	$("td", row).each(function() {
		if (row.hasClass("newRow")){
			var cells = row.find("td");
			cells.eq(2).html("Unresolved");
			cells.eq(3).html("01/06/2013");
			cells.eq(4).html("183-51-62");
			cells.eq(5).html("8888888");
			cells.eq(7).html("$250.00");
			cells.eq(8).html("08/30/1987");
			cells.eq(9).html("");
			cells.eq(10).html("$0.00");
			cells.eq(11).html("");
			row.removeClass("newRow");
			$("input[type='checkbox']", row).attr("disabled", false);
			$(".jsPostCheckedPaymentsSuspense").removeClass("priBtnDisabled");
		}else{
			if ((!$(this).hasClass("checkBoxCell")) && (!$(this).hasClass("blankCell"))){
				var cellVal = $("input.text", $(this)).val();
				$(this).html(cellVal);
			}
		}
    });
	row.removeClass("editing");
}

//Edit Suspense Row
function editSuspenseRow(row){
	var tbl = row.parents("table").eq(0);
	$("tr", tbl).removeClass("highlighted").removeClass("hovered");;
	var currentEditingRow = tbl.find(".editing");
	saveSuspenseRow(currentEditingRow);
	row.addClass("editing");
	$("td", row).each(function() {
		var w = parseInt($(this).width(), 10) -16;
        if ((!$(this).hasClass("checkBoxCell")) && (!$(this).hasClass("blankCell"))){
			var cellVal = $(this).text();
			if ($(this).hasClass("dateCell")){
				$(this).html('<input type="text" value="' + cellVal + '" class="text datePicker" style="width:' + (w-6) +  'px"/>');
			}else{
				$(this).html('<input type="text" value="' + cellVal + '" class="text" style="width:' + w +  'px"/>');
			}
		}
    });
	if (row.hasClass("newRow")){
		$("input[type='checkbox']", row).prop('checked', true).attr("disabled", true);	
	}
	$(".datePicker", row).datepicker({
		showOn: "button",
		buttonImage: "i/calendar.png",
		changeMonth: true,
		changeYear: true,yearRange: "-100:+1",
		buttonImageOnly: true,
		onSelect: function(){
			$(this).removeClass("error");	
		}
	});
}
//Report page equalize height
function equalizeReportHeight(){
	if ( $("#leftTree").length > 0 ){
		var rightHeight = parseInt($(".rightReportWrapper").height(), 10);
		$(".leftTreeWrapper").css({
			"min-height": (rightHeight - 24)
		});
	}
}

//Position No Validation Mask
function positionNoValidMask(){
	$(".noValidMask:visible").each(function(index, element) {
        var mask = $(this);
		var target = $(this).prev("div");
		var p = target.position();
		mask.css({
			left: p.left,
			top: p.top,
			height: target.height()
		});
    });
	
}

// popup
/**
 * show popup
 * selector - the jQuery selector of the popup
 */
function showPopup(selector) {
	var popup = $(selector);
	$('.alpha').css('display', 'block');
	var winHeight = parseInt($(window).height(),10);
	if ($(".printScrollArea", popup).length > 0){
		$(".printScrollArea", popup).css({
			maxHeight: (winHeight - 100)
		});
	}
	popup.css('display', 'block').css('margin', -popup.height() / 2 + 'px 0 0 ' + (-popup.width() / 2) + 'px');
};
function closePopup() {
	$('.alpha').css('display', 'none').removeClass("alphaTrans");
	$('.popup').css('display', 'none');
};
/**
 * show Notification Popup
 * selector - the jQuery selector of the popup
 */
function showNoti(selector) {
	var popup = $(selector);
	$('.alpha').css('display', 'block').addClass("alphaTrans");
	popup.css('display', 'block');
	positionNoti();
};
function positionNoti(){
	var popup = $(".notificationPopup");
	var target = $(".headerUserInfo .jsShowNotifications");
	var offset = target.offset();
	var h = parseInt(popup.height(), 10);
	var w = parseInt(popup.width(), 10);
	var tw = parseInt(target.width(), 10);
	popup.css('display', 'block').css({
		position: "absolute",
		top: ((parseInt(offset.top, 10) + 27) + 'px'),
		left:  ((parseInt(offset.left, 10) - w + 3 + tw ) + 'px')
	});
	$(".popupArrow", popup).css('display', 'block').css({
		position: "absolute",
		right: ((tw - 13) + 'px')
	});
}

//Show Tooltips
//@param str:
//	Tooltips string
//@target
//  Tooltips target object
function showTooltips(str, target){
	$(".toolTips").remove();	
	var offset = $(target).offset();
	var bd = $("body");
	bd.append("<div class='toolTips'>"+str+"<i></i></div>");
	var toolTips = $(".toolTips").eq(0);
	var h = toolTips.height();
	var w = toolTips.width();
	toolTips.css('top', (offset.top - h - 36) + 'px').css('left', (offset.left - w ) + 'px');
}
function hideTooltips(){
	$(".toolTips").remove();	
}


//Validate Date
function isDate(dateStr) {
	var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
	var matchArray = dateStr.match(datePat); // is the format ok?

	//Check format
	if (matchArray == null) {
		//alert("Please enter MM/DD/YYYY numbers correctly");
		return false;
	}
	
	// p@rse date into variables
	month = matchArray[1]; 
	day = matchArray[3];
	year = matchArray[5];
	
	// check month range
	if (month < 1 || month > 12) { 
		alert("Month must be between 1 and 12.");
		return false;
	}
	
	// check day range
	if (day < 1 || day > 31) {
		alert("Day must be between 1 and 31.");
		return false;
	}

	// check if month have 31 days
	if ((month==4 || month==6 || month==9 || month==11) && day==31) {
		alert("Month "+month+" doesn`t have 31 days!")
		return false;
	}

	//check how much days for February of the year
	if (month == 2) {
		var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
		if (day > 29 || (day==29 && !isleap)) {
			alert("February " + year + " doesn`t have " + day + " days!");
			return false;
		}
	}
	
	// date is valid
	return true; 
}

//Show pagination Dot
function showPaginationDot(wrapper){
	var pageLinks = $(".jsGoPage", wrapper);
	$("span.fLeft", wrapper).remove();
	pageLinks.hide();
	totalCount = pageLinks.length;
	pageLinks.eq(0).show();
	pageLinks.eq(1).show();
	pageLinks.eq(2).show();
	pageLinks.eq(totalCount-1).show();
	pageLinks.eq(totalCount-2).show();
	pageLinks.eq(totalCount-3).show();
	var currentPage = parseInt($(".currentPage", wrapper).eq(0).text(), 10);
	if ((currentPage > 2)&&( currentPage < (totalCount- 1) )){
		pageLinks.eq(currentPage-1).show();
		pageLinks.eq(currentPage-2).show();
		pageLinks.eq(currentPage).show();
	}
	
	if ((currentPage < 3)&& (totalCount > 6)){
		pageLinks.eq(2).after('<span class="fLeft">...</span>');
	}
	if ((currentPage >= 3)&& (currentPage <= 5) && (totalCount > 8)){
		pageLinks.eq(currentPage).after('<span class="fLeft">...</span>');
	}
	if (currentPage > 5){
		pageLinks.eq(2).after('<span class="fLeft">...</span>');
		if ( (totalCount > 10) && ( currentPage < totalCount  - 4 )){
			pageLinks.eq(currentPage).after('<span class="fLeft">...</span>');
		}
	}
}


//input zipcode only 
function validateZipInput(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
	if (charCode == 45){
		return true;
	}
    return !(charCode > 31 && (charCode < 48 || charCode > 57 ));
}

//input phone only 
function validatePhoneInput(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
	if (charCode == 40 || charCode == 41 || charCode == 43 || charCode == 45){
		return true;
	}
    return !(charCode > 31 && (charCode < 48 || charCode > 57 ));
}

//clear text selection
function clearSelection() {
  var sel ;
  if(document.selection && document.selection.empty){
    document.selection.empty() ;
  } else if(window.getSelection) {
    sel=window.getSelection();
    if(sel && sel.removeAllRanges)
      sel.removeAllRanges() ;
  }
}

//cookies
function setCookie(name,value){
    var exp  = new Date();  
    exp.setTime(exp.getTime() + 30*24*60*60*1000);
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}
function getCookie(name){
    var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
     if(arr != null) return unescape(arr[2]); return null;
}
function delCookie(name){
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval=getCookie(name);
    if(cval!=null) document.cookie= name + "="+cval+";expires="+exp.toGMTString();
}
function hidePagination(jqObj){
	var pWrapper = jqObj.parent();
	$(".toPage", pWrapper).show();
	$(".hidePage", pWrapper).remove();
	var currentNum = parseInt(jqObj.text(), 10);
	$(".toPage", pWrapper).each(function(){
		var pNum = parseInt($(this).text(), 10);
		if ( (( pNum - currentNum) > 5) || (( currentNum - pNum) > 5)){
			$(this).hide();
		}
		if ( (( pNum - currentNum) > 5) || (( currentNum - pNum) > 5)){
			$(this).hide();
		}
	});
	if ($(".toPage:visible", pWrapper).eq(0).text() !== "1"){
		$(".toPage:visible", pWrapper).eq(0).before("<span class='hidePage'>...</span>");
	}
	var idx1 = parseInt($(".toPage:visible", pWrapper).length, 10) - 1 ;
	var idx2 = parseInt($(".toPage", pWrapper).length, 10) - 1 ;
	if (($(".toPage:visible", pWrapper).eq(idx1).text()) !== ($(".toPage", pWrapper).eq(idx2).text())){
		$(".toPage:visible", pWrapper).eq(idx1).after("<span class='hidePage'>...</span>");
	}
	
}

//Padding Month/Day 
function padding(value, length) {
	var paddingCount = length - String(value).length;
	for(var i = 0; i < paddingCount; i++) {
		value = '0' + value;
	}
	return value;
}

//check required fields of country
function checkRequiredFields(obj){
	var selectedCountry = $("option:selected", $(obj)).text();
	var wrapper = $(obj).parents(".halfRowField").eq(0).parent();
	var cityRow = $("input[name='city']").parents(".halfRowField").eq(0);
	var stateRow = $("select[name='state']").parents(".halfRowField").eq(0);
	var zipRow = $("input[name='zipCode']").parents(".halfRowField").eq(0);
	if (selectedCountry != "United States"){
		$(".error", cityRow).removeClass("error");
		$(".error", zipRow).removeClass("error");
		$(".errorIcon", cityRow).hide();
		$(".errorIcon", zipRow).hide();
		$(".reqMark", cityRow).addClass("isHidden");
		$(".reqMark", stateRow).addClass("isHidden");
		$(".reqMark", zipRow).addClass("isHidden");
	}else{
		$(".reqMark", cityRow).removeClass("isHidden");
		$(".reqMark", stateRow).removeClass("isHidden");
		$(".reqMark", zipRow).removeClass("isHidden");
	}
	
	
}
