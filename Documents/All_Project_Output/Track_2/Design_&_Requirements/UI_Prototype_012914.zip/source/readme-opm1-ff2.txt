4 - CreateNewAccount_ServiceHistory.html:
change the option in the "Calculation Version" select box,the table below should be changed.
====================================================
not fixed. Copilot can confirm.


The data in the "FERS Deposit" table is complicated, it is difficult to set several groups of data in prototype to mockup data switch when change "Calculation Version".
I will leave here not fixed. I am sure there will be no problem here for next assemble phase, because in next phase here will retrieve real data.

Please leave this issue to approval phase, thanks.