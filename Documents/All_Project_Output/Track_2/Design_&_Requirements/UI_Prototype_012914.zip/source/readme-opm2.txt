1. Using JQuery plugin jquery.treeview.js, licensed under the MIT and GPL licenses

2. In Report - Reference page, please click "Calculation Explanation" link to see "Reference Documents" screen for regular user.

3. For suspense page, first row should be highlighted by default.
For approval page, no rows should be highlighed by default.
Buttons should be disabled if no it requires row highlighted, or checkbox checked.
Disabled button style should be consistent, follow existing prototype.

Please see forum for all latest updates.

4. Blow is PNG/HTML file mapping list:

Reports_Library.html
>03_01_Reports.png
>03_02_Reports_edit.png

Reports_DailyReconciliationReport.html
>03_03_Reports.png
>03_04_Reports.png

Reports_Correspondence.html
>03_05_Reports.png

Reports_Reference.html
>03_06_Reports.png

Reports_CalculationExplanation_Regularuser.html
>03_07_Reports_regularuser.png

Suspense.html
>04_01_Suspense_Currently_Selected.png
>04_02_Suspense_Currently_Selected_double_click_into_Edit.png
>04_03_Suspense_Transfer_Payment_workflow_1.png
>04_04_Suspense_Transfer_Payment_workflow_2.png
>04_05_Suspense_Print_1.png
>04_05_Suspense_Print_2.png
>04_06_Suspense_History.png

Suspense_CurrentSuspense_printview.html
>04_05_Suspense_Print_printview.png

Suspense_History_printview.html
>04_06_Suspense_History_printview.png

ApprovalPaymentMoves.html
>05_01_Approval_Disapprove_Selected.png
>05_03_Approval_no_Payments_to_Approve.png
>05_04_Approval_Payment_Moves_tab.png
>05_04_Approval_Payment_Moves_tab_ViewAuditTrial.png

ApprovalPaymentMoves_ViewAuditTrail_printview.html
>05_04_Approval_Payment_Moves_tab_ViewAuditTrial_printview.png

ApprovalInterestAdjustments.html
>05_02_Approval_Interest_Adjustments_tab.png
>05_02_Approval_Interest_Adjustments_tab_ViewAuditTrail_1.png
>05_02_Approval_Interest_Adjustments_tab_ViewAuditTrail_2.png

ApprovalInterestAdjustments_ViewAuditTrail_printview.html
>05_02_Approval_Interest_Adjustments_tab_ViewAuditTrail_printview.png

ApprovalPendingPayments.html
>05_06_Approval_Pending_Payments_tab.png
>05_07_Approval_Pending_Payments_tab_ViewAuditTrail_1.png
>05_07_Approval_Pending_Payments_tab_ViewAuditTrail_2.png

ApprovalPendingPayments_ViewAuditTrail_printview.html
>05_07_Approval_Pending_Payments_tab_ViewAuditTrail_printview.png

Payments.html
>06_01_Payments.png
>06_02_Payments_click_find_btn.png
>06_03_Payments_click_to_select_records.png