> please ignore css waring:
-webkit-text-size-adjust
-ms-text-size-adjust
screen.css can pass CSS3 valication, if you validate using CSS 2.1, please ignore CSS validation errors caused by below:
overflow-x
overflow-y
box-shadow
text-shadow
resize


> View account search popup, click "Search" will display "No Record Found", click "Search" again will go to reuslts page.

> Click "Validate Entries", "Run Calculation" and "Save Calculation" buttons, will swith validation success/failure status.

> Missing popups are added to "Show Calculation" button in step2  Service History page, Copilot said: "Some of these popups may be assembly tasks", so I only added 2 kinds of popup storyboard missing.