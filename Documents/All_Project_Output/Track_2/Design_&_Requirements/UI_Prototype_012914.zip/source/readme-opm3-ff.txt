Tools_ServiceCreditPreferences.html:
- the three tabs content box should has same height to match the storyboard. I think you'd better to set the min height.
Please check thread http://apps.topcoder.com/forums/?module=Thread&threadID=802968&start=0, copilot confirmed to remove blank spaces.


- In 07_02_Tools_Printing_Tools_tab_ShowSampleInitialStatement_1.png, the box shadow for "address change below" dose not match the storyboard. Please notice such issue in other similar screen like 08_01_Admin_Regenerate_Latest_Reports_tab_InitialBillInvoices_2.png
Please open PSD file 11_DialogWindows_PrintView.psd and check, all shadow effects is the same with old prototypes. Also, I think it does make sense to use consistent shadow effect here, please pass this issue to copolit approval phase.

Additional OPM2 Fixes:
1. We need an Account_SearchResults.html page. Should basically start at View Account

2. In Notifications, change "Unresolved & Suspicious Payments" to "Payments in Suspense" and when clicked it should go to Suspense. See screenshot below.

3. In Notifications, for #183-51-6", what is that? That doesn't look like an actual number that is used by anything in the system. Change it to "I reviewed the Account for John Doe and found an error in Billing Summary. Please fix. Click here to view the account". The "last sentence should be hyperlinked to the the users account details page. See screenshot below.

3. In Reports > Reports, remove the list of reports in the prototype, and replace with actual reports from: https://coder.topcoder.com/tcs/clients/coeci-opm/Storyboards/All_Report_Screens/PNG. 

4. In Reports > Reports, remove Create, Edit, Delete. You can only Print reports. Keep Create, Edit, Delete and Print for Correspondence and Reference

5. Selecting Create or Delete under Reports > Correspondence or Reports > Reference does nothing. 
Q: What is the expected action for create and delete? There are no such functions in WF.
A: "Selecting Create will display the wsywig editor, which is in the storyboards (attached). It's the same editor that appears when you select Edit. Delete should display a prompt "Are you sure you want to delete this item?" with <Cancel Button> and <Yes Button>.
Reports will be handled in the reporting stuff that's coming, and that's pretty much going to be a view only thing. But Reference and Correspondence are text docs that will be loaded via the wsyiwig editor."

6. Selecting Print under the Reports tab just says "Prints currently selected contents". Change this to "Example Print Window - will function in final version of the app".

7. The alignment of two tabs (Work Queue and Reports) doesn't match other tabs in Chrome.  To re-produce, click on View Account tab, then click on each tab across the top.  The header alignment will change when you get to the Work Queue and Reports tabs, then goesd back when you get to the Suspense tab.  The header alignment should be the same for all tabs.
- Checked, the alignment is correct, Work Queue tab and reports tab, page height does not need vertical scroll-bar on browser window, so the page width changes after goes to these two tabs
NOTICE, after update with actual reports list, report tab page height growth, so this page will show vertical scroll-bar by default now.

