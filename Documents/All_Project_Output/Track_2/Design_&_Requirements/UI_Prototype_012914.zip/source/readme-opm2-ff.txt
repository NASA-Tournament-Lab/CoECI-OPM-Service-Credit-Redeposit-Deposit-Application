suspense.html,in the table:
in edit mode of the first row,the input box in "Name" column can not show the value "Patricia Maupin" fully,the lastest "n" is covered by the border of input,please try to show it fully,since the storyboard also cover the text,it can be considered as Recommended.
The name can be any length, but width of the input is fixed becuase there is no room for it, please ignore this issue.

Reviewer Response: Recommendation:
suspense.html
Reset Selected Payment should be disabled unless table row is selected/checked
There is always a row been selected for this page, so the reset button should always been enabled.


Reviewer Response: suspense.html: 
- In "Payment Transaction Details" section, the Date input should be implemented as datepicker. (recommended)
The date input here is readonly, so there should have no datepikcer here.

Reviewer Response: suspense.html,for "Suspense History" modal window,the height of modal window should be bigger to match the storyboard.
- In "04_06_Suspense_History.png" screen,  the modal height should be fixed to match the storyboard.
the print popup height is always dynamically according to its content, please check all printview pages, the storyboard is with fixed height, this already been accepted in contest 1.

Reviewer Response: Reports_DailyReconciliationReport.html:
- the left rail height should be fixed or should has min-height following storyboard
see thread http://apps.topcoder.com/forums/?module=Thread&threadID=802323&start=0
there are lots of blank spacing under the report table of this screen, report page height should be dynamic according to report height and browser height, right?
copilot confirmed: yes