All the fixed issues are shown on the list below:

3.1.1 - fixed.
	1) Duplicated string was removed from the chapter 1.5.5.

	2) Clarification was added to 3.1. And the reviewer agreed with me, by answering "ok" and requesting to final fix only issues #1 and #3 (i.e. not #2):
	"ERD (provided by the client, can be found in the �ClientDocs� folder of the submission)."	

	3) Changed to be as following in the chapter 1.2:
	"Please refer to the public wiki for the source code: http://apps.topcoder.com/wiki/display/projects/OPM"

3.1.3 - fixed (changed as requested)

