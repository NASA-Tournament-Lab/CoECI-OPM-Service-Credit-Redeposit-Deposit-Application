All the fixed issues are shown below:

1.1.1 - fixed (just having "ServiceCreditAutomatedService" package in the class diagram was confirmed by the CoPilot here:
	http://apps.topcoder.com/forums/?module=Thread&threadID=766388&start=0

1.1.3 - fixed
	the following chapters were added to the ADS with the complete details and role of those methods:
	1.2.10 UpdateMasterRecord(�) Workflow
	1.2.11 PrintForms(�) Workflow
	1.2.12 PrintCrystalReport(�) Workflow

	References to chapter 1.2.10, 1.2.11, 1.2.12 were added to the related places in the ADS.	

	The step just after "ProcessBills(...)" (on the "Batch Service Activity Diagram") was renamed to be more clear
	and reflect usage of UpdateMasterRecord(...) method: 
	"Update Master Records for Processed Batch: UpdateMasterRecord(...)"

	A comment note was attached to the "Print Reports: PrintForms(...)" step on the "Batch Service Activity Diagram":
	"It calls PrintCrystalReport(...) to actually print reports."


2.4.2 - fixed (some property-get were provided and the relatd setter methods for the Account class).

3.1.3 - fixed
	zsudraco:
	1) -> "Service Credit Batch Service"
	can be -> can not be

	albertwang:
	1) continue -> continues

	2) -> The application logs a lot of data

	3) is -> are

	4) -> application

	5) is -> are

	6) has -> have

3.2.2 - fixed
	1) names and multiplicity was added for aggregations (enums have "1" multiplicity, not shown by TC UML tool)
	<<uses>>, <<creates>> stereotypes were added for dependencies.

	2) <<override>> stereotype was added.

	3) required item rejected due to successful reappeal. The manager agreed with me and restored score.
	Please refer to the q. 3.2.2 here: 
	https://software.topcoder.com/review/actions/ViewReview.do?method=viewReview&rid=223976