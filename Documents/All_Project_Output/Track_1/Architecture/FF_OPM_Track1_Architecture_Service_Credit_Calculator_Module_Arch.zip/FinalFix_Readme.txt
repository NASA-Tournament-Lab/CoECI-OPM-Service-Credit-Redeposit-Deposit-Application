All the fixed issues are shown on the list below:

1.1.1 - Fixed, the client answer was added to 1.5.14 according to http://apps.topcoder.com/forums/?module=Thread&threadID=764664
	"Some additional forms are also present in the Desktop version � as per client's response."

2.1.4 - fixed, version from the client response was added according to http://apps.topcoder.com/forums/?module=Thread&threadID=765781&start=0
	"MS Windows OS version 2000 (according to the client�s response)."

3.1.2 - fixed (proper indentation was applied)

3.1.3 - fixed
	1) -> "sometimes refers"

	2) -> "and then sort by"

	3) -> "won't add"
	

