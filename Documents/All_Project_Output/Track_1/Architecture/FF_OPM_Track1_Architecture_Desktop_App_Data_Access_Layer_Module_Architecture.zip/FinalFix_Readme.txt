All the fixed issues are shown on the list below:

1.1.4 - fixed, the following notes were added on the main class diagrams:
	"Please note, documentation of methods is provided in this UML class diagram."

	The following notes were added on the last three class diagrams (for auto-generated typed datasets' code):
	"Please note, documentation of constructors is provided in this UML class diagram."

3.1.3 - fixed

	albertwang:
	1) it's -> its

	2) the a -> the

	3) is -> are


	zsudraco:
	1) Batch -> Desktop