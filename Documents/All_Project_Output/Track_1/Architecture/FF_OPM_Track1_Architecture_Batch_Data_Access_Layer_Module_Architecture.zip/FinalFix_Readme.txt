All the fixed issues are shown on the list below:

3.1.1 - required item rejected due to activity diagrams are actually present. 
	Please just open "Activities.tcuml" file. That file has 9 activity diagrams. It was confirmed on the forum, that usage of activity diagrams is
	fine for this project: http://apps.topcoder.com/forums/?module=Thread&threadID=767259&start=0
 

3.1.3 - fixed
	1) -> in those methods

	2) uses -> use

	3) a -> an

	4) application -> applications

	5) is -> are

	6) has -> have

3.2.2 - fixed
	gevak:
	1) changed to Package visibility.
	Please note, RFile uses Protected Friend visibility, so I marked

	2) All methods were moved to a single big [Global] object. The second [Global] box was
	changed to be external.

	zsudraco:
	1) <<uses>>, <<creates>> were added.
	variable names and multiplicity were added to realationships.

	2) <<override>> stereotype was added.

	albertwang:
	1) fixed in "gevak 1)".

	2) fixed in "gevak 1)".