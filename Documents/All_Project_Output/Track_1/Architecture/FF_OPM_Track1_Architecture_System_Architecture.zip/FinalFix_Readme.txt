All the fixed issues are shown on the list below:

1.1.1 - fixed.
	1) "US Bank" stereotype was placed to Lockbox on Logical Architecture.
	Types of external payments were added to the chapter 2.1.2.

	2) "Connect: Direct" and "Flamingo Server" were added to the Logical Architecture.
	Chapters 2.1.5 and 2.1.6 were inserted to the SDS.

2.1.4 - fixed
	1) changed to "data abstraction layer"

	3) "Also sometimes to refers to ServiceCreditMaster table" ->
	"It also sometimes refers to ServiceCreditMaster table"

	4) -> "All three applications"

	5) -> "The Web-application heavily uses"

	6) -> "and an error message for the payment status description"

	7) -> "There are some action buttons too"

2.4.1 - REQUIRED issue was REJECTED, because this is a known bug of TC UML tool.
	It's just impossible to draw such a line in this case.
	Actually, I tried to draw a dashed line first, but TC UML tool doesn't allow that! It allows 
	to provide a dashed line from Lockbox to the Mainframe package, but not to the 
	components within that package. As I remember it is a known bug for years. 
	I use v. 1.2.2 of TC UML tool on MS Windows 7, so you can easily reproduce it.
	Please note, I placed a good stereotype on that line, so the purpose of that 
	dependency is clear.

	Please note, the same issue was raised in the parallel contest for the same diagram,
	and the same 	reviewer agreed with my appeal by rejecting his comment in 3.2.2:
	https://software.topcoder.com/review/actions/ViewAggregation.do?method=viewAggregation&rid=222139

2.4.2 - fixed (color of Database was changed to blue on all the diagrams)
	