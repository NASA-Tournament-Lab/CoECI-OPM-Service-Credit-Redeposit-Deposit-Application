All the fixed issues are shown on the list below:

3.1.3 - fixed
	1) is -> are

	2) it -> its

	3) logs -> log

	4) applications -> application

	5) "Apply the those found" -> "Apply the found"

	6) perform -> performs

	7) return -> returns